<link rel="stylesheet" href="<?php echo SITE_ROOT_URL; ?>views/layered/animatemaster/animate.min.css">
<script type="text/javascript" src="<?php echo SITE_ROOT_URL; ?>colorjs/jscolor.js"></script>
<style>
body
{
margin:0px;
padding:0px;
}
.ulp-content {
    position: relative;
}
.ulp-window {
    text-align: left;
}#ulp-layer-149 {
    background-color: rgba(0, 0, 0, 0.9);
    box-shadow: 0 4px 30px rgba(32, 32, 32, 1);
    text-align: left;
    z-index: 1000002;
}
#ulp-layer-149, #ulp-layer-149 p, #ulp-layer-149 a, #ulp-layer-149 span, #ulp-layer-149 li, #ulp-layer-149 input, #ulp-layer-149 button, #ulp-layer-149 textarea {
    color: #000000;
    font-family: "arial",arial;
    font-weight: 400;
}
.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}
.ulp-layer img {
    border: medium none !important;
    box-shadow: none !important;
    margin: 0 !important;
    max-width: 100% !important;
    min-width: 0 !important;
    padding: 0 !important;
}
img {
    max-width: 100%;
}
#ulp-layer-149 {
    text-align: left;
}
#ulp-layer-149, #ulp-layer-149 p, #ulp-layer-149 a, #ulp-layer-149 span, #ulp-layer-149 li, #ulp-layer-149 input, #ulp-layer-149 button, #ulp-layer-149 textarea {
    color: #000000;
}
#ulp-layer-150 {
    background-color: rgba(10, 10, 10, 0.6);
    padding: 5px 20px;
    text-align: left;
    z-index: 1000003;
}
#ulp-layer-150, #ulp-layer-150 p, #ulp-layer-150 a, #ulp-layer-150 span, #ulp-layer-150 li, #ulp-layer-150 input, #ulp-layer-150 button, #ulp-layer-150 textarea {
    color: #ffffff;
    font-family: "Open Sans",arial;
    font-weight: 100;
    text-shadow: 1px 1px 1px #000000;
}
.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}
#ulp-layer-151 {
    background-color: rgba(0, 0, 0, 0.7);
    text-align: left;
    z-index: 1000007;
}
#ulp-layer-151, #ulp-layer-151 p, #ulp-layer-151 a, #ulp-layer-151 span, #ulp-layer-151 li, #ulp-layer-151 input, #ulp-layer-151 button, #ulp-layer-151 textarea {
    color: #000000;
    font-family: "arial",arial;
    font-weight: 400;
}
.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}
#ulp-layer-152 {
    text-align: justify;
    z-index: 1000007;
}
#ulp-layer-152, #ulp-layer-152 p, #ulp-layer-152 a, #ulp-layer-152 span, #ulp-layer-152 li, #ulp-layer-152 input, #ulp-layer-152 button, #ulp-layer-152 textarea {
    color: #ffffff;
    font-family: "Open Sans",arial;
    font-weight: 100;
    text-shadow: 1px 1px 1px #000000;
}
.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}
#ulp-layer-153 {
    text-align: left;
    z-index: 1000007;
}
#ulp-layer-153, #ulp-layer-153 p, #ulp-layer-153 a, #ulp-layer-153 span, #ulp-layer-153 li, #ulp-layer-153 input, #ulp-layer-153 button, #ulp-layer-153 textarea {
    color: #ffffff;
    font-family: "Open Sans",arial;
    font-weight: 100;
    text-shadow: 1px 1px 1px #000000;
}
.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}
#ulp-layer-153 input.ulp-input {
    padding-left: 34px !important;
}
#ulp-KiNSkXji3bqvBVUB .ulp-input, #ulp-KiNSkXji3bqvBVUB .ulp-input:hover, #ulp-KiNSkXji3bqvBVUB .ulp-input:active, #ulp-KiNSkXji3bqvBVUB .ulp-input:focus {
    background-color: rgba(0, 0, 0, 0.8) !important;
    border-color: #606060;
    border-radius: 3px !important;
    border-width: 1px !important;
}
#ulp-layer-153, #ulp-layer-153 p, #ulp-layer-153 a, #ulp-layer-153 span, #ulp-layer-153 li, #ulp-layer-153 input, #ulp-layer-153 button, #ulp-layer-153 textarea {
    color: #ffffff;
    font-family: "Open Sans",arial;
    font-weight: 100;
    text-shadow: 1px 1px 1px #000000;
}
.ulp-input {
    background: none repeat scroll 0 0 rgba(255, 255, 255, 0.8);
    border-radius: 2px !important;
    border-spacing: 0 !important;
    border-style: solid !important;
    border-width: 1px !important;
    box-shadow: none !important;
    box-sizing: border-box !important;
    clear: both !important;
    font-size: inherit !important;
    height: 100% !important;
    line-height: 1.5 !important;
    margin: 0 !important;
    padding: 0 6px !important;
    vertical-align: middle !important;
    width: 100% !important;
}
input:-moz-read-write, textarea:-moz-read-write {
    -moz-user-modify: read-write !important;
}
input {
    -moz-appearance: textfield;
    -moz-binding: url("chrome://global/content/platformHTMLBindings.xml#inputFields");
    -moz-user-select: text;
    cursor: text;
    font: ;
    letter-spacing: normal;
    line-height: normal;
    padding: 1px;
    text-align: start;
    text-indent: 0;
    text-rendering: optimizelegibility;
    text-transform: none;
    word-spacing: normal;
}
textarea > .anonymous-div, input > .anonymous-div, input::-moz-placeholder, textarea::-moz-placeholder, *|*::-moz-button-content, *|*::-moz-display-comboboxcontrol-frame, optgroup:before {
    text-overflow: inherit;
    unicode-bidi: inherit;
}
input::-moz-placeholder, textarea::-moz-placeholder {
    display: inline-block !important;
    opacity: 0.54;
    overflow: hidden !important;
    pointer-events: none !important;
    resize: none !important;
}
textarea > .anonymous-div, input > .anonymous-div, input::-moz-placeholder, textarea::-moz-placeholder {
    -moz-control-character-visibility: visible;
    border: 0 none !important;
    display: inline-block;
    ime-mode: inherit;
    margin: 0;
    overflow: auto;
    padding: inherit !important;
    resize: inherit;
    text-decoration: inherit;
    white-space: pre;
}
input > .anonymous-div, input::-moz-placeholder {
    line-height: -moz-block-height;
    word-wrap: normal !important;
}

.ulp-fa-input-table {
    display: table;
    height: 100%;
    left: 0;
    line-height: 100%;
    position: absolute;
    top: 0;
    vertical-align: middle;
}
#ulp-layer-153 div.ulp-fa-input-cell {
    padding-left: 4px !important;
    width: 30px !important;
}
.ulp-fa-input-cell {
    display: table-cell;
    opacity: 0.7;
    text-align: center;
    vertical-align: middle;
}
#ulp-layer-153, #ulp-layer-153 p, #ulp-layer-153 a, #ulp-layer-153 span, #ulp-layer-153 li, #ulp-layer-153 input, #ulp-layer-153 button, #ulp-layer-153 textarea {
    color: #ffffff;
    text-shadow: 1px 1px 1px #000000;
}

.fa {
    display: inline-block;
    font-family: FontAwesome;
    font-feature-settings: normal;
    font-kerning: auto;
    font-language-override: normal;
    font-size: inherit;
    font-size-adjust: none;
    font-stretch: normal;
    font-style: normal;
    font-synthesis: weight style;
    font-variant: normal;
    font-weight: normal;
    line-height: 1;
    text-rendering: auto;
}
.ulp-fa-input-cell {
    text-align: center;
}
#ulp-layer-154 {
    text-align: left;
    z-index: 1000007;
}
#ulp-layer-154, #ulp-layer-154 p, #ulp-layer-154 a, #ulp-layer-154 span, #ulp-layer-154 li, #ulp-layer-154 input, #ulp-layer-154 button, #ulp-layer-154 textarea {
    color: #ffffff;
    font-family: "Open Sans",arial;
    font-weight: 100;
    text-shadow: 1px 1px 1px #000000;
}
.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}
#ulp-layer-154 input.ulp-input {
    padding-left: 34px !important;
}
#ulp-KiNSkXji3bqvBVUB .ulp-input, #ulp-KiNSkXji3bqvBVUB .ulp-input:hover, #ulp-KiNSkXji3bqvBVUB .ulp-input:active, #ulp-KiNSkXji3bqvBVUB .ulp-input:focus {
    background-color: rgba(0, 0, 0, 0.8) !important;
    border-color: #606060;
    border-radius: 3px !important;
    border-width: 1px !important;
}
#ulp-layer-154, #ulp-layer-154 p, #ulp-layer-154 a, #ulp-layer-154 span, #ulp-layer-154 li, #ulp-layer-154 input, #ulp-layer-154 button, #ulp-layer-154 textarea {
    color: #ffffff;
    font-family: "Open Sans",arial;
    font-weight: 100;
    text-shadow: 1px 1px 1px #000000;
}
.ulp-input {
    background: none repeat scroll 0 0 rgba(255, 255, 255, 0.8);
    border-radius: 2px !important;
    border-spacing: 0 !important;
    border-style: solid !important;
    border-width: 1px !important;
    box-shadow: none !important;
    box-sizing: border-box !important;
    clear: both !important;
    font-size: inherit !important;
    height: 100% !important;
    line-height: 1.5 !important;
    margin: 0 !important;
    padding: 0 6px !important;
    vertical-align: middle !important;
    width: 100% !important;
	background: none repeat scroll 0 0 #000;
	opacity:0.8;
}
input:-moz-read-write, textarea:-moz-read-write {
    -moz-user-modify: read-write !important;
}
input {
    -moz-appearance: textfield;
    -moz-binding: url("chrome://global/content/platformHTMLBindings.xml#inputFields");
    -moz-user-select: text;
    cursor: text;
    font: ;
    letter-spacing: normal;
    line-height: normal;
    padding: 1px;
    text-align: start;
    text-indent: 0;
    text-rendering: optimizelegibility;
    text-transform: none;
    word-spacing: normal;
}
textarea > .anonymous-div, input > .anonymous-div, input::-moz-placeholder, textarea::-moz-placeholder, *|*::-moz-button-content, *|*::-moz-display-comboboxcontrol-frame, optgroup:before {
    text-overflow: inherit;
    unicode-bidi: inherit;
}
input::-moz-placeholder, textarea::-moz-placeholder {
    display: inline-block !important;
    opacity: 0.54;
    overflow: hidden !important;
    pointer-events: none !important;
    resize: none !important;
}
textarea > .anonymous-div, input > .anonymous-div, input::-moz-placeholder, textarea::-moz-placeholder {
    -moz-control-character-visibility: visible;
    border: 0 none !important;
    display: inline-block;
    ime-mode: inherit;
    margin: 0;
    overflow: auto;
    padding: inherit !important;
    resize: inherit;
    text-decoration: inherit;
    white-space: pre;
}
input > .anonymous-div, input::-moz-placeholder {
    line-height: -moz-block-height;
    word-wrap: normal !important;
}
.ulp-fa-input-table {
    display: table;
    height: 100%;
    left: 0;
    line-height: 100%;
    position: absolute;
    top: 0;
    vertical-align: middle;
}
#ulp-layer-154 {
    text-align: left;
}
#ulp-layer-154, #ulp-layer-154 p, #ulp-layer-154 a, #ulp-layer-154 span, #ulp-layer-154 li, #ulp-layer-154 input, #ulp-layer-154 button, #ulp-layer-154 textarea {
    color: #ffffff;
    text-shadow: 1px 1px 1px #000000;
}
#ulp-layer-154 div.ulp-fa-input-cell {
    padding-left: 4px !important;
    width: 30px !important;
}
.ulp-fa-input-cell {
    display: table-cell;
    opacity: 0.7;
    text-align: center;
    vertical-align: middle;
}
.fa {
    display: inline-block;
    font-family: FontAwesome;
    font-feature-settings: normal;
    font-kerning: auto;
    font-language-override: normal;
    font-size: inherit;
    font-size-adjust: none;
    font-stretch: normal;
    font-style: normal;
    font-synthesis: weight style;
    font-variant: normal;
    font-weight: normal;
    line-height: 1;
    text-rendering: auto;
}
.ulp-fa-input-cell {
    text-align: center;
}
#ulp-layer-155 {
    text-align: right;
    z-index: 1000007;
}
#ulp-layer-155, #ulp-layer-155 p, #ulp-layer-155 a, #ulp-layer-155 span, #ulp-layer-155 li, #ulp-layer-155 input, #ulp-layer-155 button, #ulp-layer-155 textarea {
    color: #ffffff;
    font-family: "Open Sans",arial;
    font-weight: 100;
    text-shadow: 1px 1px 1px #000000;
}
.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}
#ulp-KiNSkXji3bqvBVUB .ulp-submit, #ulp-KiNSkXji3bqvBVUB .ulp-submit:visited {
    background: linear-gradient(#94b336, #a6c93c) repeat scroll 0 0 #a6c93c;
    border: 1px solid #a6c93c;
    border-radius: 3px !important;
}
#ulp-layer-155, #ulp-layer-155 p, #ulp-layer-155 a, #ulp-layer-155 span, #ulp-layer-155 li, #ulp-layer-155 input, #ulp-layer-155 button, #ulp-layer-155 textarea {
    color: #ffffff;
    font-family: "Open Sans",arial;
    font-weight: 100;
    text-shadow: 1px 1px 1px #000000;
}
.ulp-window a {
    text-decoration: none !important;
}
.ulp-submit, .ulp-submit:visited, .ulp-submit-button, .ulp-submit-button:visited {
    border-radius: 2px;
    box-shadow: none;
    cursor: pointer;
    display: inline-block;
    font-size: inherit !important;
    height: auto;
    line-height: 1.5;
    margin: 0;
    padding: 5px 20px;
    position: relative;
    text-decoration: none !important;
    transition-duration: 0.3s;
    white-space: nowrap;
    width: auto;
	background: linear-gradient(#94b336, #a6c93c) repeat scroll 0 0 #a6c93c;
    border: 1px solid #a6c93c;
    border-radius: 3px !important;
}
.fo-right-ribbon a:hover, .fo-right-ribbon a:focus, a {
    text-decoration: none;
}
a, a:active, a:hover {
    outline: medium none;
}

.fa {
    display: inline-block;
    font-family: FontAwesome;
    font-feature-settings: normal;
    font-kerning: auto;
    font-language-override: normal;
    font-size: inherit;
    font-size-adjust: none;
    font-stretch: normal;
    font-style: normal;
    font-synthesis: weight style;
    font-variant: normal;
    font-weight: normal;
    line-height: 1;
    text-rendering: auto;
}
#ulp-layer-155, #ulp-layer-155 p, #ulp-layer-155 a, #ulp-layer-155 span, #ulp-layer-155 li, #ulp-layer-155 input, #ulp-layer-155 button, #ulp-layer-155 textarea {
    color: #ffffff;
    text-shadow: 1px 1px 1px #000000;
}
.ulp-submit, .ulp-submit:visited, .ulp-submit-button, .ulp-submit-button:visited {
    cursor: pointer;
    font-size: inherit !important;
    white-space: nowrap;
}
#ulp-layer-155 {
    text-align: right;
}
#ulp-layer-156 {
    background-color: rgba(0, 0, 0, 0.5);
    padding: 0 10px;
    text-align: left;
    z-index: 1000007;
}
#ulp-layer-156, #ulp-layer-156 p, #ulp-layer-156 a, #ulp-layer-156 span, #ulp-layer-156 li, #ulp-layer-156 input, #ulp-layer-156 button, #ulp-layer-156 textarea {
    color: #ffffff;
    font-family: "Open Sans",arial;
    font-weight: 100;
    text-shadow: 1px 1px 1px #000000;
}
.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}
#ulp-layer-156, #ulp-layer-156 p, #ulp-layer-156 a, #ulp-layer-156 span, #ulp-layer-156 li, #ulp-layer-156 input, #ulp-layer-156 button, #ulp-layer-156 textarea {
    color: #ffffff;
    font-family: "Open Sans",arial;
    font-weight: 100;
    text-shadow: 1px 1px 1px #000000;
}
.ulp-window a {
    text-decoration: none !important;
}
.fo-right-ribbon a:hover, .fo-right-ribbon a:focus, a {
    text-decoration: none;
}
a, .contactForm input[type="text"]:focus, .contactForm input[type="email"]:focus, .contactForm textarea:focus, input#formSubmit, .errorForm, #subscribe input[type="email"]:focus, .errorSubs, .servSingle, #toTop i, #notForm input[type="email"]:focus, .contactForm input#submit, #loginForm input, #loginForm input[type="text"]:focus, #loginForm input[type="password"]:focus {
    transition: all 0.5s ease 0s;
}
a, a:active, a:hover {
    outline: medium none;
}
table
{
	margin:20px;
	background:#f8f8f8;
	
}
table td
{
	padding:10px;
	border:1px solid #ccc;
}
table td label
{
	font-family:Arial, Helvetica, sans-serif;
	font-size:14px;
	font-weight:normal;
}
table td input[type='text']
{
	border:none;
	padding:10px;
	font-size:12px;
	font-weight:normal;
	border:1px solid #ccc;
	width:300px;
}
table td textarea
{
	width:300px;
	font-size:12px;
}
#updateform
{
	background:#019ad2;
	color:#fff;
	font-size:16px;
	padding:10px;
	border:1px solid #019ad2;
	width:100px;
}
</style>

<?php


$txthtml="<div id='popupform' style='position:relative;'><div class='ulp-content ' style='width: 640px; height: 400px; margin: 5% auto auto;'>
							<div id='ulp-layer-149' class='ulp-layer animated bounceInDown' style='width: 640px; height: 400px; font-size: 14px; left: 0px; top: 0px;'><img alt='' src='https://layeredpopups.com/layered-popups/images/default/business03.jpg'></div>
							<div id='ulp-layer-150' class='ulp-layer animated bounceInLeft' style='font-size: 28px; left: 0px; top: 20px;'>SUBSCRIBE TO NEWSLETTER</div>
							<div id='ulp-layer-151' class='ulp-layer animated bounceInRight' style='width: 340px; height: 280px; font-size: 14px; left: 300px; top: 100px;'></div>
							<div id='ulp-layer-152' class='ulp-layer animated slideInDown' style='width: 300px; font-size: 14px; left: 320px; top: 120px;'>Turpis dis amet adipiscing hac montes odio ac velit? Porta, non rhoncus vut, vel, et adipiscing magna pulvinar adipiscing est adipiscing urna. Dignissim rhoncus scelerisque pulvinar?</div>
							<div id='ulp-layer-153' class='ulp-layer animated zoomInRight' style='width: 300px; height: 38px; font-size: 15px; left: 320px; top: 220px;'><input type='text' onfocus='jQuery(this).removeClass('ulp-input-error');' value='' placeholder='Enter your name...' name='ulp-name' class='ulp-input'><div class='ulp-fa-input-table'><div class='ulp-fa-input-cell'><i class='fa fa-user'></i></div></div></div>
							<div id='ulp-layer-154' class='ulp-layer animated zoomInLeft' style='width: 300px; height: 38px; font-size: 15px; left: 320px; top: 265px;'><input type='text' onfocus='jQuery(this).removeClass('ulp-input-error');' value='' placeholder='Enter your e-mail...' name='ulp-email' class='ulp-input'><div class='ulp-fa-input-table'><div class='ulp-fa-input-cell'><i class='fa fa-envelope'></i></div></div></div>
							<div id='ulp-layer-155' class='ulp-layer animated slideInUp' style='width: 300px; height: 38px; font-size: 15px; left: 320px; top: 310px;'><a data-loading='Loading...' data-label='Subscribe' data-icon='fa-sign-in' onclick='return ulp_subscribe(this);' class='ulp-submit'><i class='fa fa-sign-in'></i>&nbsp; Subscribe</a></div>
							<div id='ulp-layer-156' class='ulp-layer' style='height: 20px; font-size: 12px; left: 0px; top: 380px;'><a onclick='return ulp_self_close();' href='#'>close</a></div>
						</div>

					</div>
						";
						echo $txthtml;
						?>
						
                        <table width="97%" border="0">
  <tr>
    
    <td><label>Header Background Color :</label></td>
    <td><input class="color boxcolor" value="66ff00" id="bkgcolor" onchange="header_bg();"></td>
    <td><label>Header Text :</label></td>
    <td><input type="text" value="" id="header_txt" onkeypress="header_txt();" maxlength="30" /></td>
    <!-- <td><label>Popup Background Color :</label></td>
    <td><input class="color boxcolor" value="66ff00" id="popbgcolor" onchange="popup_bg();"></td> -->
    
  </tr>
    <tr>
    
    <!-- <td><label>Header Background Color :</label></td>
    <td><input class="color boxcolor" value="66ff00" id="bkgcolor" onchange="header_bg();"></td>
    <td><label>Header Text :</label></td>
    <td><input type="text" value="" id="header_txt" onkeypress="header_txt();" maxlength="30" /></td>-->
    <!-- <td><label>Popup Background Color :</label></td>
    <td><input class="color boxcolor" value="66ff00" id="popbgcolor" onchange="popup_bg();"></td> -->
    
  </tr>
  <tr>
    <td><label>Layer one Color :</label></td>
    <td><input class="color boxcolor" value="66ff00" id="layer1_color" onchange="layer1_color();"></td>
    <td><label>Layer One Text :</label></td>
    <td><textarea type="text" value="" id="layer1_txt" onkeypress="layer1_txt();" maxlength="30" ></textarea></td>
    <!-- <td>&nbsp;</td>
    <td>&nbsp;</td> -->
  </tr>
   <!-- <tr>
    <td><label>Layer Two Color :</label></td>
    <td><input class="color boxcolor" value="66ff00" id="layer2_color" onchange="layer2_color();"></td>
    <td><label>Layer Two Text :</label></td>
    <td><input type="text" value="" id="layer2_txt" onkeypress="layer2_txt();"  /></td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
     <tr>
    <td><label>Layer Three Color :</label></td>
    <td><input class="color boxcolor" value="66ff00" id="layer3_color" onchange="layer3_color();"></td>
    <td><label>Layer Three Text :</label></td>
    <td><textarea id="layer3_txt" onkeypress="layer3_txt();"></textarea></td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>-->
      <tr>
    <td><label>Label One Color :</label></td>
    <td><input class="color boxcolor" value="66ff00" id="label1_color" onchange="label1_color();"></td>
    <!-- <td><label>Label One Text :</label></td>
    <td><input type="text" value="" id="label1_txt" onkeypress="label1_txt();"  /></td>-->
    <td><label>Placeholder one text :</label></td>
    <td><input type="text" value="" id="placeholder1_txt" onkeypress="placeholder1_txt();"  /></td>
  </tr>
  
    <tr>
     <td><label>Label Two Color :</label></td>
    <td><input class="color boxcolor" value="66ff00" id="label2_color" onchange="label2_color();"></td>
    <!-- <td><label>Label Two Text :</label></td>
    <td><input type="text" value="" id="label2_txt" onkeypress="label2_txt();"  /></td> -->
    <td><label>Placeholder Two text :</label></td>
    <td><input type="text" value="" id="placeholder2_txt" onkeypress="placeholder2_txt();"  /></td> 
  </tr>
  
  
    <!-- <tr>
    <td><label>Label Three Color :</label></td>
    <td><input class="color boxcolor" value="66ff00" id="label3_color" onchange="label3_color();"></td>
    <td><label>Label Three Text :</label></td>
    <td><input type="text" value="" id="label3_txt" onkeypress="label3_txt();"  /></td>
    <td><label>Placeholder Three text :</label></td>
    <td><input type="text" value="" id="placeholder3_txt" onkeypress="placeholder3_txt();"  /></td> 
  </tr> -->
  
    <tr>
    <td><label>Button Color:</label></td>
    <td><input class="color boxcolor" value="66ff00" id="button1_color" onchange="button1_color();"></td>
    <td><label>Button Background Color :</label></td>
    <td><input class="color boxcolor" value="66ff00" id="button1_bkgcolor" onchange="button1_bkgcolor();"></td>
    <td><label>Button Text :</label></td>
    <td><input type="text" value="" id="button1_txt" onkeypress="button1_txt();"  /></td>
  
  </tr>
  
   <!-- <tr>
    <td><label>Layer Four Color :</label></td>
    <td><input class="color boxcolor" value="66ff00" id="layer4_color" onchange="layer4_color();"></td>
    <td><label>Layer Four Text :</label></td>
    <td><input type="text" value="" onkeypress="layer4_txt();" id="layer4_txt" /></td>
    <td>Close Button Background</td>
    <td><input class="color boxcolor" value="66ff00" id="buttonclose_bkgcolor" onchange="buttonclose_bkgcolor();"></td>
  </tr> -->
  
  
  
  
    <tr>
<td>&nbsp;</td>    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
</table>

</div>       
<script type="text/javascript">
function pop_layer_data()
{
	var header_txt=$("#ulp-layer-150").html();
	var layer1_txt=$("#ulp-layer-152").html();
	//var layer2_txt=$("#ulp-layer-173").html();
	//var layer3_txt=$("#ulp-layer-174").html();
	//var label1_txt=$("#ulp-layer-153").html();
	//var label2_txt=$("#ulp-layer-154").html();
	//var label3_txt=$("#ulp-layer-179").html();
	//var layer4_txt=$("#ulp-layer-182").html();
	var placeholder1_txt=$("#ulp-layer-153 .ulp-input").attr('placeholder');
	var placeholder2_txt=$("#ulp-layer-154 .ulp-input").attr('placeholder');
	//var placeholder3_txt=$("#ulp-layer-180 .ulp-input").attr('placeholder');
	var button1_txt=$("#ulp-layer-155 .ulp-submit").attr('data-label');

	$("#header_txt").attr('value',header_txt);
	$("#layer1_txt").val(layer1_txt);
	//$("#layer2_txt").val(layer2_txt);
	//$("#layer3_txt").val(layer3_txt);
	//$("#label1_txt").val(label1_txt);
	//$("#label2_txt").val(label2_txt);
	//$("#label3_txt").val(label3_txt);
	//$("#layer4_txt").val(layer4_txt);
	$("#placeholder1_txt").val(placeholder1_txt);
	$("#placeholder2_txt").val(placeholder2_txt);
	//$("#placeholder3_txt").val(placeholder3_txt);
	$("#button1_txt").val(button1_txt);
}

						/*function popup_bg()
						{
							
							var popbgcolor="#"+$("#popbgcolor").val();
							//alert(bgcolor);
							$("#ulp-layer-151").css("background-color",popbgcolor);
						}*/
						function header_bg()
						{
							var bkgcolor="#"+$("#bkgcolor").val();
							//alert(bgcolor);
							$("#ulp-layer-150").css("background-color",bkgcolor);
						}
						function header_txt()
						{
							var header_txt=$("#header_txt").val();
							//alert(bgcolor);
							$("#ulp-layer-150").html(header_txt);
						}
						
						function layer1_color()
						{
							var fcolor="#"+$("#layer1_color").val();
							//alert(bgcolor);
							$("#ulp-layer-152").css("color",fcolor);
						}
						function layer1_txt()
						{
							var layer1_txt=$("#layer1_txt").val();
							//alert(bgcolor);
							$("#ulp-layer-152").html(layer1_txt);
						}
						/*function layer2_color()
						{
							var fcolor="#"+$("#layer2_color").val();
							//alert(bgcolor);
							$("#ulp-layer-173").css("color",fcolor);
						}
						function layer2_txt()
						{
							var layer2_txt=$("#layer2_txt").val();
							//alert(bgcolor);
							$("#ulp-layer-173").html(layer2_txt);
						}
						function layer3_color()
						{
							var fcolor="#"+$("#layer3_color").val();
							//alert(bgcolor);
							$("#ulp-layer-174").css("color",fcolor);
						}
						function layer3_txt()
						{
							var layer3_txt=$("#layer3_txt").val();
							//alert(bgcolor);
							$("#ulp-layer-174").html(layer3_txt);
						}*/
						function label1_color()
						{
							var fcolor="#"+$("#label1_color").val();
							//alert(bgcolor);
							$("#ulp-layer-153").css("color",fcolor);
						}
						/*function label1_txt()
						{
							var label1_txt=$("#label1_txt").val();
							//alert(bgcolor);
							$("#ulp-layer-152").html(label1_txt);
						}*/
						function placeholder1_txt()
						{
							var placeholder1_txt=$("#placeholder1_txt").val();
							//alert(bgcolor);
							$("#ulp-layer-153 .ulp-input").attr('placeholder',placeholder1_txt);
						}
						
						function label2_color()
						{
							var fcolor="#"+$("#label2_color").val();
							//alert(bgcolor);
							$("#ulp-layer-154").css("color",fcolor);
						}
						/*function label2_txt()
						{
							var label2_txt=$("#label2_txt").val();
							//alert(bgcolor);
							$("#ulp-layer-177").html(label2_txt);
						}*/
						function placeholder2_txt()
						{
							var placeholder2_txt=$("#placeholder2_txt").val();
							//alert(bgcolor);
							$("#ulp-layer-154 .ulp-input").attr('placeholder',placeholder2_txt);
						}
						function label3_color()
						{
							var fcolor="#"+$("#label3_color").val();
							//alert(bgcolor);
							$("#ulp-layer-179").css("color",fcolor);
						}
						function label3_txt()
						{
							var label3_txt=$("#label3_txt").val();
							//alert(bgcolor);
							$("#ulp-layer-179").html(label3_txt);
						}
						function placeholder3_txt()
						{
							var placeholder3_txt=$("#placeholder3_txt").val();
							//alert(bgcolor);
							$("#ulp-layer-180 .ulp-input").attr('placeholder',placeholder3_txt);
						}
						
						function button1_color()
						{
							var fcolor="#"+$("#button1_color").val();
							//alert(bgcolor);
							$("#ulp-layer-155 .ulp-submit").css("color",fcolor);
						}
						function button1_bkgcolor()
						{
							var button1_bkgcolor="#"+$("#button1_bkgcolor").val();
							//alert(button1_bkgcolor);
							$("#ulp-layer-155 .ulp-submit").css('background',button1_bkgcolor);
						}
						function button1_txt()
						{
							var button1_txt=$("#button1_txt").val();
							//alert(bgcolor);
							$("#ulp-layer-155 .ulp-submit").html(button1_txt);
						}
						
						/*function layer4_color()
						{
							var fcolor="#"+$("#layer4_color").val();
							//alert(bgcolor);
							$("#ulp-layer-182").css("color",fcolor);
						}*/
						/*function layer4_txt()
						{
							var layer4_txt=$("#layer4_txt").val();
							//alert(bgcolor);
							$("#ulp-layer-182").html(layer4_txt);
						}*/
						
						/*function buttonclose_bkgcolor()
						{
							var bkgcolor="#"+$("#buttonclose_bkgcolor").val();
							//alert(bgcolor);
							$("#ulp-layer-183").css("background-color",bkgcolor);
						}*/
						
						
						function updateform()
						{
							var popupform= $("#popupform").html();
							
							$.ajax({
							type: "post",
							url: 'animatemaster/updatepop1.php',
							data: {
							popupform: popupform,
							},			
							success: function(response) {
								alert(response);
							},
							error:function 
							(XMLHttpRequest, textStatus, errorThrown) {
							}
							});  
							
						}
						</script>
