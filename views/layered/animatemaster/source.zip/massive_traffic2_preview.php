<link rel="stylesheet" href="http://www.cliks.it/click/views/layered/animatemaster/animate.min.css">
<style>
body
{
margin:0px;
padding:0px;
}
.ulp-content {
    position: relative;
}
#ulp-layer-205 {
    background-color: rgba(255, 255, 255, 1);
    border-radius: 3px;
    box-shadow: 0 4px 20px rgba(32, 32, 32, 1);
    text-align: left;
    z-index: 1000003;
}
#ulp-layer-205, #ulp-layer-205 p, #ulp-layer-205 a, #ulp-layer-205 span, #ulp-layer-205 li, #ulp-layer-205 input, #ulp-layer-205 button, #ulp-layer-205 textarea {
    color: #000000;
    font-family: "arial",arial;
    font-weight: 400;
}
.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}
#ulp-layer-206 {
    border-radius: 3px;
    box-shadow: 0 0 90px rgba(32, 32, 32, 0.1) inset;
    text-align: left;
    z-index: 1000005;
}
#ulp-layer-206, #ulp-layer-206 p, #ulp-layer-206 a, #ulp-layer-206 span, #ulp-layer-206 li, #ulp-layer-206 input, #ulp-layer-206 button, #ulp-layer-206 textarea {
    color: #000000;
    font-family: "arial",arial;
    font-weight: 400;
}
.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}
#ulp-layer-207 {
    letter-spacing: -1px;
    text-align: left;
    z-index: 1000007;
}
#ulp-layer-207, #ulp-layer-207 p, #ulp-layer-207 a, #ulp-layer-207 span, #ulp-layer-207 li, #ulp-layer-207 input, #ulp-layer-207 button, #ulp-layer-207 textarea {
    color: #56912d;
    font-family: "arial",arial;
    font-weight: 700;
}
.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}
#ulp-layer-208 {
    line-height: 1.3;
    text-align: left;
    z-index: 1000007;
}
#ulp-layer-208, #ulp-layer-208 p, #ulp-layer-208 a, #ulp-layer-208 span, #ulp-layer-208 li, #ulp-layer-208 input, #ulp-layer-208 button, #ulp-layer-208 textarea {
    color: #888888;
    font-family: "arial",arial;
    font-weight: 400;
}
.ulp-layer {
    box-sizing: border-box;
    position: absolute;
}
#ulp-layer-209 {
    text-align: left;
    z-index: 1000007;
}
#ulp-layer-209, #ulp-layer-209 p, #ulp-layer-209 a, #ulp-layer-209 span, #ulp-layer-209 li, #ulp-layer-209 input, #ulp-layer-209 button, #ulp-layer-209 textarea {
    color: #333333;
    font-family: "arial",arial;
    font-weight: 700;
}
.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}
ul.ulp-sf3-popup {
    list-style: outside none none !important;
    margin: 0 !important;
    padding: 0 !important;
}
ul, menu, dir {
    display: block;
}
#ulp-layer-210 {
    background-color: rgba(221, 153, 51, 1);
    border-radius: 3px;
    box-shadow: 0 4px 20px rgba(32, 32, 32, 1);
    text-align: left;
    z-index: 1000005;
}
#ulp-layer-210, #ulp-layer-210 p, #ulp-layer-210 a, #ulp-layer-210 span, #ulp-layer-210 li, #ulp-layer-210 input, #ulp-layer-210 button, #ulp-layer-210 textarea {
    color: #000000;
    font-family: "arial",arial;
    font-weight: 400;
}
.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}
#ulp-layer-211 {
    border-radius: 3px;
    box-shadow: 0 0 90px rgba(32, 32, 32, 0.1) inset;
    text-align: left;
    z-index: 1000005;
}
#ulp-layer-211, #ulp-layer-211 p, #ulp-layer-211 a, #ulp-layer-211 span, #ulp-layer-211 li, #ulp-layer-211 input, #ulp-layer-211 button, #ulp-layer-211 textarea {
    color: #000000;
    font-family: "arial",arial;
    font-weight: 400;
}
.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}
#ulp-layer-212 {
    letter-spacing: -1px;
    text-align: center;
    z-index: 1000007;
}
#ulp-layer-212, #ulp-layer-212 p, #ulp-layer-212 a, #ulp-layer-212 span, #ulp-layer-212 li, #ulp-layer-212 input, #ulp-layer-212 button, #ulp-layer-212 textarea {
    color: #ffffff;
    font-family: "arial",arial;
    font-weight: 700;
    text-shadow: 1px 1px 1px #000000;
}
.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}
#ulp-layer-213 {
    text-align: justify;
    z-index: 1000008;
}
#ulp-layer-213, #ulp-layer-213 p, #ulp-layer-213 a, #ulp-layer-213 span, #ulp-layer-213 li, #ulp-layer-213 input, #ulp-layer-213 button, #ulp-layer-213 textarea {
    color: #000000;
    font-family: "arial",arial;
    font-weight: 400;
    text-shadow: 1px 1px 1px #ffffff;
}
.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}
#ulp-layer-213 input.ulp-input {
    padding-left: 32px !important;
}
#ulp-RWyl85W8ZegKXhFU .ulp-input, #ulp-RWyl85W8ZegKXhFU .ulp-input:hover, #ulp-RWyl85W8ZegKXhFU .ulp-input:active, #ulp-RWyl85W8ZegKXhFU .ulp-input:focus {
    background-color: rgba(255, 255, 255, 1) !important;
    border-color: #ffffff;
    border-radius: 2px !important;
    border-width: 1px !important;
}
#ulp-layer-213, #ulp-layer-213 p, #ulp-layer-213 a, #ulp-layer-213 span, #ulp-layer-213 li, #ulp-layer-213 input, #ulp-layer-213 button, #ulp-layer-213 textarea {
    color: #000000;
    font-family: "arial",arial;
    font-weight: 400;
    text-shadow: 1px 1px 1px #ffffff;
}
.ulp-input {
    background: none repeat scroll 0 0 rgba(255, 255, 255, 0.8);
    border-radius: 2px !important;
    border-spacing: 0 !important;
    border-style: solid !important;
    border-width: 1px !important;
    box-shadow: none !important;
    box-sizing: border-box !important;
    clear: both !important;
    font-size: inherit !important;
    height: 100% !important;
    line-height: 1.5 !important;
    margin: 0 !important;
    padding: 0 6px !important;
    vertical-align: middle !important;
    width: 100% !important;
}
input:-moz-read-write, textarea:-moz-read-write {
    -moz-user-modify: read-write !important;
}
input {
    -moz-appearance: textfield;
    -moz-binding: url("chrome://global/content/platformHTMLBindings.xml#inputFields");
    -moz-user-select: text;
    cursor: text;
    font: ;
    letter-spacing: normal;
    line-height: normal;
    padding: 1px;
    text-align: start;
    text-indent: 0;
    text-rendering: optimizelegibility;
    text-transform: none;
    word-spacing: normal;
}
textarea > .anonymous-div, input > .anonymous-div, input::-moz-placeholder, textarea::-moz-placeholder, *|*::-moz-button-content, *|*::-moz-display-comboboxcontrol-frame, optgroup:before {
    text-overflow: inherit;
    unicode-bidi: inherit;
}
input::-moz-placeholder, textarea::-moz-placeholder {
    display: inline-block !important;
    opacity: 0.54;
    overflow: hidden !important;
    pointer-events: none !important;
    resize: none !important;
}
textarea > .anonymous-div, input > .anonymous-div, input::-moz-placeholder, textarea::-moz-placeholder {
    -moz-control-character-visibility: visible;
    border: 0 none !important;
    display: inline-block;
    ime-mode: inherit;
    margin: 0;
    overflow: auto;
    padding: inherit !important;
    resize: inherit;
    text-decoration: inherit;
    white-space: pre;
}
input > .anonymous-div, input::-moz-placeholder {
    line-height: -moz-block-height;
    word-wrap: normal !important;
}

.ulp-fa-input-table {
    display: table;
    height: 100%;
    left: 0;
    line-height: 100%;
    position: absolute;
    top: 0;
    vertical-align: middle;
}
.ulp-fa-input-cell {
    display: table-cell;
    opacity: 0.7;
    text-align: center;
    vertical-align: middle;
}
.fa-user:before {
    content: "";
}
.fa {
    display: inline-block;
    font-family: FontAwesome;
    font-feature-settings: normal;
    font-kerning: auto;
    font-language-override: normal;
    font-size: inherit;
    font-size-adjust: none;
    font-stretch: normal;
    font-style: normal;
    font-synthesis: weight style;
    font-variant: normal;
    font-weight: normal;
    line-height: 1;
    text-rendering: auto;
}
#ulp-layer-214 {
    text-align: justify;
    z-index: 1000008;
}
#ulp-layer-214, #ulp-layer-214 p, #ulp-layer-214 a, #ulp-layer-214 span, #ulp-layer-214 li, #ulp-layer-214 input, #ulp-layer-214 button, #ulp-layer-214 textarea {
    color: #000000;
    font-family: "arial",arial;
    font-weight: 400;
    text-shadow: 1px 1px 1px #ffffff;
}
.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}
#ulp-layer-214 input.ulp-input {
    padding-left: 32px !important;
}
#ulp-RWyl85W8ZegKXhFU .ulp-input, #ulp-RWyl85W8ZegKXhFU .ulp-input:hover, #ulp-RWyl85W8ZegKXhFU .ulp-input:active, #ulp-RWyl85W8ZegKXhFU .ulp-input:focus {
    background-color: rgba(255, 255, 255, 1) !important;
    border-color: #ffffff;
    border-radius: 2px !important;
    border-width: 1px !important;
}
#ulp-layer-214, #ulp-layer-214 p, #ulp-layer-214 a, #ulp-layer-214 span, #ulp-layer-214 li, #ulp-layer-214 input, #ulp-layer-214 button, #ulp-layer-214 textarea {
    color: #000000;
    font-family: "arial",arial;
    font-weight: 400;
    text-shadow: 1px 1px 1px #ffffff;
}
.ulp-input {
    background: none repeat scroll 0 0 rgba(255, 255, 255, 0.8);
    border-radius: 2px !important;
    border-spacing: 0 !important;
    border-style: solid !important;
    border-width: 1px !important;
    box-shadow: none !important;
    box-sizing: border-box !important;
    clear: both !important;
    font-size: inherit !important;
    height: 100% !important;
    line-height: 1.5 !important;
    margin: 0 !important;
    padding: 0 6px !important;
    vertical-align: middle !important;
    width: 100% !important;
}
input:-moz-read-write, textarea:-moz-read-write {
    -moz-user-modify: read-write !important;
}
input {
    -moz-appearance: textfield;
    -moz-binding: url("chrome://global/content/platformHTMLBindings.xml#inputFields");
    -moz-user-select: text;
    cursor: text;
    font: ;
    letter-spacing: normal;
    line-height: normal;
    padding: 1px;
    text-align: start;
    text-indent: 0;
    text-rendering: optimizelegibility;
    text-transform: none;
    word-spacing: normal;
}
textarea > .anonymous-div, input > .anonymous-div, input::-moz-placeholder, textarea::-moz-placeholder, *|*::-moz-button-content, *|*::-moz-display-comboboxcontrol-frame, optgroup:before {
    text-overflow: inherit;
    unicode-bidi: inherit;
}
input::-moz-placeholder, textarea::-moz-placeholder {
    display: inline-block !important;
    opacity: 0.54;
    overflow: hidden !important;
    pointer-events: none !important;
    resize: none !important;
}
textarea > .anonymous-div, input > .anonymous-div, input::-moz-placeholder, textarea::-moz-placeholder {
    -moz-control-character-visibility: visible;
    border: 0 none !important;
    display: inline-block;
    ime-mode: inherit;
    margin: 0;
    overflow: auto;
    padding: inherit !important;
    resize: inherit;
    text-decoration: inherit;
    white-space: pre;
}
input > .anonymous-div, input::-moz-placeholder {
    line-height: -moz-block-height;
    word-wrap: normal !important;
}
element.style {
    font-size: 14px;
}

.ulp-fa-input-table {
    display: table;
    height: 100%;
    left: 0;
    line-height: 100%;
    position: absolute;
    top: 0;
    vertical-align: middle;
}

#ulp-layer-214 div.ulp-fa-input-cell {
    padding-left: 4px !important;
    width: 28px !important;
}
.ulp-fa-input-cell {
    display: table-cell;
    opacity: 0.7;
    text-align: center;
    vertical-align: middle;
}
.fa-envelope:before {
    content: "";
}
.fa {
    display: inline-block;
    font-family: FontAwesome;
    font-feature-settings: normal;
    font-kerning: auto;
    font-language-override: normal;
    font-size: inherit;
    font-size-adjust: none;
    font-stretch: normal;
    font-style: normal;
    font-synthesis: weight style;
    font-variant: normal;
    font-weight: normal;
    line-height: 1;
    text-rendering: auto;
}
#ulp-layer-215 {
    text-align: center;
    z-index: 1000009;
}
#ulp-layer-215, #ulp-layer-215 p, #ulp-layer-215 a, #ulp-layer-215 span, #ulp-layer-215 li, #ulp-layer-215 input, #ulp-layer-215 button, #ulp-layer-215 textarea {
    color: #ffffff;
    font-family: "arial",arial;
    font-weight: 400;
    text-shadow: 1px 1px 1px #000000;
}
.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}
#ulp-RWyl85W8ZegKXhFU .ulp-submit, #ulp-RWyl85W8ZegKXhFU .ulp-submit:visited {
    background: linear-gradient(#487826, #56912d) repeat scroll 0 0 #56912d;
    border: 1px solid #56912d;
    border-radius: 2px !important;
}
#ulp-layer-215, #ulp-layer-215 p, #ulp-layer-215 a, #ulp-layer-215 span, #ulp-layer-215 li, #ulp-layer-215 input, #ulp-layer-215 button, #ulp-layer-215 textarea {
    color: #ffffff;
    font-family: "arial",arial;
    font-weight: 400;
    text-shadow: 1px 1px 1px #000000;
}
.ulp-window a {
    text-decoration: none !important;
}
.ulp-submit, .ulp-submit:visited, .ulp-submit-button, .ulp-submit-button:visited {
    border-radius: 2px;
    box-shadow: none;
    cursor: pointer;
    display: inline-block;
    font-size: inherit !important;
    height: auto;
    line-height: 1.5;
    margin: 0;
    padding: 5px 20px;
    position: relative;
    text-decoration: none !important;
    transition-duration: 0.3s;
    white-space: nowrap;
    width: auto;
	background: linear-gradient(#487826, #56912d) repeat scroll 0 0 #56912d;
    border: 1px solid #56912d;
    border-radius: 2px !important;
}
a, a:active, a:hover {
    outline: medium none;
}
.fa-sign-out:before {
    content: "";
}
.fa {
    display: inline-block;
    font-family: FontAwesome;
    font-feature-settings: normal;
    font-kerning: auto;
    font-language-override: normal;
    font-size: inherit;
    font-size-adjust: none;
    font-stretch: normal;
    font-style: normal;
    font-synthesis: weight style;
    font-variant: normal;
    font-weight: normal;
    line-height: 1;
    text-rendering: auto;
}
#ulp-layer-215, #ulp-layer-215 p, #ulp-layer-215 a, #ulp-layer-215 span, #ulp-layer-215 li, #ulp-layer-215 input, #ulp-layer-215 button, #ulp-layer-215 textarea {
    color: #ffffff;
    text-shadow: 1px 1px 1px #000000;
}
.ulp-submit, .ulp-submit:visited, .ulp-submit-button, .ulp-submit-button:visited {
    cursor: pointer;
    font-size: inherit !important;
    white-space: nowrap;
}
#ulp-layer-216 {
    text-align: left;
    z-index: 1000007;
}
#ulp-layer-216, #ulp-layer-216 p, #ulp-layer-216 a, #ulp-layer-216 span, #ulp-layer-216 li, #ulp-layer-216 input, #ulp-layer-216 button, #ulp-layer-216 textarea {
    color: #ffffff;
    font-family: "arial",arial;
    font-weight: 400;
}
.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}
#ulp-layer-217 {
    text-align: right;
    z-index: 1000007;
}
#ulp-layer-217, #ulp-layer-217 p, #ulp-layer-217 a, #ulp-layer-217 span, #ulp-layer-217 li, #ulp-layer-217 input, #ulp-layer-217 button, #ulp-layer-217 textarea {
    color: #ffffff;
    font-family: "arial",arial;
    font-weight: 400;
    text-shadow: 1px 1px 1px #000000;
}
.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}
#ulp-layer-217, #ulp-layer-217 p, #ulp-layer-217 a, #ulp-layer-217 span, #ulp-layer-217 li, #ulp-layer-217 input, #ulp-layer-217 button, #ulp-layer-217 textarea {
    color: #ffffff;
    font-family: "arial",arial;
    font-weight: 400;
    text-shadow: 1px 1px 1px #000000;
}
.ulp-window a {
    text-decoration: none !important;
}
a, .contactForm input[type="text"]:focus, .contactForm input[type="email"]:focus, .contactForm textarea:focus, input#formSubmit, .errorForm, #subscribe input[type="email"]:focus, .errorSubs, .servSingle, #toTop i, #notForm input[type="email"]:focus, .contactForm input#submit, #loginForm input, #loginForm input[type="text"]:focus, #loginForm input[type="password"]:focus {
    transition: all 0.5s ease 0s;
}
a, a:active, a:hover {
    outline: medium none;
}
	
ul.ulp-sf3-popup {margin: 0 !important; padding: 0 !important; list-style: none !important;}
ul.ulp-sf3-popup li {padding: 0 !important; margin: 0 !important; text-indent: 0 !important; line-height: 1.8 !important;}
ul.ulp-sf3-popup li:before {content: "● " !important; color: #56912d; margin-right: 10px !important;}

</style>

 
<div id='popupform_preview' style="display:none;"><div class="ulp-content" style="z-index:99999;width: 700px; height: 360px; margin:auto;position:fixed; left:30%; top:15%;">
							<div id="ulp-layer-205" class="ulp-layer animated bounceInLeft" style="width: 640px; height: 360px; font-size: 14px; left: 0px; top: 0px;"></div>
							<div id="ulp-layer-206" class="ulp-layer " style="width: 640px; height: 360px; font-size: 14px; left: 0px; top: 0px;"></div>
							<div id="ulp-layer-207" class="ulp-layer animated fadeInLeftBig" style="width: 580px; font-size: 28px; left: 30px; top: 20px;">Do you want more traffic?</div>
							<div id="ulp-layer-208" class="ulp-layer animated fadeInLeft" style="width: 350px; font-size: 14px; left: 30px; top: 60px;">Dignissim enim porta aliquam nisi pellentesque. Pulvinar rhoncus
magnis turpis sit odio pid pulvinar mattis integer aliquam!</div>
							<div id="ulp-layer-209" class="ulp-layer animated fadeInLeft" style="width: 420px; font-size: 14px; left: 30px; top: 130px;">
<ul class="ulp-sf3-popup">
<li>Goblinus globalus fantumo tubus dia montes </li>
<li>Scelerisque cursus dignissim lopatico vutario</li>
<li>Montes vutario lacus quis preambul den lacus </li>
<li>Leftomato denitro oculus softam lorum quis </li>
<li>Spiratio dodenus christmas gulleria tix digit </li>
<li>Dualo fitemus lacus quis preambul pat turtulis</li>
<li>Scelerisque cursus dignissim lopatico vutario</li>
<li>Montes vutario lacus quis preambul den lacus </li>
</ul></div>
							<div id="ulp-layer-210" class="ulp-layer animated fadeInRightBig" style="width: 300px; height: 400px; font-size: 14px; left: 400px; top: -20px;"></div>
							<div id="ulp-layer-211" class="ulp-layer" style="width: 300px; height: 400px; font-size: 14px; left: 400px; top: -20px;"></div>
							<div id="ulp-layer-212" class="ulp-layer animated fadeInRight" style="width: 260px; font-size: 25px; left: 420px; top: 20px;">SUBSCRIBE TO OUR NEWSLETTER AND START INCREASING YOUR PROFITS NOW!</div>
							<div id="ulp-layer-213" class="ulp-layer animated zoomInLeft" style="width: 260px; height: 36px; font-size: 14px; left: 420px; top: 205px;"><input type="text" onfocus="jQuery(this).removeClass('ulp-input-error');" value="" placeholder="Enter your name..." name="ulp-name" class="ulp-input"><div class="ulp-fa-input-table" style="left:12px;"><div class="ulp-fa-input-cell"><i class="fa fa-user"></i></div></div></div>
							<div id="ulp-layer-214" class="ulp-layer animated zoomInRight" style="width: 260px; height: 36px; font-size: 14px; left: 420px; top: 250px;"><input type="text" onfocus="jQuery(this).removeClass('ulp-input-error');" value="" placeholder="Enter your e-mail..." name="ulp-email" class="ulp-input"><div class="ulp-fa-input-table"><div class="ulp-fa-input-cell"><i class="fa fa-envelope"></i></div></div></div>
							<div id="ulp-layer-215" class="ulp-layer animated bounceInLeft" style="width: 300px; height: 38px; font-size: 15px; left: 400px; top: 300px;"><a data-loading="Loading..." data-label="SUBSCRIBE NOW" data-icon="fa-sign-out" onclick="return ulp_subscribe(this);" class="ulp-submit"><i class="fa fa-sign-out"></i>&nbsp; SUBSCRIBE NOW</a></div>
							<div id="ulp-layer-216" class="ulp-layer animated bounceIn" style="width: 280px; font-size: 12px; left: 420px; top: 350px;">* we never share your e-mail with third parties.</div>
							<div id="ulp-layer-217" class="ulp-layer" style="width: 40px; height: 20px; font-size: 24px; left: 655px; top: -25px;"><a onclick="return ulp_self_close();" href="#">×</a></div>
						</div>
						
						<div id="blackscreen" style='width:100%; height:100%; background:#000; opacity:0.7; top:0; left:0; position:fixed; z-index:20000; display:none;'></div>
						</div>
						
						
										                        <script>
function ulp_self_close()
{
	$("#popupform_preview").hide();
	$("#blackscreen").hide();
	$("#popup_content_data").html('');
}
</script>  		
				
						
						