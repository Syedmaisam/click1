<link rel="stylesheet" href="http://www.cliks.it/click/views/layered/animatemaster/animate.min.css">
<style>
body
{
margin:0px;
padding:0px;
}
.ulp-content {
    position: relative;
}
#ulp-layer-184 {
    background-color: rgba(32, 54, 129, 1);
    border-radius: 5px;
    box-shadow: 0 4px 20px rgba(32, 32, 32, 1);
    overflow: hidden;
    text-align: left;
    z-index: 1000003;
}
#ulp-layer-184, #ulp-layer-184 p, #ulp-layer-184 a, #ulp-layer-184 span, #ulp-layer-184 li, #ulp-layer-184 input, #ulp-layer-184 button, #ulp-layer-184 textarea {
    color: #000000;
    font-family: "arial",arial;
    font-weight: 400;
    text-shadow: 1px 1px 1px #ffffff;
}
.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}
#ulp-layer-185 {
    text-align: center;
    z-index: 1000006;
}
#ulp-layer-185, #ulp-layer-185 p, #ulp-layer-185 a, #ulp-layer-185 span, #ulp-layer-185 li, #ulp-layer-185 input, #ulp-layer-185 button, #ulp-layer-185 textarea {
    color: #ffffff;
    font-family: "arial",arial;
    font-weight: 400;
    text-shadow: 1px 1px 1px #000000;
}
.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}
#ulp-layer-186 {
    text-align: justify;
    z-index: 1000007;
}
#ulp-layer-186, #ulp-layer-186 p, #ulp-layer-186 a, #ulp-layer-186 span, #ulp-layer-186 li, #ulp-layer-186 input, #ulp-layer-186 button, #ulp-layer-186 textarea {
    color: #ffffff;
    font-family: "arial",arial;
    font-weight: 400;
    text-shadow: 1px 1px 1px #000000;
}
.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}
#ulp-layer-187 {
    text-align: justify;
    z-index: 1000007;
}
#ulp-layer-187, #ulp-layer-187 p, #ulp-layer-187 a, #ulp-layer-187 span, #ulp-layer-187 li, #ulp-layer-187 input, #ulp-layer-187 button, #ulp-layer-187 textarea {
    color: #ffffff;
    font-family: "arial",arial;
    font-weight: 400;
    text-shadow: 1px 1px 1px #000000;
}
.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}
#ulp-layer-187 {
    text-align: justify;
}
#ulp-layer-187, #ulp-layer-187 p, #ulp-layer-187 a, #ulp-layer-187 span, #ulp-layer-187 li, #ulp-layer-187 input, #ulp-layer-187 button, #ulp-layer-187 textarea {
    color: #ffffff;
    font-family: "arial",arial;
    font-weight: 400;
    text-shadow: 1px 1px 1px #000000;
}
.ulp-layer {
    line-height: 1.475;
}
ul.ulp-901 {
    list-style: outside none none !important;
    margin: 0 !important;
    padding: 0 !important;
}
html, body, div, section, article, aside, header, hgroup, footer, nav, h1, h2, h3, h4, h5, h6, p, a, blockquote, address, time, span, em, strong, img, ol, ul, li, figure, canvas, video, th, td, tr, iframe {
    border: 0 none;
    font: inherit;
    list-style: outside none none;
    margin: 0;
    padding: 0;
    text-decoration: none;
    vertical-align: baseline;
}
ul, menu, dir {
    display: block;
}
#ulp-layer-187 {
    text-align: justify;
}
#ulp-layer-187, #ulp-layer-187 p, #ulp-layer-187 a, #ulp-layer-187 span, #ulp-layer-187 li, #ulp-layer-187 input, #ulp-layer-187 button, #ulp-layer-187 textarea {
    color: #ffffff;
    text-shadow: 1px 1px 1px #000000;
}
#ulp-layer-188 {
    background-color: rgba(202, 50, 49, 1);
    border-radius: 5px;
    box-shadow: 0 4px 20px rgba(32, 32, 32, 1);
    overflow: hidden;
    text-align: left;
    z-index: 1000003;
}
#ulp-layer-188, #ulp-layer-188 p, #ulp-layer-188 a, #ulp-layer-188 span, #ulp-layer-188 li, #ulp-layer-188 input, #ulp-layer-188 button, #ulp-layer-188 textarea {
    color: #000000;
    font-family: "arial",arial;
    font-weight: 400;
}
.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}
#ulp-layer-189 {
    text-align: justify;
    z-index: 1000007;
}
#ulp-layer-189, #ulp-layer-189 p, #ulp-layer-189 a, #ulp-layer-189 span, #ulp-layer-189 li, #ulp-layer-189 input, #ulp-layer-189 button, #ulp-layer-189 textarea {
    color: #000000;
    font-family: "arial",arial;
    font-weight: 400;
}
.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}
#ulp-layer-189 input.ulp-input {
    padding-left: 32px !important;
}
#ulp-5w8FtbwC1Ui9LJ1U .ulp-input, #ulp-5w8FtbwC1Ui9LJ1U .ulp-input:hover, #ulp-5w8FtbwC1Ui9LJ1U .ulp-input:active, #ulp-5w8FtbwC1Ui9LJ1U .ulp-input:focus {
    background-color: rgba(255, 255, 255, 1) !important;
    border-color: #ffffff;
    border-radius: 2px !important;
    border-width: 1px !important;
}
#ulp-layer-189, #ulp-layer-189 p, #ulp-layer-189 a, #ulp-layer-189 span, #ulp-layer-189 li, #ulp-layer-189 input, #ulp-layer-189 button, #ulp-layer-189 textarea {
    color: #000000;
    font-family: "arial",arial;
    font-weight: 400;
}
.ulp-input {
    background: none repeat scroll 0 0 rgba(255, 255, 255, 0.8);
    border-radius: 2px !important;
    border-spacing: 0 !important;
    border-style: solid !important;
    border-width: 1px !important;
    box-shadow: none !important;
    box-sizing: border-box !important;
    clear: both !important;
    font-size: inherit !important;
    height: 100% !important;
    line-height: 1.5 !important;
    margin: 0 !important;
    padding: 0 6px !important;
    vertical-align: middle !important;
    width: 100% !important;
}
input:-moz-read-write, textarea:-moz-read-write {
    -moz-user-modify: read-write !important;
}
input {
    -moz-appearance: textfield;
    -moz-binding: url("chrome://global/content/platformHTMLBindings.xml#inputFields");
    -moz-user-select: text;
    cursor: text;
    font: ;
    letter-spacing: normal;
    line-height: normal;
    padding: 1px;
    text-align: start;
    text-indent: 0;
    text-rendering: optimizelegibility;
    text-shadow: none;
    text-transform: none;
    word-spacing: normal;
}
textarea > .anonymous-div, input > .anonymous-div, input::-moz-placeholder, textarea::-moz-placeholder, *|*::-moz-button-content, *|*::-moz-display-comboboxcontrol-frame, optgroup:before {
    text-overflow: inherit;
    unicode-bidi: inherit;
}
input::-moz-placeholder, textarea::-moz-placeholder {
    display: inline-block !important;
    opacity: 0.54;
    overflow: hidden !important;
    pointer-events: none !important;
    resize: none !important;
}
textarea > .anonymous-div, input > .anonymous-div, input::-moz-placeholder, textarea::-moz-placeholder {
    -moz-control-character-visibility: visible;
    border: 0 none !important;
    display: inline-block;
    ime-mode: inherit;
    margin: 0;
    overflow: auto;
    padding: inherit !important;
    resize: inherit;
    text-decoration: inherit;
    white-space: pre;
}
input > .anonymous-div, input::-moz-placeholder {
    line-height: -moz-block-height;
    word-wrap: normal !important;
}
element.style {
    font-size: 13px;
}

.ulp-fa-input-table {
    display: table;
    height: 100%;
    left: 0;
    line-height: 100%;
    position: absolute;
    top: 0;
    vertical-align: middle;
}
#ulp-layer-189 div.ulp-fa-input-cell {
    padding-left: 4px !important;
    width: 28px !important;
}
.ulp-fa-input-cell {
    display: table-cell;
    opacity: 0.7;
    text-align: center;
    vertical-align: middle;
}
.fa-user:before {
    content: "";
}
.fa {
    display: inline-block;
    font-family: FontAwesome;
    font-feature-settings: normal;
    font-kerning: auto;
    font-language-override: normal;
    font-size: inherit;
    font-size-adjust: none;
    font-stretch: normal;
    font-style: normal;
    font-synthesis: weight style;
    font-variant: normal;
    font-weight: normal;
    line-height: 1;
    text-rendering: auto;
}
#ulp-layer-190 {
    text-align: justify;
    z-index: 1000007;
}
#ulp-layer-190, #ulp-layer-190 p, #ulp-layer-190 a, #ulp-layer-190 span, #ulp-layer-190 li, #ulp-layer-190 input, #ulp-layer-190 button, #ulp-layer-190 textarea {
    color: #000000;
    font-family: "arial",arial;
    font-weight: 400;
}
.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}

#ulp-layer-190 input.ulp-input {
    padding-left: 32px !important;
}
#ulp-5w8FtbwC1Ui9LJ1U .ulp-input, #ulp-5w8FtbwC1Ui9LJ1U .ulp-input:hover, #ulp-5w8FtbwC1Ui9LJ1U .ulp-input:active, #ulp-5w8FtbwC1Ui9LJ1U .ulp-input:focus {
    background-color: rgba(255, 255, 255, 1) !important;
    border-color: #ffffff;
    border-radius: 2px !important;
    border-width: 1px !important;
}
#ulp-layer-190, #ulp-layer-190 p, #ulp-layer-190 a, #ulp-layer-190 span, #ulp-layer-190 li, #ulp-layer-190 input, #ulp-layer-190 button, #ulp-layer-190 textarea {
    color: #000000;
    font-family: "arial",arial;
    font-weight: 400;
}
.ulp-input {
    background: none repeat scroll 0 0 rgba(255, 255, 255, 0.8);
    border-radius: 2px !important;
    border-spacing: 0 !important;
    border-style: solid !important;
    border-width: 1px !important;
    box-shadow: none !important;
    box-sizing: border-box !important;
    clear: both !important;
    font-size: inherit !important;
    height: 100% !important;
    line-height: 1.5 !important;
    margin: 0 !important;
    padding: 0 6px !important;
    vertical-align: middle !important;
    width: 100% !important;
}
input:-moz-read-write, textarea:-moz-read-write {
    -moz-user-modify: read-write !important;
}
input {
    -moz-appearance: textfield;
    -moz-binding: url("chrome://global/content/platformHTMLBindings.xml#inputFields");
    -moz-user-select: text;
    cursor: text;
    font: ;
    letter-spacing: normal;
    line-height: normal;
    padding: 1px;
    text-align: start;
    text-indent: 0;
    text-rendering: optimizelegibility;
    text-shadow: none;
    text-transform: none;
    word-spacing: normal;
}
textarea > .anonymous-div, input > .anonymous-div, input::-moz-placeholder, textarea::-moz-placeholder, *|*::-moz-button-content, *|*::-moz-display-comboboxcontrol-frame, optgroup:before {
    text-overflow: inherit;
    unicode-bidi: inherit;
}
input::-moz-placeholder, textarea::-moz-placeholder {
    display: inline-block !important;
    opacity: 0.54;
    overflow: hidden !important;
    pointer-events: none !important;
    resize: none !important;
}
textarea > .anonymous-div, input > .anonymous-div, input::-moz-placeholder, textarea::-moz-placeholder {
    -moz-control-character-visibility: visible;
    border: 0 none !important;
    display: inline-block;
    ime-mode: inherit;
    margin: 0;
    overflow: auto;
    padding: inherit !important;
    resize: inherit;
    text-decoration: inherit;
    white-space: pre;
}
input > .anonymous-div, input::-moz-placeholder {
    line-height: -moz-block-height;
    word-wrap: normal !important;
}

.ulp-fa-input-table {
    display: table;
    height: 100%;
    left: 0;
    line-height: 100%;
    position: absolute;
    top: 0;
    vertical-align: middle;
}

#ulp-layer-190 div.ulp-fa-input-cell {
    padding-left: 4px !important;
    width: 28px !important;
}
.ulp-fa-input-cell {
    display: table-cell;
    opacity: 0.7;
    text-align: center;
    vertical-align: middle;
}
.fa-envelope:before {
    content: "";
}
.fa {
    display: inline-block;
    font-family: FontAwesome;
    font-feature-settings: normal;
    font-kerning: auto;
    font-language-override: normal;
    font-size: inherit;
    font-size-adjust: none;
    font-stretch: normal;
    font-style: normal;
    font-synthesis: weight style;
    font-variant: normal;
    font-weight: normal;
    line-height: 1;
    text-rendering: auto;
}
#ulp-layer-191 {
    text-align: center;
    z-index: 1000007;
}
#ulp-layer-191, #ulp-layer-191 p, #ulp-layer-191 a, #ulp-layer-191 span, #ulp-layer-191 li, #ulp-layer-191 input, #ulp-layer-191 button, #ulp-layer-191 textarea {
    color: #ffffff;
    font-family: "arial",arial;
    font-weight: 400;
    text-shadow: 1px 1px 1px #000000;
}
.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}
#ulp-5w8FtbwC1Ui9LJ1U .ulp-submit, #ulp-5w8FtbwC1Ui9LJ1U .ulp-submit:visited {
    background: linear-gradient(#46b0d0, #4dc2e5) repeat scroll 0 0 #4dc2e5;
    border: 1px solid #4dc2e5;
    border-radius: 2px !important;
}
#ulp-layer-191, #ulp-layer-191 p, #ulp-layer-191 a, #ulp-layer-191 span, #ulp-layer-191 li, #ulp-layer-191 input, #ulp-layer-191 button, #ulp-layer-191 textarea {
    color: #ffffff;
    font-family: "arial",arial;
    font-weight: 400;
    text-shadow: 1px 1px 1px #000000;
}
.ulp-window a {
    text-decoration: none !important;
}
.ulp-submit, .ulp-submit:visited, .ulp-submit-button, .ulp-submit-button:visited {
    border-radius: 2px;
    box-shadow: none;
    cursor: pointer;
    display: inline-block;
    font-size: inherit !important;
    height: auto;
    line-height: 1.5;
    margin: 0;
    padding: 5px 20px;
    position: relative;
    text-decoration: none !important;
    transition-duration: 0.3s;
    white-space: nowrap;
    width: auto;
}
a, a:active, a:hover {
    outline: medium none;
}
.fa-edit:before, .fa-pencil-square-o:before {
    content: "";
}
.fa {
    display: inline-block;
    font-family: FontAwesome;
    font-feature-settings: normal;
    font-kerning: auto;
    font-language-override: normal;
    font-size: inherit;
    font-size-adjust: none;
    font-stretch: normal;
    font-style: normal;
    font-synthesis: weight style;
    font-variant: normal;
    font-weight: normal;
    line-height: 1;
    text-rendering: auto;
}
#ulp-layer-191, #ulp-layer-191 p, #ulp-layer-191 a, #ulp-layer-191 span, #ulp-layer-191 li, #ulp-layer-191 input, #ulp-layer-191 button, #ulp-layer-191 textarea {
    color: #ffffff;
    text-shadow: 1px 1px 1px #000000;
}
.ulp-submit, .ulp-submit:visited, .ulp-submit-button, .ulp-submit-button:visited {
    cursor: pointer;
    font-size: inherit !important;
    white-space: nowrap;
}
#ulp-layer-191 {
    text-align: center;
}
#ulp-layer-192 {
    text-align: right;
    z-index: 1000007;
}
#ulp-layer-192, #ulp-layer-192 p, #ulp-layer-192 a, #ulp-layer-192 span, #ulp-layer-192 li, #ulp-layer-192 input, #ulp-layer-192 button, #ulp-layer-192 textarea {
    color: #ffffff;
    font-family: "arial",arial;
    font-weight: 400;
    text-shadow: 1px 1px 1px #000000;
}
.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}
#ulp-layer-192, #ulp-layer-192 p, #ulp-layer-192 a, #ulp-layer-192 span, #ulp-layer-192 li, #ulp-layer-192 input, #ulp-layer-192 button, #ulp-layer-192 textarea {
    color: #ffffff;
    font-family: "arial",arial;
    font-weight: 400;
    text-shadow: 1px 1px 1px #000000;
}
.ulp-window a {
    text-decoration: none !important;
}
#ulp-layer-193 {
    text-align: center;
    z-index: 1000006;
}
#ulp-layer-193, #ulp-layer-193 p, #ulp-layer-193 a, #ulp-layer-193 span, #ulp-layer-193 li, #ulp-layer-193 input, #ulp-layer-193 button, #ulp-layer-193 textarea {
    color: #ffffff;
    font-family: "arial",arial;
    font-weight: 400;
    text-shadow: 1px 1px 1px #000000;
}
.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}
ul.ulp-901 {margin: 0 !important; padding: 0 !important; list-style: none !important;}
ul.ulp-901 li {padding: 0 !important; margin: 0 !important; text-indent: 0 !important; line-height: 1.8 !important;}
ul.ulp-901 li:before {content: "● " !important; color: #FFDB2F; margin-right: 10px !important;}

</style>

 
<div id='popupform_preview' style="display:none;"><div class="ulp-content" style="z-index:99999;width: 595px; height: 397px; margin:auto;position:fixed; left:30%; top:15%;">
							<div id="ulp-layer-184" class="ulp-layer " style="width: 476px; height: 397px; font-size: 13px; left: 119px; top: 0px; display: block;"></div>
							<div id="ulp-layer-185" class="ulp-layer animated fadeInLeftBig" style="width: 436px; font-size: 19px; left: 138px; top: 19px;">SUBSCRIBE TO NEWSLETTER</div>
							<div id="ulp-layer-186" class="ulp-layer animated fadeInRightBig" style="width: 436px; font-size: 13px; left: 138px; top: 59px;">Dolor aliquet augue augue sit magnis, magna aenean aenean et! Et tempor, facilisis cursus turpis tempor odio, cursus montes ac turpis. Ultrices! Massa integer augue ridiculus adipiscing, massa cras pid. Turpis placerat scelerisque, vut odio mus non, mattis porttitor, nunc odio, turpis tortor sit? Pid amet, sed facilisis.</div>
							<div id="ulp-layer-187" class="ulp-layer animated fadeInRight" style="width: 436px; font-size: 13px; left: 312px; top: 173px;">
<ul class="ulp-901">
<li>Goblinus globalus fantumo tandempo</li>
<li>Scelerisque cursus dignissim donus</li>
<li>Montes vutario lacus quis arcupolisio</li>
<li>Leftomato denitro oculus tepircos den</li>
<li>Spiratio dodenus christmas popupius</li>
<li>Afrenius globalus spiritum tandempo</li>
<li>Fitatos vutario lacus quis arcup delis</li>
</ul></div>
							<div id="ulp-layer-188" class="ulp-layer animated fadeInDown" style="width: 297px; height: 163px; font-size: 13px; left: 0px; top: 178px;"></div>
							<div id="ulp-layer-189" class="ulp-layer animated fadeInUp" style="width: 258px; height: 36px; font-size: 13px; left: 19px; top: 198px;"><input type="text" onfocus="jQuery(this).removeClass('ulp-input-error');" value="" placeholder="Enter your name..." name="ulp-name" class="ulp-input"><div class="ulp-fa-input-table"><div class="ulp-fa-input-cell"><i class="fa fa-user"></i></div></div></div>
							<div id="ulp-layer-190" class="ulp-layer animated fadeInUp" style="width: 258px; height: 36px; font-size: 13px; left: 19px; top: 243px;"><input type="text" onfocus="jQuery(this).removeClass('ulp-input-error');" value="" placeholder="Enter your e-mail..." name="ulp-email" class="ulp-input"><div class="ulp-fa-input-table"><div class="ulp-fa-input-cell"><i class="fa fa-envelope"></i></div></div></div>
							<div id="ulp-layer-191" class="ulp-layer animated zoomInDown" style="width: 258px; height: 37px; font-size: 14px; left: 19px; top: 287px;"><a data-loading="Loading..." data-label="Subscribe" data-icon="fa-pencil-square-o" onclick="return ulp_subscribe(this);" class="ulp-submit"><i class="fa fa-pencil-square-o"></i>&nbsp; Subscribe</a></div>
							<div id="ulp-layer-192" class="ulp-layer" style="width: 39px; height: 19px; font-size: 23px; left: 555px; top: -29px;"><a onclick="return ulp_self_close();" href="#">×</a></div>
							<div id="ulp-layer-193" class="ulp-layer animated zoomInDown" style="width: 436px; font-size: 11px; left: 138px; top: 372px;">All rights reserved &copy; Company Name, 2014</div>
						</div>

						
						<div id="blackscreen" style='width:100%; height:100%; background:#000; opacity:0.7; top:0; left:0; position:fixed; z-index:20000; display:none;'></div>
						</div>
						
						                        <script>
function ulp_self_close()
{
	$("#popupform_preview").hide();
	$("#blackscreen").hide();
	$("#popup_content_data").html('');
}
</script>  
						
						