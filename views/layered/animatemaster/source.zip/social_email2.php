<link rel="stylesheet" href="<?php echo SITE_ROOT_URL; ?>views/layered/animatemaster/animate.min.css">
<script type="text/javascript" src="<?php echo SITE_ROOT_URL; ?>colorjs/jscolor.js"></script>
<style>
body
{
margin:0px;
padding:0px;
}
.ulp-content {
    position: relative;
}
#ulp-layer-348 {
    background-color: rgba(30, 115, 190, 1);
    background-image: url("https://layeredpopups.com/layered-popups/images/default/transparent-squares.png");
    background-repeat: repeat;
    box-shadow: 0 4px 20px rgba(32, 32, 32, 1);
    text-align: left;
    transform: rotate(-3deg);
    z-index: 1000007;
}
#ulp-layer-348, #ulp-layer-348 p, #ulp-layer-348 a, #ulp-layer-348 span, #ulp-layer-348 li, #ulp-layer-348 input, #ulp-layer-348 button, #ulp-layer-348 textarea {
    color: #000000;
    font-family: "arial",arial;
    font-weight: 400;
}
.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}
#ulp-layer-349 {
    background-color: rgba(230, 226, 77, 1);
    padding: 5px 0;
    text-align: center;
    z-index: 1000007;
}
#ulp-layer-349, #ulp-layer-349 p, #ulp-layer-349 a, #ulp-layer-349 span, #ulp-layer-349 li, #ulp-layer-349 input, #ulp-layer-349 button, #ulp-layer-349 textarea {
    color: #ffffff;
    font-family: "arial",arial;
    font-weight: 700;
}
.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}
#ulp-layer-350 {
    text-align: left;
    transform: rotate(-2deg);
    z-index: 1000007;
}
#ulp-layer-350, #ulp-layer-350 p, #ulp-layer-350 a, #ulp-layer-350 span, #ulp-layer-350 li, #ulp-layer-350 input, #ulp-layer-350 button, #ulp-layer-350 textarea {
    color: #000000;
    font-family: "arial",arial;
    font-weight: 400;
}
.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}
#ulp-layer-350 input.ulp-input {
    padding-left: 36px !important;
}
#ulp-SU1xVylD2bJJSNiZ .ulp-input, #ulp-SU1xVylD2bJJSNiZ .ulp-input:hover, #ulp-SU1xVylD2bJJSNiZ .ulp-input:active, #ulp-SU1xVylD2bJJSNiZ .ulp-input:focus {
    background-color: rgba(255, 255, 255, 1) !important;
    border-color: #ffffff;
    border-radius: 2px !important;
    border-width: 1px !important;
}
#ulp-layer-350, #ulp-layer-350 p, #ulp-layer-350 a, #ulp-layer-350 span, #ulp-layer-350 li, #ulp-layer-350 input, #ulp-layer-350 button, #ulp-layer-350 textarea {
    color: #000000;
    font-family: "arial",arial;
    font-weight: 400;
}
.ulp-input {
    background: none repeat scroll 0 0 rgba(255, 255, 255, 0.8);
    border-radius: 2px !important;
    border-spacing: 0 !important;
    border-style: solid !important;
    border-width: 1px !important;
    box-shadow: none !important;
    box-sizing: border-box !important;
    clear: both !important;
    font-size: inherit !important;
    height: 100% !important;
    line-height: 1.5 !important;
    margin: 0 !important;
    padding: 0 6px !important;
    vertical-align: middle !important;
    width: 100% !important;
}
input:-moz-read-write, textarea:-moz-read-write {
    -moz-user-modify: read-write !important;
}
input {
    -moz-appearance: textfield;
    -moz-binding: url("chrome://global/content/platformHTMLBindings.xml#inputFields");
    -moz-user-select: text;
    cursor: text;
    font: ;
    letter-spacing: normal;
    line-height: normal;
    padding: 1px;
    text-align: start;
    text-indent: 0;
    text-rendering: optimizelegibility;
    text-shadow: none;
    text-transform: none;
    word-spacing: normal;
}
textarea > .anonymous-div, input > .anonymous-div, input::-moz-placeholder, textarea::-moz-placeholder, *|*::-moz-button-content, *|*::-moz-display-comboboxcontrol-frame, optgroup:before {
    text-overflow: inherit;
    unicode-bidi: inherit;
}
input::-moz-placeholder, textarea::-moz-placeholder {
    display: inline-block !important;
    opacity: 0.54;
    overflow: hidden !important;
    pointer-events: none !important;
    resize: none !important;
}
textarea > .anonymous-div, input > .anonymous-div, input::-moz-placeholder, textarea::-moz-placeholder {
    -moz-control-character-visibility: visible;
    border: 0 none !important;
    display: inline-block;
    ime-mode: inherit;
    margin: 0;
    overflow: auto;
    padding: inherit !important;
    resize: inherit;
    text-decoration: inherit;
    white-space: pre;
}
input > .anonymous-div, input::-moz-placeholder {
    line-height: -moz-block-height;
    word-wrap: normal !important;
}

.ulp-fa-input-table {
    display: table;
    height: 100%;
    left: 0;
    line-height: 100%;
    position: absolute;
    top: 0;
    vertical-align: middle;
}
#ulp-layer-350 div.ulp-fa-input-cell {
    padding-left: 4px !important;
    width: 32px !important;
}
.ulp-fa-input-cell {
    display: table-cell;
    opacity: 0.7;
    text-align: center;
    vertical-align: middle;
}
.fa-user:before {
    content: "";
}
.fa-user:before {
    content: "";
}
.fa {
    display: inline-block;
    font-family: FontAwesome;
    font-feature-settings: normal;
    font-kerning: auto;
    font-language-override: normal;
    font-size: inherit;
    font-size-adjust: none;
    font-stretch: normal;
    font-style: normal;
    font-synthesis: weight style;
    font-variant: normal;
    font-weight: normal;
    line-height: 1;
    text-rendering: auto;
}
.ulp-fa-input-cell {
    text-align: center;
}
#ulp-layer-351 {
    text-align: left;
    transform: rotate(2deg);
    z-index: 1000007;
}
#ulp-layer-351, #ulp-layer-351 p, #ulp-layer-351 a, #ulp-layer-351 span, #ulp-layer-351 li, #ulp-layer-351 input, #ulp-layer-351 button, #ulp-layer-351 textarea {
    color: #000000;
    font-family: "arial",arial;
    font-weight: 400;
}
.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}
#ulp-layer-351 input.ulp-input {
    padding-left: 36px !important;
}
#ulp-SU1xVylD2bJJSNiZ .ulp-input, #ulp-SU1xVylD2bJJSNiZ .ulp-input:hover, #ulp-SU1xVylD2bJJSNiZ .ulp-input:active, #ulp-SU1xVylD2bJJSNiZ .ulp-input:focus {
    background-color: rgba(255, 255, 255, 1) !important;
    border-color: #ffffff;
    border-radius: 2px !important;
    border-width: 1px !important;
}
#ulp-layer-351, #ulp-layer-351 p, #ulp-layer-351 a, #ulp-layer-351 span, #ulp-layer-351 li, #ulp-layer-351 input, #ulp-layer-351 button, #ulp-layer-351 textarea {
    color: #000000;
    font-family: "arial",arial;
    font-weight: 400;
}
.ulp-input {
    background: none repeat scroll 0 0 rgba(255, 255, 255, 0.8);
    border-radius: 2px !important;
    border-spacing: 0 !important;
    border-style: solid !important;
    border-width: 1px !important;
    box-shadow: none !important;
    box-sizing: border-box !important;
    clear: both !important;
    font-size: inherit !important;
    height: 100% !important;
    line-height: 1.5 !important;
    margin: 0 !important;
    padding: 0 6px !important;
    vertical-align: middle !important;
    width: 100% !important;
}
input:-moz-read-write, textarea:-moz-read-write {
    -moz-user-modify: read-write !important;
}
input {
    -moz-appearance: textfield;
    -moz-binding: url("chrome://global/content/platformHTMLBindings.xml#inputFields");
    -moz-user-select: text;
    cursor: text;
    font: ;
    letter-spacing: normal;
    line-height: normal;
    padding: 1px;
    text-align: start;
    text-indent: 0;
    text-rendering: optimizelegibility;
    text-shadow: none;
    text-transform: none;
    word-spacing: normal;
}
textarea > .anonymous-div, input > .anonymous-div, input::-moz-placeholder, textarea::-moz-placeholder, *|*::-moz-button-content, *|*::-moz-display-comboboxcontrol-frame, optgroup:before {
    text-overflow: inherit;
    unicode-bidi: inherit;
}
input::-moz-placeholder, textarea::-moz-placeholder {
    display: inline-block !important;
    opacity: 0.54;
    overflow: hidden !important;
    pointer-events: none !important;
    resize: none !important;
}
textarea > .anonymous-div, input > .anonymous-div, input::-moz-placeholder, textarea::-moz-placeholder {
    -moz-control-character-visibility: visible;
    border: 0 none !important;
    display: inline-block;
    ime-mode: inherit;
    margin: 0;
    overflow: auto;
    padding: inherit !important;
    resize: inherit;
    text-decoration: inherit;
    white-space: pre;
}
input > .anonymous-div, input::-moz-placeholder {
    line-height: -moz-block-height;
    word-wrap: normal !important;
}

.ulp-fa-input-table {
    display: table;
    height: 100%;
    left: 0;
    line-height: 100%;
    position: absolute;
    top: 0;
    vertical-align: middle;
}
#ulp-layer-351 div.ulp-fa-input-cell {
    padding-left: 4px !important;
    width: 32px !important;
}
.ulp-fa-input-cell {
    display: table-cell;
    opacity: 0.7;
    text-align: center;
    vertical-align: middle;
}
.fa-envelope:before {
    content: "";
}
.fa-envelope:before {
    content: "";
}
.fa {
    display: inline-block;
    font-family: FontAwesome;
    font-feature-settings: normal;
    font-kerning: auto;
    font-language-override: normal;
    font-size: inherit;
    font-size-adjust: none;
    font-stretch: normal;
    font-style: normal;
    font-synthesis: weight style;
    font-variant: normal;
    font-weight: normal;
    line-height: 1;
    text-rendering: auto;
}
.ulp-fa-input-cell {
    text-align: center;
}
#ulp-layer-352 {
    text-align: center;
    transform: rotate(2deg);
    z-index: 1000007;
}
#ulp-layer-352, #ulp-layer-352 p, #ulp-layer-352 a, #ulp-layer-352 span, #ulp-layer-352 li, #ulp-layer-352 input, #ulp-layer-352 button, #ulp-layer-352 textarea {
    color: #ffffff;
    font-family: "arial",arial;
    font-weight: 700;
}
.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}
.ulp-inherited:before {
    content: "";
    display: inline-block;
    height: 100%;
    padding-top: 3px;
    vertical-align: middle;
}
#ulp-SU1xVylD2bJJSNiZ .ulp-submit, #ulp-SU1xVylD2bJJSNiZ .ulp-submit:visited {
    background: none repeat scroll 0 0 #45a039;
    border: 1px solid #45a039;
    border-radius: 2px !important;
}
#ulp-layer-352, #ulp-layer-352 p, #ulp-layer-352 a, #ulp-layer-352 span, #ulp-layer-352 li, #ulp-layer-352 input, #ulp-layer-352 button, #ulp-layer-352 textarea {
    color: #ffffff;
    font-family: "arial",arial;
    font-weight: 700;
}
.ulp-window a {
    text-decoration: none !important;
}
.ulp-inherited {
    box-sizing: border-box !important;
    display: block !important;
    height: 100% !important;
}
.ulp-submit, .ulp-submit:visited, .ulp-submit-button, .ulp-submit-button:visited {
    border-radius: 2px;
    box-shadow: none;
    cursor: pointer;
    display: inline-block;
    font-size: inherit !important;
    height: auto;
    line-height: 1.5;
    margin: 0;
    padding: 5px 20px;
    position: relative;
    text-decoration: none !important;
    text-shadow: 0 -1px 1px rgba(0, 0, 0, 0.25);
    transition-duration: 0.3s;
    white-space: nowrap;
    width: auto;
}
.fo-right-ribbon a:hover, .fo-right-ribbon a:focus, a {
    text-decoration: none;
}
a, a:active, a:hover {
    outline: medium none;
}
.fa-share-square-o:before {
    content: "";
}
.fa-share-square-o:before {
    content: "";
}
.fa {
    display: inline-block;
    font-family: FontAwesome;
    font-feature-settings: normal;
    font-kerning: auto;
    font-language-override: normal;
    font-size: inherit;
    font-size-adjust: none;
    font-stretch: normal;
    font-style: normal;
    font-synthesis: weight style;
    font-variant: normal;
    font-weight: normal;
    line-height: 1;
    text-rendering: auto;
}
#ulp-layer-352, #ulp-layer-352 p, #ulp-layer-352 a, #ulp-layer-352 span, #ulp-layer-352 li, #ulp-layer-352 input, #ulp-layer-352 button, #ulp-layer-352 textarea {
    color: #ffffff;
}
.ulp-submit, .ulp-submit:visited, .ulp-submit-button, .ulp-submit-button:visited {
    cursor: pointer;
    font-size: inherit !important;
    text-shadow: 0 -1px 1px rgba(0, 0, 0, 0.25);
    white-space: nowrap;
}
#ulp-layer-353 {
    background-color: rgba(230, 226, 77, 1);
    padding: 4px 0;
    text-align: center;
    z-index: 1000007;
}
#ulp-layer-353, #ulp-layer-353 p, #ulp-layer-353 a, #ulp-layer-353 span, #ulp-layer-353 li, #ulp-layer-353 input, #ulp-layer-353 button, #ulp-layer-353 textarea {
    color: #ffffff;
    font-family: "arial",arial;
    font-weight: 700;
}
.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}
#ulp-layer-354 {
    text-align: center;
    transform: rotate(-5deg);
    z-index: 1000007;
}
#ulp-layer-354, #ulp-layer-354 p, #ulp-layer-354 a, #ulp-layer-354 span, #ulp-layer-354 li, #ulp-layer-354 input, #ulp-layer-354 button, #ulp-layer-354 textarea {
    color: #ffffff;
    font-family: "arial",arial;
    font-weight: 700;
}
.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}
.ulp-inherited:before {
    content: "";
    display: inline-block;
    height: 100%;
    padding-top: 3px;
    vertical-align: middle;
}
#ulp-SU1xVylD2bJJSNiZ .ulp-submit-facebook, #ulp-SU1xVylD2bJJSNiZ .ulp-submit-facebook:visited {
    background: none repeat scroll 0 0 #3b5998;
    border: 1px solid #3b5998;
}
#ulp-SU1xVylD2bJJSNiZ .ulp-submit-button, #ulp-SU1xVylD2bJJSNiZ .ulp-submit-button:visited, #ulp-SU1xVylD2bJJSNiZ .ulp-submit-button:hover, #ulp-SU1xVylD2bJJSNiZ .ulp-submit-button:active {
    border-radius: 2px !important;
}
#ulp-layer-354, #ulp-layer-354 p, #ulp-layer-354 a, #ulp-layer-354 span, #ulp-layer-354 li, #ulp-layer-354 input, #ulp-layer-354 button, #ulp-layer-354 textarea {
    color: #ffffff;
    font-family: "arial",arial;
    font-weight: 700;
}
.ulp-window a {
    text-decoration: none !important;
}
.ulp-inherited {
    box-sizing: border-box !important;
    display: block !important;
    height: 100% !important;
}
.ulp-submit, .ulp-submit:visited, .ulp-submit-button, .ulp-submit-button:visited {
    border-radius: 2px;
    box-shadow: none;
    cursor: pointer;
    display: inline-block;
    font-size: inherit !important;
    height: auto;
    line-height: 1.5;
    margin: 0;
    padding: 5px 20px;
    position: relative;
    text-decoration: none !important;
    text-shadow: 0 -1px 1px rgba(0, 0, 0, 0.25);
    transition-duration: 0.3s;
    white-space: nowrap;
    width: auto;
}
.fo-right-ribbon a:hover, .fo-right-ribbon a:focus, a {
    text-decoration: none;
}
a, a:active, a:hover {
    outline: medium none;
}
.fa-facebook:before {
    content: "";
}
.fa-facebook:before {
    content: "";
}
.fa {
    display: inline-block;
    font-family: FontAwesome;
    font-feature-settings: normal;
    font-kerning: auto;
    font-language-override: normal;
    font-size: inherit;
    font-size-adjust: none;
    font-stretch: normal;
    font-style: normal;
    font-synthesis: weight style;
    font-variant: normal;
    font-weight: normal;
    line-height: 1;
    text-rendering: auto;
}
#ulp-layer-354, #ulp-layer-354 p, #ulp-layer-354 a, #ulp-layer-354 span, #ulp-layer-354 li, #ulp-layer-354 input, #ulp-layer-354 button, #ulp-layer-354 textarea {
    color: #ffffff;
}
.ulp-submit, .ulp-submit:visited, .ulp-submit-button, .ulp-submit-button:visited {
    cursor: pointer;
    font-size: inherit !important;
    text-shadow: 0 -1px 1px rgba(0, 0, 0, 0.25);
    white-space: nowrap;
}
#ulp-layer-355 {
    text-align: center;
    transform: rotate(3deg);
    z-index: 1000007;
}
#ulp-layer-355, #ulp-layer-355 p, #ulp-layer-355 a, #ulp-layer-355 span, #ulp-layer-355 li, #ulp-layer-355 input, #ulp-layer-355 button, #ulp-layer-355 textarea {
    color: #ffffff;
    font-family: "arial",arial;
    font-weight: 700;
}
.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}
.ulp-inherited:before {
    content: "";
    display: inline-block;
    height: 100%;
    padding-top: 3px;
    vertical-align: middle;
}
#ulp-SU1xVylD2bJJSNiZ .ulp-submit-google, #ulp-SU1xVylD2bJJSNiZ .ulp-submit-google:visited {
    background: none repeat scroll 0 0 #d34836;
    border: 1px solid #d34836;
}
#ulp-SU1xVylD2bJJSNiZ .ulp-submit-button, #ulp-SU1xVylD2bJJSNiZ .ulp-submit-button:visited, #ulp-SU1xVylD2bJJSNiZ .ulp-submit-button:hover, #ulp-SU1xVylD2bJJSNiZ .ulp-submit-button:active {
    border-radius: 2px !important;
}
#ulp-layer-355, #ulp-layer-355 p, #ulp-layer-355 a, #ulp-layer-355 span, #ulp-layer-355 li, #ulp-layer-355 input, #ulp-layer-355 button, #ulp-layer-355 textarea {
    color: #ffffff;
    font-family: "arial",arial;
    font-weight: 700;
}
.ulp-window a {
    text-decoration: none !important;
}
.ulp-inherited {
    box-sizing: border-box !important;
    display: block !important;
    height: 100% !important;
}
.ulp-submit, .ulp-submit:visited, .ulp-submit-button, .ulp-submit-button:visited {
    border-radius: 2px;
    box-shadow: none;
    cursor: pointer;
    display: inline-block;
    font-size: inherit !important;
    height: auto;
    line-height: 1.5;
    margin: 0;
    padding: 5px 20px;
    position: relative;
    text-decoration: none !important;
    text-shadow: 0 -1px 1px rgba(0, 0, 0, 0.25);
    transition-duration: 0.3s;
    white-space: nowrap;
    width: auto;
	  background: none repeat scroll 0 0 #45a039;
    border: 1px solid #45a039;
    border-radius: 2px !important;
}
.fo-right-ribbon a:hover, .fo-right-ribbon a:focus, a {
    text-decoration: none;
}
a, a:active, a:hover {
    outline: medium none;
}
.fa-google:before {
    content: "";
}
.fa-google:before {
    content: "";
}
.fa {
    display: inline-block;
    font-family: FontAwesome;
    font-feature-settings: normal;
    font-kerning: auto;
    font-language-override: normal;
    font-size: inherit;
    font-size-adjust: none;
    font-stretch: normal;
    font-style: normal;
    font-synthesis: weight style;
    font-variant: normal;
    font-weight: normal;
    line-height: 1;
    text-rendering: auto;
}
#ulp-layer-355, #ulp-layer-355 p, #ulp-layer-355 a, #ulp-layer-355 span, #ulp-layer-355 li, #ulp-layer-355 input, #ulp-layer-355 button, #ulp-layer-355 textarea {
    color: #ffffff;
}
.ulp-submit, .ulp-submit:visited, .ulp-submit-button, .ulp-submit-button:visited {
    cursor: pointer;
    font-size: inherit !important;
    text-shadow: 0 -1px 1px rgba(0, 0, 0, 0.25);
    white-space: nowrap;
}
#ulp-layer-356 {
    background-color: rgba(172, 30, 191, 1);
    text-align: center;
    transform: rotate(5deg);
    z-index: 1000007;
}
#ulp-layer-356, #ulp-layer-356 p, #ulp-layer-356 a, #ulp-layer-356 span, #ulp-layer-356 li, #ulp-layer-356 input, #ulp-layer-356 button, #ulp-layer-356 textarea {
    color: #ffffff;
    font-family: "arial",arial;
    font-weight: 700;
}
.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}
.ulp-inherited:before {
    content: "";
    display: inline-block;
    height: 100%;
    padding-top: 3px;
    vertical-align: middle;
}
#ulp-layer-356, #ulp-layer-356 p, #ulp-layer-356 a, #ulp-layer-356 span, #ulp-layer-356 li, #ulp-layer-356 input, #ulp-layer-356 button, #ulp-layer-356 textarea {
    color: #ffffff;
    font-family: "arial",arial;
    font-weight: 700;
}
.ulp-window a {
    text-decoration: none !important;
}
.ulp-inherited {
    box-sizing: border-box !important;
    display: block !important;
    height: 100% !important;
}
.fo-right-ribbon a:hover, .fo-right-ribbon a:focus, a {
    text-decoration: none;
}
a, .contactForm input[type="text"]:focus, .contactForm input[type="email"]:focus, .contactForm textarea:focus, input#formSubmit, .errorForm, #subscribe input[type="email"]:focus, .errorSubs, .servSingle, #toTop i, #notForm input[type="email"]:focus, .contactForm input#submit, #loginForm input, #loginForm input[type="text"]:focus, #loginForm input[type="password"]:focus {
    transition: all 0.5s ease 0s;
}
table
{
	margin:20px;
	background:#f8f8f8;
	
}
table td
{
	padding:10px;
	border:1px solid #ccc;
}
table td label
{
	font-family:Arial, Helvetica, sans-serif;
	font-size:14px;
	font-weight:normal;
}
table td input[type='text']
{
	border:none;
	padding:10px;
	font-size:12px;
	font-weight:normal;
	border:1px solid #ccc;
	width:300px;
}
table td textarea
{
	width:300px;
	font-size:12px;
}
#updateform
{
	background:#019ad2;
	color:#fff;
	font-size:16px;
	padding:10px;
	border:1px solid #019ad2;
	width:100px;
}


</style>

 <?php 
$txthtml="<div id='popupform' style='position:relative;'><div class='ulp-content' style='width: 397px; height: 397px; margin: 10% auto auto;'>
							<div id='ulp-layer-348' class='ulp-layer' style='width: 397px; height: 397px; font-size: 11px; left: 0px; top: 0px;'></div>
							<div id='ulp-layer-349' class='ulp-layer animated zoomInLeft' style='width: 301px; font-size: 15px; left: 63px; top: 72px;'>ARE YOU READY? GET IT NOW!</div>
							<div id='ulp-layer-350' class='ulp-layer animated zoomInRight' style='width: 285px; height: 34px; font-size: 12px; left: 15px; top: 150px;'><input type='text' onfocus='jQuery(this).removeClass('ulp-input-error');' value='' placeholder='Enter your name...' name='ulp-name' class='ulp-input'><div class='ulp-fa-input-table'><div class='ulp-fa-input-cell'><i class='fa fa-user'></i></div></div></div>
							<div id='ulp-layer-351' class='ulp-layer animated zoomInLeft' style='width: 285px; height: 34px; font-size: 12px; left: 79px; top: 220px;'><input type='text' onfocus='jQuery(this).removeClass('ulp-input-error');' value='' placeholder='Enter your e-mail...' name='ulp-email' class='ulp-input'><div class='ulp-fa-input-table'><div class='ulp-fa-input-cell '><i class='fa fa-envelope'></i></div></div></div>
							<div id='ulp-layer-352' class='ulp-layer animated zoomInRight' style='width: 158px; height: 38px; font-size: 15px; left: 31px; top: 290px;'><a data-loading='Loading...' data-label='Subscribe' data-icon='fa-share-square-o' onclick='return ulp_subscribe(this);' class='ulp-submit ulp-inherited'><i class='fa fa-share-square-o'></i>&nbsp; Subscribe</a></div>
							<div id='ulp-layer-356' class='ulp-layer'' style='width: 31px; height: 31px; font-size: 22px; left: 365px; top: -23px;'><a onclick='return ulp_self_close();' href='#' class='ulp-inherited'>x</a></div>
						</div></div>";
		echo $txthtml;
?>
 <div  style="margin-top:30px;">
<table width="97%" border="0">
  <tr>
    
    <td><label>Popup Background Color :</label></td>
    <td><input class="color boxcolor" value="66ff00" id="popbgcolor" onchange="popup_bg();"></td>
      <td></td>
    <td></td>
    
  </tr>
  <tr>
    <td><label>Layer One Color :</label></td>
    <td><input class="color boxcolor" value="66ff00" id="layer1_color" onchange="layer1_color();"></td>
    <td><label> Layer One Background Color :</label></td>
    <td><input class="color boxcolor" value="66ff00" id="button1_bkgcolor" onchange="button1_bkgcolor();"></td>
    <td><label>Layer One Text :</label></td>
    <td><input type="text" value="" id="layer1_txt" onkeypress="layer1_txt();" maxlength="30" /></td>
   <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
   <tr>
    <td><label>Placeholder one text :</label></td>
    <td><input type="text" value="" id="placeholder1_txt" onkeypress="placeholder1_txt();"  /></td>
    <td><label>Placeholder Two text :</label></td>
    <td><input type="text" value="" id="placeholder2_txt" onkeypress="placeholder2_txt();"  /></td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  
    <tr>
    <td><label>Subscribe Text Color:</label></td>
    <td><input class="color boxcolor" value="66ff00" id="button1_color" onchange="button1_color();"></td>
    <td><label> Subscribe Background Color :</label></td>
    <td><input class="color boxcolor" value="66ff00" id="button1_bkgcolor" onchange="button1_bkgcolor();"></td>
    <td><label> Subscribe Text :</label></td>
    <td><input type="text" value="" maxlength="100" id="button1_txt" onkeypress="button1_txt();"  /></td>
  
  </tr>
   
  
   <tr>
    <td>Close Button Background</td>
    <td><input class="color boxcolor" value="66ff00" id="buttonclose_bkgcolor" onchange="buttonclose_bkgcolor();"></td>
  </tr>

 
</table>

</div>                       
<script type="text/javascript">
function pop_layer_data()
{
	var layer1_txt=$("#ulp-layer-349").html();
    var layer2_txt=$("#ulp-layer-329").html();
    var layer3_txt=$("#ulp-layer-327").html();
   
    var placeholder1_txt=$("#ulp-layer-350 .ulp-input").attr('placeholder');
    var placeholder2_txt=$("#ulp-layer-351 .ulp-input").attr('placeholder');
    var button1_txt=$("#ulp-layer-352 .ulp-inherited").html();
    var button2_txt=$("#ulp-layer-353").html();
    var button3_txt=$("#ulp-layer-355 .ulp-submit-google").html();
    var button4_txt=$("#ulp-layer-354 .ulp-submit-facebook").html();
    
	

	$("#layer1_txt").val(layer1_txt);
    $("#layer2_txt").val(layer2_txt);
    $("#layer3_txt").val(layer3_txt);
    $("#placeholder1_txt").val(placeholder1_txt);
    $("#placeholder2_txt").val(placeholder2_txt);
    $("#button1_txt").val(button1_txt);
    $("#button2_txt").val(button2_txt);
    $("#button3_txt").val(button3_txt);
    $("#button4_txt").val(button4_txt);
    
}
                 		function popup_bg()
						{
							
							var popbgcolor="#"+$("#popbgcolor").val();
							//alert(bgcolor);
							$("#ulp-layer-348").css("background-color",popbgcolor);
						}
						
						function layer1_color()
						{
							
							var fcolor="#"+$("#layer1_color").val();
							//alert(bgcolor);
							$("#ulp-layer-349").css("color",fcolor);
						}
						function layer1_txt()
						{
							var layer1_txt=$("#layer1_txt").val();
							//alert(bgcolor);
							$("#ulp-layer-349").html(layer1_txt);
						}
						function button1_bkgcolor()
						{
							var fcolor="#"+$("#button1_bkgcolor").val();
							$("#ulp-layer-349").css("background",fcolor);
							
							
						}
						
						function placeholder1_txt()
						{
							var placeholder1_txt=$("#placeholder1_txt").val();
							//alert(bgcolor);
							$("#ulp-layer-350 .ulp-input").attr('placeholder',placeholder1_txt);
						}
						
						
						function placeholder2_txt()
						{
							var placeholder2_txt=$("#placeholder2_txt").val();
							//alert(bgcolor);
							$("#ulp-layer-351 .ulp-input").attr('placeholder',placeholder2_txt);
						}
						
						
						function button1_color()
						{
							var fcolor="#"+$("#button1_color").val();
							//alert(bgcolor);
							$("#ulp-layer-352 .ulp-inherited").css("color",fcolor);
						}
						function button1_bkgcolor()
						{
							var button1_bkgcolor="#"+$("#button1_bkgcolor").val();
							//alert(button1_bkgcolor);
							$("#ulp-layer-352 .ulp-inherited").css('background',button1_bkgcolor);
						}
						function button1_txt()
						{
							var button1_txt=$("#button1_txt").val();
							//alert(bgcolor);
							$("#ulp-layer-352 .ulp-inherited").html(button1_txt);
						}


						
						function button2_color()
						{
							var fcolor="#"+$("#button2_color").val();
							
							//alert(bgcolor);
							$("#ulp-layer-353").css("color",fcolor);
						}
						function button2_bkgcolor()
						{
							var button2_bkgcolor="#"+$("#button2_bkgcolor").val();
							
							//alert(button1_bkgcolor);
							$("#ulp-layer-353").css('background',button2_bkgcolor);
						}
						function button2_txt()
						{
							var button2_txt=$("#button2_txt").val();
							//alert(button2_txt);
							//alert(bgcolor);
							$("#ulp-layer-353").html(button2_txt);
						}


						
						function button4_color()
						{
							var fcolor="#"+$("#button4_color").val();
							
							//alert(bgcolor);
							$("#ulp-layer-354 .ulp-submit-facebook").css("color",fcolor);
						}
						function button4_bkgcolor()
						{
							var button4_bkgcolor="#"+$("#button4_bkgcolor").val();
							
							//alert(button1_bkgcolor);
							$("#ulp-layer-354 .ulp-submit-facebook").css('background',button4_bkgcolor);
						}
						function button4_txt()
						{
							var button4_txt=$("#button4_txt").val();
						    $("#ulp-layer-354 .ulp-submit-facebook").html(button4_txt);
						}

						



						function button3_color()
						{
							var fcolor="#"+$("#button3_color").val();
							
							//alert(bgcolor);
							$("#ulp-layer-355 .ulp-submit-google").css("color",fcolor);
						}
						function button3_bkgcolor()
						{
							var button3_bkgcolor="#"+$("#button3_bkgcolor").val();
							
							//alert(button1_bkgcolor);
							$("#ulp-layer-355 .ulp-submit-google").css('background',button3_bkgcolor);
						}
						function button3_txt()
						{
							var button3_txt=$("#button3_txt").val();
							//alert(button3_txt);
							$("#ulp-layer-355 .ulp-submit-google").html(button3_txt);
						}
						function buttonclose_bkgcolor()
						{
							var bkgcolor="#"+$("#buttonclose_bkgcolor").val();
							//alert(bgcolor);
							$("#ulp-layer-356").css("background-color",bkgcolor);
						}
						
						
						
					
						</script>



						
					