<link rel="stylesheet" href="<?php echo SITE_ROOT_URL; ?>views/layered/animatemaster/animate.min.css">
<script type="text/javascript" src="<?php echo SITE_ROOT_URL; ?>colorjs/jscolor.js"></script>
<style>
body
{
margin:0px;
padding:0px;
}
.ulp-content {
    position: relative;
}
#ulp-layer-311 {
    background-color: rgba(0, 0, 0, 0.9);
    box-shadow: 0 4px 30px rgba(32, 32, 32, 1);
    text-align: left;
    z-index: 1000002;
}
#ulp-layer-311, #ulp-layer-311 p, #ulp-layer-311 a, #ulp-layer-311 span, #ulp-layer-311 li, #ulp-layer-311 input, #ulp-layer-311 button, #ulp-layer-311 textarea {
    color: #000000;
    font-family: "arial",arial;
    font-weight: 400;
}
.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}
.ulp-layer img {
    border: medium none !important;
    box-shadow: none !important;
    margin: 0 !important;
    max-width: 100% !important;
    min-width: 0 !important;
    padding: 0 !important;
}
img {
    max-width: 100%;
}
#ulp-layer-312 {
    background-color: rgba(0, 0, 0, 0.7);
    text-align: left;
    z-index: 1000003;
}
#ulp-layer-312, #ulp-layer-312 p, #ulp-layer-312 a, #ulp-layer-312 span, #ulp-layer-312 li, #ulp-layer-312 input, #ulp-layer-312 button, #ulp-layer-312 textarea {
    color: #000000;
    font-family: "arial",arial;
    font-weight: 400;
}
.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}
#ulp-layer-313 {
    text-align: center;
    z-index: 1000004;
}
#ulp-layer-313, #ulp-layer-313 p, #ulp-layer-313 a, #ulp-layer-313 span, #ulp-layer-313 li, #ulp-layer-313 input, #ulp-layer-313 button, #ulp-layer-313 textarea {
    color: #ffffff;
    font-family: "arial",arial;
    font-weight: 100;
    text-shadow: 1px 1px 1px #000000;
}
.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}
#ulp-layer-314 {
    background-color: #0597f2;
    text-align: center;
    z-index: 1000004;
}
#ulp-layer-314, #ulp-layer-314 p, #ulp-layer-314 a, #ulp-layer-314 span, #ulp-layer-314 li, #ulp-layer-314 input, #ulp-layer-314 button, #ulp-layer-314 textarea {
    color: #ffffff;
    font-family: "arial",arial;
    font-weight: 100;
    text-shadow: 1px 1px 1px #000000;
}
.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}
#ulp-layer-315 {
    text-align: justify;
    z-index: 1000004;
}
#ulp-layer-315, #ulp-layer-315 p, #ulp-layer-315 a, #ulp-layer-315 span, #ulp-layer-315 li, #ulp-layer-315 input, #ulp-layer-315 button, #ulp-layer-315 textarea {
    color: #ffffff;
    font-family: "arial",arial;
    font-weight: 100;
    text-shadow: 1px 1px 1px #000000;
}
.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}
#ulp-layer-316 {
    text-align: center;
    z-index: 1000007;
}
#ulp-layer-316, #ulp-layer-316 p, #ulp-layer-316 a, #ulp-layer-316 span, #ulp-layer-316 li, #ulp-layer-316 input, #ulp-layer-316 button, #ulp-layer-316 textarea {
    color: #ffffff;
    font-family: "arial",arial;
    font-weight: 100;
}
.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}
.ulp-social-button-google-plusone {
    padding-top: 2px;
}
.ulp-social-button {
    display: inline-block;
    overflow: hidden;
    vertical-align: top;
}
#ulp-layer-316 {
    text-align: center;
}
#ulp-layer-316, #ulp-layer-316 p, #ulp-layer-316 a, #ulp-layer-316 span, #ulp-layer-316 li, #ulp-layer-316 input, #ulp-layer-316 button, #ulp-layer-316 textarea {
    color: #ffffff;
}
.ulp-social-button-facebook-like {
    padding-top: 1px;
}
.ulp-social-button {
    display: inline-block;
    overflow: hidden;
    vertical-align: top;
}
.fb_iframe_widget {
    display: inline-block;
    position: relative;
}
#ulp-layer-316, #ulp-layer-316 p, #ulp-layer-316 a, #ulp-layer-316 span, #ulp-layer-316 li, #ulp-layer-316 input, #ulp-layer-316 button, #ulp-layer-316 textarea {
    color: #ffffff;
    font-family: "arial",arial;
    font-weight: 100;
}
.fb_iframe_widget span {
    display: inline-block;
    position: relative;
    text-align: justify;
}
.fb_iframe_widget iframe {
    position: absolute;
}
.ulp-social-button {
    display: inline-block;
    overflow: hidden;
    vertical-align: top;
}
iframe {
    border: 0 none;
}
.ulp-social-button {
    display: inline-block;
    overflow: hidden;
    vertical-align: top;
}
#ulp-layer-316, #ulp-layer-316 p, #ulp-layer-316 a, #ulp-layer-316 span, #ulp-layer-316 li, #ulp-layer-316 input, #ulp-layer-316 button, #ulp-layer-316 textarea {
    color: #ffffff;
    font-family: "arial",arial;
    font-weight: 100;
}
#ulp-layer-316, #ulp-layer-316 p, #ulp-layer-316 a, #ulp-layer-316 span, #ulp-layer-316 li, #ulp-layer-316 input, #ulp-layer-316 button, #ulp-layer-316 textarea {
    color: #ffffff;
    font-family: "arial",arial;
    font-weight: 100;
}
#li_ui_li_gen_1422699496928_1-container.IN-top {
    cursor: pointer !important;
    display: inline-block !important;
    height: 42px !important;
    line-height: 1px !important;
    overflow: visible !important;
    position: relative !important;
}
#ulp-layer-316, #ulp-layer-316 p, #ulp-layer-316 a, #ulp-layer-316 span, #ulp-layer-316 li, #ulp-layer-316 input, #ulp-layer-316 button, #ulp-layer-316 textarea {
    color: #ffffff;
    font-family: "arial",arial;
    font-weight: 100;
}
#li_ui_li_gen_1422699496928_1.IN-top {
    background-color: transparent !important;
    background-image: url("https://static.licdn.com/scds/common/u/images/apps/connect/sprites/sprite_connect_v14.png") !important;
    background-position: -150px top !important;
    background-repeat: no-repeat !important;
    display: inline-block !important;
    height: 42px !important;
    text-align: center !important;
    width: 57px !important;
}
#ulp-layer-316, #ulp-layer-316 p, #ulp-layer-316 a, #ulp-layer-316 span, #ulp-layer-316 li, #ulp-layer-316 input, #ulp-layer-316 button, #ulp-layer-316 textarea {
    color: #ffffff;
    font-family: "arial",arial;
    font-weight: 100;
}
#li_ui_li_gen_1422699496928_1-container.IN-empty #li_ui_li_gen_1422699496928_1-inner.IN-top {
    background-color: transparent !important;
    background-image: url("https://static.licdn.com/scds/common/u/images/apps/connect/sprites/sprite_connect_v14.png") !important;
    background-position: 0 -20px !important;
    background-repeat: no-repeat !important;
    display: block !important;
    height: 26px !important;
    margin: 5px auto 0 !important;
    overflow: hidden !important;
    width: 26px !important;
}
#ulp-layer-316, #ulp-layer-316 p, #ulp-layer-316 a, #ulp-layer-316 span, #ulp-layer-316 li, #ulp-layer-316 input, #ulp-layer-316 button, #ulp-layer-316 textarea {
    color: #ffffff;
    font-family: "arial",arial;
    font-weight: 100;
}
#li_ui_li_gen_1422699496928_1-container.IN-empty #li_ui_li_gen_1422699496928_1-content.IN-top {
    display: inline-block !important;
    text-indent: -999px !important;
}
#li_ui_li_gen_1422699496928_1-content.IN-top {
    color: #04558b !important;
    display: inline !important;
    font-family: Arial,sans-serif !important;
    font-size: 16px !important;
    font-weight: bold !important;
    line-height: 38px !important;
}
#ulp-layer-316, #ulp-layer-316 p, #ulp-layer-316 a, #ulp-layer-316 span, #ulp-layer-316 li, #ulp-layer-316 input, #ulp-layer-316 button, #ulp-layer-316 textarea {
    color: #ffffff;
    font-family: "arial",arial;
    font-weight: 100;
}
#li_ui_li_gen_1422699496928_1-container.IN-empty #li_ui_li_gen_1422699496928_1-content.IN-top {
    display: inline-block !important;
    text-indent: -999px !important;
}
#li_ui_li_gen_1422699496928_1-content.IN-top {
    color: #04558b !important;
    display: inline !important;
    font-family: Arial,sans-serif !important;
    font-size: 16px !important;
    font-weight: bold !important;
    line-height: 38px !important;
}
#ulp-layer-316, #ulp-layer-316 p, #ulp-layer-316 a, #ulp-layer-316 span, #ulp-layer-316 li, #ulp-layer-316 input, #ulp-layer-316 button, #ulp-layer-316 textarea {
    color: #ffffff;
    font-family: "arial",arial;
    font-weight: 100;
}
#ulp-layer-316, #ulp-layer-316 p, #ulp-layer-316 a, #ulp-layer-316 span, #ulp-layer-316 li, #ulp-layer-316 input, #ulp-layer-316 button, #ulp-layer-316 textarea {
    color: #ffffff;
    font-family: "arial",arial;
    font-weight: 100;
}
#li_ui_li_gen_1422699496921_0 {
    display: block !important;
    overflow: visible !important;
    position: relative !important;
}
#li_ui_li_gen_1422699496921_0 a#li_ui_li_gen_1422699496921_0-link:after {
    clear: both !important;
    content: "." !important;
    display: block !important;
    height: 0 !important;
    line-height: 0 !important;
    visibility: hidden !important;
}
#li_ui_li_gen_1422699496921_0 a#li_ui_li_gen_1422699496921_0-link:link, #li_ui_li_gen_1422699496921_0 a#li_ui_li_gen_1422699496921_0-link:visited, #li_ui_li_gen_1422699496921_0 a#li_ui_li_gen_1422699496921_0-link:hover, #li_ui_li_gen_1422699496921_0 a#li_ui_li_gen_1422699496921_0-link:active {
    border: 0 none !important;
    text-decoration: none !important;
}
#li_ui_li_gen_1422699496921_0 a#li_ui_li_gen_1422699496921_0-link {
    border: 0 none !important;
    display: inline-block !important;
    height: 20px !important;
    margin: 0 !important;
    padding: 0 !important;
    text-decoration: none !important;
}
#ulp-layer-316, #ulp-layer-316 p, #ulp-layer-316 a, #ulp-layer-316 span, #ulp-layer-316 li, #ulp-layer-316 input, #ulp-layer-316 button, #ulp-layer-316 textarea {
    color: #ffffff;
    font-family: "arial",arial;
    font-weight: 100;
}
.ulp-window a {
    text-decoration: none !important;
}
#li_ui_li_gen_1422699496921_0 a#li_ui_li_gen_1422699496921_0-link:after {
    clear: both !important;
    content: "." !important;
    display: block !important;
    height: 0 !important;
    line-height: 0 !important;
    visibility: hidden !important;
}
#li_ui_li_gen_1422699496921_0 a#li_ui_li_gen_1422699496921_0-link:link, #li_ui_li_gen_1422699496921_0 a#li_ui_li_gen_1422699496921_0-link:visited, #li_ui_li_gen_1422699496921_0 a#li_ui_li_gen_1422699496921_0-link:hover, #li_ui_li_gen_1422699496921_0 a#li_ui_li_gen_1422699496921_0-link:active {
    border: 0 none !important;
    text-decoration: none !important;
}
#li_ui_li_gen_1422699496921_0 a#li_ui_li_gen_1422699496921_0-link {
    border: 0 none !important;
    display: inline-block !important;
    height: 20px !important;
    margin: 0 !important;
    padding: 0 !important;
    text-decoration: none !important;
}
#ulp-layer-316, #ulp-layer-316 p, #ulp-layer-316 a, #ulp-layer-316 span, #ulp-layer-316 li, #ulp-layer-316 input, #ulp-layer-316 button, #ulp-layer-316 textarea {
    color: #ffffff;
    font-family: "arial",arial;
    font-weight: 100;
}
.ulp-window a {
    text-decoration: none !important;
}
#li_ui_li_gen_1422699496921_0 #li_ui_li_gen_1422699496921_0-title {
    -moz-border-bottom-colors: none !important;
    -moz-border-left-colors: none !important;
    -moz-border-right-colors: none !important;
    -moz-border-top-colors: none !important;
    background-color: #ececec !important;
    background-image: -moz-linear-gradient(center top , #fefefe 0%, #ececec 100%) !important;
    border-color: #e2e2e2 #bfbfbf #b9b9b9 -moz-use-text-color !important;
    border-image: none !important;
    border-radius: 0 2px 2px 0 !important;
    border-style: solid solid solid none !important;
    border-width: 1px 1px 1px 0 !important;
    color: #333 !important;
    cursor: pointer !important;
    display: block !important;
    float: left !important;
    height: 18px !important;
    line-height: 20px !important;
    margin-left: 1px !important;
    overflow: hidden !important;
    padding: 0 4px 0 23px !important;
    text-align: center !important;
    text-shadow: -1px 1px 0 #ffffff !important;
    vertical-align: top !important;
    white-space: nowrap !important;
}
#ulp-layer-316, #ulp-layer-316 p, #ulp-layer-316 a, #ulp-layer-316 span, #ulp-layer-316 li, #ulp-layer-316 input, #ulp-layer-316 button, #ulp-layer-316 textarea {
    color: #ffffff;
    font-family: "arial",arial;
    font-weight: 100;
}
#li_ui_li_gen_1422699496921_0 span {
    box-sizing: content-box !important;
}
#li_ui_li_gen_1422699496921_0 #li_ui_li_gen_1422699496921_0-title-text, #li_ui_li_gen_1422699496921_0 #li_ui_li_gen_1422699496921_0-title-text * {
    background: none repeat scroll 0 0 transparent !important;
    color: #333 !important;
    display: inline-block !important;
    float: none !important;
    font-family: Arial,sans-serif !important;
    font-size: 11px !important;
    font-style: normal !important;
    font-weight: bold !important;
    height: 18px !important;
    line-height: 20px !important;
    vertical-align: top !important;
}
#ulp-layer-316, #ulp-layer-316 p, #ulp-layer-316 a, #ulp-layer-316 span, #ulp-layer-316 li, #ulp-layer-316 input, #ulp-layer-316 button, #ulp-layer-316 textarea {
    color: #ffffff;
    font-family: "arial",arial;
    font-weight: 100;
}
#li_ui_li_gen_1422699496921_0 span {
    box-sizing: content-box !important;
}
#ulp-layer-317 {
    background-color: rgba(5, 151, 242, 0.9);
    line-height: 32px;
    text-align: center;
    z-index: 1000007;
}
#ulp-layer-317, #ulp-layer-317 p, #ulp-layer-317 a, #ulp-layer-317 span, #ulp-layer-317 li, #ulp-layer-317 input, #ulp-layer-317 button, #ulp-layer-317 textarea {
    color: #ffffff;
    font-family: "arial",arial;
    font-weight: 400;
}
.ulp-layer {
    box-sizing: border-box;
    position: absolute;
}
#ulp-layer-317, #ulp-layer-317 p, #ulp-layer-317 a, #ulp-layer-317 span, #ulp-layer-317 li, #ulp-layer-317 input, #ulp-layer-317 button, #ulp-layer-317 textarea {
    color: #ffffff;
    font-family: "arial",arial;
    font-weight: 400;
}
.ulp-window a {
    text-decoration: none !important;
}
a, .contactForm input[type="text"]:focus, .contactForm input[type="email"]:focus, .contactForm textarea:focus, input#formSubmit, .errorForm, #subscribe input[type="email"]:focus, .errorSubs, .servSingle, #toTop i, #notForm input[type="email"]:focus, .contactForm input#submit, #loginForm input, #loginForm input[type="text"]:focus, #loginForm input[type="password"]:focus {
    transition: all 0.5s ease 0s;
}
a, a:active, a:hover {
    outline: medium none;
}
#ulp-layer-318 {
    background-color: #0597f2;
    text-align: center;
    z-index: 1000004;
}
#ulp-layer-318, #ulp-layer-318 p, #ulp-layer-318 a, #ulp-layer-318 span, #ulp-layer-318 li, #ulp-layer-318 input, #ulp-layer-318 button, #ulp-layer-318 textarea {
    color: #ffffff;
    font-family: "arial",arial;
    font-weight: 100;
    text-shadow: 1px 1px 1px #000000;
}
.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}

table
{
	margin:20px;
	background:#f8f8f8;
	
}
table td
{
	padding:10px;
	border:1px solid #ccc;
}
table td label
{
	font-family:Arial, Helvetica, sans-serif;
	font-size:14px;
	font-weight:normal;
}
table td input[type='text']
{
	border:none;
	padding:10px;
	font-size:12px;
	font-weight:normal;
	border:1px solid #ccc;
	width:300px;
}
table td textarea
{
	width:300px;
	font-size:12px;
}
#updateform
{
	background:#019ad2;
	color:#fff;
	font-size:16px;
	padding:10px;
	border:1px solid #019ad2;
	width:100px;
}
</style>
<?php 
 
$txthtml="<div id='popupform' style='position:relative;'><div class='ulp-content' style='width: 635px; height: 397px; margin: 10% auto auto;'>
							<div id='ulp-layer-311' class='ulp-layer animated bounce' style='width: 635px; height: 397px; font-size: 13px; left: 0px; top: 0px;'><img alt='' src='https://layeredpopups.com/layered-popups/images/default/business03.jpg'></div>
							<div id='ulp-layer-312' class='ulp-layer' style='width: 635px; height: 397px; font-size: 13px; left: 0px; top: 0px;'></div>
							<div id='ulp-layer-313' class='ulp-layer animated bounceInDown' style='width: 635px; font-size: 27px; left: 0px; top: 19px;'>PLEASE SHARE US!</div>
							<div id='ulp-layer-314' class='ulp-layer animated bounceInLeft' style='width: 397px; height: 3px; font-size: 27px; left: 119px; top: 79px;'></div>
							<div id='ulp-layer-315' class='ulp-layer animated bounceInDown' style='width: 555px; font-size: 13px; left: 39px; top: 99px;'>Vel eros amet amet mauris a habitasse scelerisque? Vel urna dis et, placerat phasellus, diam in! Placerat nec facilisis, tortor tristique. Arcu placerat sagittis, velit lorem scelerisque egestas. Lundium et, ultrices, et tempor vel proin est! Lundium sociis ac, ut ultricies ridiculus ultricies pulvinar scelerisque et adipiscing auctor, urna platea non rhoncus magna egestas montes platea sed porta nisi porta, mus integer porta elit.</div>
							<div id='ulp-layer-316' class='ulp-layer animated bounceInUp' style='width: 555px; font-size: 13px; left: 39px; top: 258px;'><div style='margin:0 15px;' class='ulp-social-button ulp-social-button-google-plusone'><div id='gplusshare' data-uhf='http://layeredpopups.com' style='text-indent: 0px; margin: 0px; padding: 0px; background: none repeat scroll 0% 0% transparent; border-style: none; float: none; line-height: normal; font-size: 1px; vertical-align: baseline; display: inline-block; width: 50px; height: 60px;'><iframe width='100%' frameborder='0' hspace='0' marginheight='0' marginwidth='0' scrolling='no' style='position: static; top: 0px; width: 50px; margin: 0px; border-style: none; left: 0px; visibility: visible; height: 60px;' tabindex='0' vspace='0' id='I1_1422699496912' name='I1_1422699496912' src='https://apis.google.com/se/0/_/+1/fastbutton?usegapi=1&amp;size=tall&amp;origin=https%3A%2F%2Flayeredpopups.com&amp;url=http%3A%2F%2Flayeredpopups.com%2F&amp;gsrc=3p&amp;jsh=m%3B%2F_%2Fscs%2Fapps-static%2F_%2Fjs%2Fk%3Doz.gapi.en_GB.qQyfm_LIxiY.O%2Fm%3D__features__%2Fam%3DEQ%2Frt%3Dj%2Fd%3D1%2Ft%3Dzcms%2Frs%3DAGLTcCMfmpf-E_5fAUYv5QdVcy9zEMcH9A#_methods=onPlusOne%2C_ready%2C_close%2C_open%2C_resizeMe%2C_renderstart%2Concircled%2Cdrefresh%2Cerefresh&amp;id=I1_1422699496912&amp;parent=https%3A%2F%2Flayeredpopups.com&amp;pfname=&amp;rpctoken=24385886' data-gapiattached='true' s13537183397987071108='true' replaced='true' title='+1'></iframe></div></div><div style='margin:0 15px;' class='ulp-social-button ulp-social-button-facebook-like'><fb:like layout='box_count' show_faces='false' href='http://layeredpopups.com/' id='fbLikeButton' class=' fb_iframe_widget' fb-xfbml-state='rendered' fb-iframe-plugin-query='app_id=739667286071364&amp;href=http%3A%2F%2Flayeredpopups.com%2F&amp;layout=box_count&amp;locale=en_US&amp;sdk=joey&amp;show_faces=false'><span style='vertical-align: bottom; width: 49px; height: 61px;'><div id='frame' data-uhf='https://www.facebook.com/pages/Find-Some-One/709885775797856'><iframe src='//www.facebook.com/plugins/like.php?href=https://www.facebook.com/pages/Find-Some-One/709885775797856&amp;width&amp;layout=box_count&amp;action=like&amp;show_faces=true&amp;share=false&amp;height=21' scrolling='no' frameborder='0' style='border:none; overflow:hidden; height:101px;' allowTransparency='true'></iframe></div> </span></fb:like></div><div style='margin:0 15px;' class='ulp-social-button ulp-social-button-twitter-tweet'><iframe data-uhf='https://twitter.com/sksanjstyle' class='twwiget' frameborder='0' id='twitter-widget-1' scrolling='no' allowtransparency='true' src='https://platform.twitter.com/widgets/tweet_button.67ae45a68af44ab435dd5797206058d3.en.html#_=1422699496890&amp;count=vertical&amp;dnt=false&amp;id=twitter-widget-1&amp;lang=en&amp;original_referer=https://twitter.com/sksanjstyle;size=m&amp;url=https://twitter.com/sksanjstyle' class='twitter-share-button twitter-tweet-button twitter-share-button twitter-count-vertical' title='Twitter Tweet Button' data-twttr-rendered='true' style='width: 58px; height: 62px;' s13537183397987071108='true' replaced='true'></iframe></div><div style='margin:0 15px;' class='ulp-social-button ulp-social-button-linkedin-share'><span style='line-height: 1; vertical-align: baseline; display: inline-block; text-align: center;' class='IN-widget'><div id='frameLinkedin' data-uhf='http://facebook.com'><script src='//platform.linkedin.com/in.js' type='text/javascript'> lang: en_US</script><script id='newData' type='IN/Share' data-url='' data-counter='top'></script></div></div></div>
							<div id='ulp-layer-317' class='ulp-layer animated bounceInDown' style='width: 31px; height: 31px; font-size: 31px; left: 603px; top: 0px;'><a onclick='return ulp_self_close();' href='#'>x</a></div>
							<div id='ulp-layer-318' class='ulp-layer' style='width: 635px; height: 3px; font-size: 27px; left: 0px; top: 393px;'></div>
						</div></div>";
echo $txthtml;
						
						
					?>	
					
					
	<div style="margin-top:30px;">										
						
<table width="97%" border="0">
  
    <td><label>Layer one Color :</label></td>
    <td><input class="color boxcolor" value="66ff00" id="layer1_color" onchange="layer1_color();"></td>
    <td><label>Layer One Text :</label></td>
    <td><input type="text" value="" id="layer1_txt" onkeypress="layer1_txt();" maxlength="30" /></td>
      <td>Google Plus URL</td>
    <td><input id="gplussharewlink" type='text' onblur='changeGplusFrame(this.value)'></input></td>
  </tr>
   <tr>
    <td><label>Layer Color :</label></td>
    <td><input class="color boxcolor" value="66ff00" id="layer3_color" onchange="layer3_color();"></td>
    <td>Facebook Like URL</td>
    <td><input id="fbsharewlink" type='text' onblur='changeFrame(this.value)'></input></td>
    
  </tr>
  
   <tr>
    <td><label>Layer Two Color :</label></td>
    <td><input class="color boxcolor" value="66ff00" id="layer2_color" onchange="layer2_color();"></td>
    <td><label>Layer Two Text :</label></td>
    <td><textarea type="text" value="" id="layer2_txt" onkeypress="layer2_txt();"></textarea></td>
    <td>Twitter Share Link</td>
    <td><input type="text" value="" id="twsharewlink" onkeyup="twsharewlink();"  /></td>
  </tr>
  
 <tr>
 <td>Linked In Share URL</td>
 <td><input id='linksh' type='text' onblur='changeLinkedinFrame(this.value)'></input></td>
 </tr>
  
   <tr>
    <td>Close Button Background</td>
    <td><input class="color boxcolor" value="66ff00" id="buttonclose_bkgcolor" onchange="buttonclose_bkgcolor();"></td>
  </tr>
  
</table>

</div>              


<script type="text/javascript">
function pop_layer_data()
{
	 var layer1_txt=$("#ulp-layer-313").html();
	 var layer2_txt=$("#ulp-layer-315").html();
	

	$("#layer1_txt").val(layer1_txt);
	$("#layer2_txt").val(layer2_txt);
$("#twsharewlink").val($('.twwiget').attr('data-uhf'));
	$("#fbsharewlink").val($('#frame').attr('data-uhf'));
	$("#gplussharewlink").val($('#gplusshare').attr('data-uhf'));
$("#linksh").val($('#frameLinkedin').attr('data-uhf'));
	
}
	                  function layer1_color()
						{
							var fcolor="#"+$("#layer1_color").val();
							//alert(bgcolor);
							$("#ulp-layer-313").css("color",fcolor);
						}
						function layer1_txt()
						{
							var layer1_txt=$("#layer1_txt").val();
							//alert(bgcolor);
							$("#ulp-layer-313").html(layer1_txt);
						}
						function layer2_color()
						{
							var fcolor="#"+$("#layer2_color").val();
							//alert(bgcolor);
							$("#ulp-layer-315").css("color",fcolor);
						}
						function layer2_txt()
						{
							var layer2_txt=$("#layer2_txt").val();
							//alert(bgcolor);
							$("#ulp-layer-315").html(layer2_txt);
						}
						
						
						function layer3_color()
						{
							var fcolor="#"+$("#layer3_color").val();
						    //alert(fcolor);
							$("#ulp-layer-314").css("background",fcolor);
						}
						
					
						
						function buttonclose_bkgcolor()
						{
							var bkgcolor="#"+$("#buttonclose_bkgcolor").val();
							//alert(bgcolor);
							$("#ulp-layer-317").css("background-color",bkgcolor);
						}
						
						function twsharewlink()
						{
							var twurl=$("#twsharewlink").val();
							
					

						var ssc="https://platform.twitter.com/widgets/tweet_button.67ae45a68af44ab435dd5797206058d3.en.html#_=1422699496890&count=vertical&dnt=false&id=twitter-widget-1&lang=en&original_referer="+twurl+";size=m&url="+twurl;
							$(".twwiget").attr("src",ssc);
							$(".twwiget").attr("data-uhf",ssc);
						}


						function changeFrame(data)
						{
						 
						 document.getElementById('frame').innerHTML = "<iframe src='//www.facebook.com/plugins/like.php?href="+data+"&amp;width&amp;layout=box_count&amp;action=like&amp;show_faces=true&amp;share=false&amp;height=21' scrolling='no' frameborder='0' style='border:none; overflow:hidden; height:101px;' allowTransparency='true'></iframe>";
						 $("#frame").attr("data-uhf",data);

						}
					
							function changeGplusFrame(data)
						{
							
						 
						 document.getElementById('gplusshare').innerHTML = "<iframe width='100%' frameborder='0' hspace='0' marginheight='0' marginwidth='0' scrolling='no' style='position: static; top: 0px; width: 50px; margin: 0px; border-style: none; left: 0px; visibility: visible; height: 60px;' tabindex='0' vspace='0' id='I1_1422699496912' name='I1_1422699496912' src='https://apis.google.com/se/0/_/+1/fastbutton?usegapi=1&amp;size=tall&amp;origin="+data+"&amp;url="+data+"%2F&amp;gsrc=3p&amp;jsh=m%3B%2F_%2Fscs%2Fapps-static%2F_%2Fjs%2Fk%3Doz.gapi.en_GB.qQyfm_LIxiY.O%2Fm%3D__features__%2Fam%3DEQ%2Frt%3Dj%2Fd%3D1%2Ft%3Dzcms%2Frs%3DAGLTcCMfmpf-E_5fAUYv5QdVcy9zEMcH9A#_methods=onPlusOne%2C_ready%2C_close%2C_open%2C_resizeMe%2C_renderstart%2Concircled%2Cdrefresh%2Cerefresh&amp;id=I1_1422699496912&amp;parent="+data+"&amp;pfname=&amp;rpctoken=24385886' data-gapiattached='true' s13537183397987071108='true' replaced='true' title='+1'></iframe>";
						 $("#gplusshare").attr("data-uhf",data);

						}
						function changeLinkedinFrame(data)
						{
						 var din ="<script id='holderLink' type='IN/Share' data-url="+data+" data-counter='top'></\script>";
						 $("#frameLinkedin").html(din);
						 IN.parse(); 
						}
						</script>