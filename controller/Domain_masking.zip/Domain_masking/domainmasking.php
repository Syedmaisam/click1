<?php
include_once SOURCE_ROOT . 'classes/Domain_masking/domain_masking_classes.php';
class Domain_Controller {
	public $objDomain;
	public $userData;
	public function __construct()
	{
		$this->objDomain = new Domain_Class(MASKING_DOMAIN,MASKING_USER_NAME,MASKING_USER_PASSWORD,MASKING_IP,MASKING_PORT);
		$this->userData = $_SESSION['user'];
	}
	public function addOnDomain($domianName)
	{
		//echo MASKING_DOMAIN.",".MASKING_USER_NAME.",".MASKING_USER_NAME.",".MASKING_IP.",".MASKING_PORT;
		$retunData = $this->objDomain->addOnDomain($domianName,$this->userData['id']);
		return $retunData;
		//			var_dump($retunData);exit;
		//			$arrReturnData =explode('.',$domianName);
		//			if($retunData->error!='')
		//			{
		//				$msg = "Alredy exits";
		//
		//			} else
		//			{
		//				$url = $domianName.'/wp-admin';
		//				$arrReturnData =explode('.',$domianName);
		//				$retunData = $this->objWordpress->saveConsoleInfo($domianName,$blogTitle,'admin','admin',$url,'',$addDomain);
		//				$this->objDomain->extractFolderOnDomain($arrReturnData[0],$comment,$blogTitle,$tagLine,$domianName,$email,$dsetting,$contactform7,$optinNinja,$seo_pack);
		//				if($addDomain==1){
		//					$this->objWordpress->saveDomain($domianName,'admin','admin','us','wp-verify','key-verify');
		//				}
		//				$msg = "created";
		//			}
		//return $msg;
	}
	public function extractDomain($web_dir_name)
	{
		$this->objDomain->extractDomain($web_dir_name);
	}

}
?>