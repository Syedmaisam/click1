<link rel="stylesheet" href="<?php echo SITE_ROOT_URL; ?>views/layered/animatemaster/animate.min.css">
<style>
body
{
margin:0px;
padding:0px;
}
.ulp-content {
    position: relative;
}
#ulp-layer-122 {
    text-align: left;
    z-index: 1000003;
}
#ulp-layer-122, #ulp-layer-122 p, #ulp-layer-122 a, #ulp-layer-122 span, #ulp-layer-122 li, #ulp-layer-122 input, #ulp-layer-122 button, #ulp-layer-122 textarea {
    color: #000000;
    font-family: "arial",arial;
    font-weight: 400;
}
.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}

.ulp-layer img {
    border: medium none !important;
    box-shadow: none !important;
    margin: 0 !important;
    max-width: 100% !important;
    min-width: 0 !important;
    padding: 0 !important;
}
img {
    max-width: 100%;
}
#ulp-layer-123 {
    text-align: left;
    z-index: 1000007;
}
#ulp-layer-123, #ulp-layer-123 p, #ulp-layer-123 a, #ulp-layer-123 span, #ulp-layer-123 li, #ulp-layer-123 input, #ulp-layer-123 button, #ulp-layer-123 textarea {
    color: #000000;
    font-family: "arial",arial;
    font-weight: 400;
}
.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}
iframe {
    border: 0 none;
    width: 100%;
}
html, body, div, section, article, aside, header, hgroup, footer, nav, h1, h2, h3, h4, h5, h6, p, a, blockquote, address, time, span, em, strong, img, ol, ul, li, figure, canvas, video, th, td, tr, iframe {

    list-style: outside none none;
    margin: 0;
    padding: 0;
    text-decoration: none;
    vertical-align: baseline;
}
#ulp-layer-123 {
    text-align: left;
}
#ulp-layer-123, #ulp-layer-123 p, #ulp-layer-123 a, #ulp-layer-123 span, #ulp-layer-123 li, #ulp-layer-123 input, #ulp-layer-123 button, #ulp-layer-123 textarea {
    color: #000000;
}
#ulp-layer-124 {
    padding: 10px 20px;
    text-align: center;
    z-index: 1000007;
}
#ulp-layer-124, #ulp-layer-124 p, #ulp-layer-124 a, #ulp-layer-124 span, #ulp-layer-124 li, #ulp-layer-124 input, #ulp-layer-124 button, #ulp-layer-124 textarea {
    color: #ffffff;
    font-family: "Open Sans",arial;
    font-weight: 400;
    text-shadow: 1px 1px 1px #000000;
}
.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}
#ulp-layer-125 {
    text-align: right;
    z-index: 1000007;
}
#ulp-layer-125, #ulp-layer-125 p, #ulp-layer-125 a, #ulp-layer-125 span, #ulp-layer-125 li, #ulp-layer-125 input, #ulp-layer-125 button, #ulp-layer-125 textarea {
    color: #ffffff;
    font-family: "arial",arial;
    font-weight: 700;
    text-shadow: 1px 1px 1px #3a3a3a;
}
.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}
#ulp-layer-125, #ulp-layer-125 p, #ulp-layer-125 a, #ulp-layer-125 span, #ulp-layer-125 li, #ulp-layer-125 input, #ulp-layer-125 button, #ulp-layer-125 textarea {
    color: #ffffff;
    font-family: "arial",arial;
    font-weight: 700;
    text-shadow: 1px 1px 1px #3a3a3a;
}
.ulp-window a {
    text-decoration: none !important;
}
a, .contactForm input[type="text"]:focus, .contactForm input[type="email"]:focus, .contactForm textarea:focus, input#formSubmit, .errorForm, #subscribe input[type="email"]:focus, .errorSubs, .servSingle, #toTop i, #notForm input[type="email"]:focus, .contactForm input#submit, #loginForm input, #loginForm input[type="text"]:focus, #loginForm input[type="password"]:focus {
    transition: all 0.5s ease 0s;
}
a, a:active, a:hover {
    outline: medium none;
}


table
{
	margin:20px;
	background:#f8f8f8;
	
}
table td
{
	padding:10px;
	border:1px solid #ccc;
}
table td label
{
	font-family:Arial, Helvetica, sans-serif;
	font-size:14px;
	font-weight:normal;
}
table td input[type='text']
{
	border:none;
	padding:10px;
	font-size:12px;
	font-weight:normal;
	border:1px solid #ccc;
	width:300px;
}
table td textarea
{
	width:300px;
	font-size:12px;
}
#updateform
{
	background:#019ad2;
	color:#fff;
	font-size:16px;
	padding:10px;
	border:1px solid #019ad2;
	width:100px;
}
</style>

<?php

$txthtml="<div id='popupform' style='position:relative;'><div class='ulp-content ' style='width: 650px; height: 400px; margin: 5% auto auto;'>
                            
							<div id='ulp-layer-122' class='ulp-layer' style='width: 650px; height: 400px; font-size: 14px; left: 0px; top: 0px; display: block;'><img alt='' src='https://layeredpopups.com/layered-popups/images/default/macbook.png'></div>
							<div id='ulp-layer-123' class='ulp-layer' style='width: 490px; height: 320px; font-size: 14px; left: 80px; top: 30px;'><iframe width='640' height='320' src='https://www.youtube.com/embed/Rk6_hdRtJOE?feature=player_detailpage' frameborder='0' allowfullscreen></iframe></div>
							<div  id='ulp-layer-124' class='ulp-layer animated fadeInLeftBig' style='width: 650px; font-size: 24px; left: 0px; top: -40px;'>ENJOY AURORA BOREALIS</div>
							<div id='ulp-layer-125' class='ulp-layer' style='width: 650px; height: 25px; font-size: 20px; left: 0px; top: -25px;'><a onclick='return ulp_self_close();' href='#'>x</a></div>
						</div>
		          </div>
                     ";
					echo $txthtml;
					?>
					
<div>

<table width="97%" border="0">
 
  <tr>
    <td><label>Heading One Text :</label></td>
    <td><input type="text" value="" id="heading1_txt" onkeypress="heading1_txt();" maxlength="30" /></td>
     <td><label>Video Link :</label></td>
    <td><input type="text" value="" id="Link_txt" onkeyup="Link_txt();"  /></td>
  
  </tr>
<tr>
 <td><label>Heading One color :</label></td>
  <td><input class="color boxcolor" value="66ff00" id="heading1_color" onchange="heading1_color();"></td>
</tr>

</table>

</div>                       
<script type="text/javascript">
function pop_layer_data()
{
	var heading1_txt=$("#ulp-layer-124").html();
	var heading2_txt=$("#ulp-layer-123  iframe").attr('src');
	 $("#heading1_txt").val(heading1_txt);
	 $("#Link_txt").val(heading2_txt);
	 
}
						function heading1_txt()
						{
							var heading1_txt=$("#heading1_txt").val();
							$("#ulp-layer-124").html(heading1_txt);
						}
                                                function heading1_color()
						{
							var fcolor="#"+$("#heading1_color").val();
							$("#ulp-layer-124").css("color",fcolor);
						}
						
						function Link_txt()
						{
							var heading2_txt=$("#Link_txt").val();
var sc1=$("#ulp-layer-123 iframe").attr("src");
var sc2=sc1.split("/");


$.ajax({
		type: "post",
		url: location.protocol + '//' + location.host+'/click/views/layered/vidup.php',
		data: {
		id:heading2_txt
	},			
	success: function(response) {

var sclr=sc1.replace(sc2[4],response);
sclr=sclr+"?feature=player_detailpage";

		$("#ulp-layer-123 iframe").attr("src",sclr);
		
	},
	error:function 
	(XMLHttpRequest, textStatus, errorThrown) {
	}
	}); 
							
							
						}
					
						
						function updateform()
						{
							var popupform= $("#popupform").html();
							
							$.ajax({
							type: "post",
							url: 'animatemaster/updatepop1.php',
							data: {
							popupform: popupform,
							},			
							success: function(response) {
								//alert(response);
							},
							error:function 
							(XMLHttpRequest, textStatus, errorThrown) {
							}
							});  
							
						}
</script>


                     