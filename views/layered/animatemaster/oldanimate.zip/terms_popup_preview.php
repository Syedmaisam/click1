<link rel="stylesheet" href="http://www.cliks.it/click/views/layered/animatemaster/animate.min.css">
<style>
body
{
margin:0px;
padding:0px;
}
.ulp-content {
    position: relative;
}
#ulp-layer-365 {
    border-radius: 5px;
    box-shadow: 0 4px 20px rgba(32, 32, 32, 1), 0 0 60px rgba(0, 0, 0, 0.1) inset;
    text-align: left;
    z-index: 1000004;
}
#ulp-layer-365, #ulp-layer-365 p, #ulp-layer-365 a, #ulp-layer-365 span, #ulp-layer-365 li, #ulp-layer-365 input, #ulp-layer-365 button, #ulp-layer-365 textarea {
    color: #000000;
    font-family: "arial",arial;
    font-weight: 400;
}
.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}
#ulp-layer-366 {
    background-color: rgba(55, 124, 143, 1);
    border-radius: 5px 5px 0 0;
    text-align: left;
    z-index: 1000003;
}
#ulp-layer-366, #ulp-layer-366 p, #ulp-layer-366 a, #ulp-layer-366 span, #ulp-layer-366 li, #ulp-layer-366 input, #ulp-layer-366 button, #ulp-layer-366 textarea {
    color: #000000;
    font-family: "arial",arial;
    font-weight: 400;
}
.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}
#ulp-layer-367 {
    background-color: rgba(249, 239, 212, 1);
    border-radius: 0 0 5px 5px;
    text-align: left;
    z-index: 1000003;
}
#ulp-layer-367, #ulp-layer-367 p, #ulp-layer-367 a, #ulp-layer-367 span, #ulp-layer-367 li, #ulp-layer-367 input, #ulp-layer-367 button, #ulp-layer-367 textarea {
    color: #000000;
    font-family: "arial",arial;
    font-weight: 400;
}
.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}
#ulp-layer-368 {
    text-align: center;
    z-index: 1000007;
}
#ulp-layer-368, #ulp-layer-368 p, #ulp-layer-368 a, #ulp-layer-368 span, #ulp-layer-368 li, #ulp-layer-368 input, #ulp-layer-368 button, #ulp-layer-368 textarea {
    color: #ffffff;
    font-family: "arial",arial;
    font-weight: 700;
    text-shadow: 1px 1px 1px #00303d;
}
.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}
#ulp-layer-369 {
    background-color: rgba(0, 48, 61, 0.5);
    border-bottom: 1px solid #71a8a2;
    text-align: left;
    z-index: 1000007;
}
#ulp-layer-369, #ulp-layer-369 p, #ulp-layer-369 a, #ulp-layer-369 span, #ulp-layer-369 li, #ulp-layer-369 input, #ulp-layer-369 button, #ulp-layer-369 textarea {
    color: #000000;
    font-family: "arial",arial;
    font-weight: 400;
}
.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}
#ulp-layer-370 {
    overflow-x: hidden;
    padding: 0 20px;
    text-align: justify;
    z-index: 1000007;
}
#ulp-layer-370, #ulp-layer-370 p, #ulp-layer-370 a, #ulp-layer-370 span, #ulp-layer-370 li, #ulp-layer-370 input, #ulp-layer-370 button, #ulp-layer-370 textarea {
    color: #ffffff;
    font-family: "arial",arial;
    font-weight: 400;
    text-shadow: 1px 1px 1px #002e3d;
}
.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}
#ulp-layer-371 {
    text-align: center;
    z-index: 1000007;
}
#ulp-layer-371, #ulp-layer-371 p, #ulp-layer-371 a, #ulp-layer-371 span, #ulp-layer-371 li, #ulp-layer-371 input, #ulp-layer-371 button, #ulp-layer-371 textarea {
    color: #ffffff;
    font-family: "arial",arial;
    font-weight: 400;
}
.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}
.ulp-link-button:before {
    content: "";
    display: inline-block;
    height: 100%;
    padding-top: 3px;
    vertical-align: middle;
}
#ulp-layer-371, #ulp-layer-371 p, #ulp-layer-371 a, #ulp-layer-371 span, #ulp-layer-371 li, #ulp-layer-371 input, #ulp-layer-371 button, #ulp-layer-371 textarea {
    color: #ffffff;
    font-family: "arial",arial;
    font-weight: 400;
}
.ulp-window a {
    text-decoration: none !important;
}
.ulp-link-button-red, .ulp-link-button-red:visited {
    background-color: rgb(255, 48, 25);
    background-image: linear-gradient(to bottom, rgba(255, 48, 25, 1) 0%, rgba(207, 4, 4, 1) 100%);
    border: 1px solid #b20000;
}
.ulp-link-button, .ulp-link-button:hover, .ulp-link-button:active, .ulp-link-button:focus, .ulp-link-button:visited {
    border-radius: 5px !important;
    box-shadow: 0 1px 0 rgba(255, 255, 255, 0.3) inset, 0 0 3px rgba(255, 255, 255, 0.5) inset, 0 1px 1px rgba(0, 0, 0, 0.3) !important;
    box-sizing: border-box !important;
    display: block !important;
    height: 100% !important;
    text-decoration: none !important;
    text-shadow: 0 -1px 0 rgba(0, 0, 0, 0.2) !important;
    transition-duration: 0.5s !important;
}
a, .contactForm input[type="text"]:focus, .contactForm input[type="email"]:focus, .contactForm textarea:focus, input#formSubmit, .errorForm, #subscribe input[type="email"]:focus, .errorSubs, .servSingle, #toTop i, #notForm input[type="email"]:focus, .contactForm input#submit, #loginForm input, #loginForm input[type="text"]:focus, #loginForm input[type="password"]:focus {
    transition: all 0.5s ease 0s;
}
a, a:active, a:hover {
    outline: medium none;
}
#ulp-layer-372 {
    text-align: center;
    z-index: 1000007;
}
#ulp-layer-372, #ulp-layer-372 p, #ulp-layer-372 a, #ulp-layer-372 span, #ulp-layer-372 li, #ulp-layer-372 input, #ulp-layer-372 button, #ulp-layer-372 textarea {
    color: #ffffff;
    font-family: "arial",arial;
    font-weight: 700;
}
.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}
.ulp-link-button:before {
    content: "";
    display: inline-block;
    height: 100%;
    padding-top: 3px;
    vertical-align: middle;
}
#ulp-layer-372, #ulp-layer-372 p, #ulp-layer-372 a, #ulp-layer-372 span, #ulp-layer-372 li, #ulp-layer-372 input, #ulp-layer-372 button, #ulp-layer-372 textarea {
    color: #ffffff;
    font-family: "arial",arial;
    font-weight: 700;
}
.ulp-window a {
    text-decoration: none !important;
}
.ulp-link-button-green, .ulp-link-button-green:visited {
    background-color: rgb(72, 180, 36);
    background-image: -moz-linear-gradient(center top , rgba(72, 180, 36, 1) 0%, rgba(48, 120, 24, 1) 100%);
    border: 1px solid #307818;
}
.ulp-link-button, .ulp-link-button:hover, .ulp-link-button:active, .ulp-link-button:focus, .ulp-link-button:visited {
    border-radius: 5px !important;
    box-shadow: 0 1px 0 rgba(255, 255, 255, 0.3) inset, 0 0 3px rgba(255, 255, 255, 0.5) inset, 0 1px 1px rgba(0, 0, 0, 0.3) !important;
    box-sizing: border-box !important;
    display: block !important;
    height: 100% !important;
    text-decoration: none !important;
    text-shadow: 0 -1px 0 rgba(0, 0, 0, 0.2) !important;
    transition-duration: 0.5s !important;
}
.ulp-layer::-webkit-scrollbar {
	width: 5px;
}
.ulp-layer::-webkit-scrollbar-track {
	box-shadow: inset 0 0 6px rgba(0,0,0,0.3);
}
.ulp-layer::-webkit-scrollbar-thumb {
	background-color: #006080;
}

</style>


<div id='popupform_preview' style="display:none;"><div class="ulp-content "  style="width: 422px; height: 422px; margin:auto;position:fixed; left:30%; top:15%;">
							<div id="ulp-layer-365" class="ulp-layer " style="width: 442px; height: 442px; font-size: 11px; left: 0px; top: 0px; display: block;"></div>
							<div id="ulp-layer-366" class="ulp-layer animated fadeInDown" style="width: 442px; height: 368px; font-size: 11px; left: 0px; top: 0px;"></div>
							<div id="ulp-layer-367" class="ulp-layer animated fadeInUp" style="width: 442px; height: 73px; font-size: 11px; left: 0px; top: 368px;"></div>
							<div id="ulp-layer-368" class="ulp-layer animated zoomInUp" style="width: 442px; font-size: 18px; left: 0px; top: 12px;">TERMS &amp; CONDITIONS</div>
							<div id="ulp-layer-369" class="ulp-layer" style="width: 442px; height: 1px; font-size: 11px; left: 0px; top: 49px; display: block;"></div>
							<div id="ulp-layer-370" class="ulp-layer" style="width: 442px; height: 302px; font-size: 11px; left: 0px; top: 57px; display: block;">

Vut diam quis sociis. Scelerisque placerat? Hac lorem odio, tincidunt a turpis, eu ut purus elementum, amet auctor nunc porttitor sed, habitasse cras velit! Sed amet quis mus proin tortor vel lacus auctor elementum magna rhoncus, dictumst rhoncus scelerisque ut! Urna dictumst sit pulvinar, porttitor ac parturient mattis, tortor. Scelerisque facilisis nec risus ultricies purus, pulvinar eu risus habitasse ultrices. Tincidunt a tristique nascetur aenean scelerisque. Natoque vel turpis turpis aliquam magnis? Risus ultrices et ac scelerisque eu? Dis etiam? Mid elementum sed magna. Rhoncus ridiculus nunc adipiscing a placerat, turpis turpis porta turpis scelerisque! Hac, proin, ut nec etiam! Lacus ac enim magna? Ultricies turpis lorem placerat ultrices turpis quis. Lectus vel dolor tortor dis enim est duis habitasse.
<br>
Dapibus ut vel eu nisi ac pulvinar nunc velit sed proin mid! Sit massa odio mattis elit cursus augue. Elementum purus lorem porta, vut cras! Etiam turpis cursus porttitor, cras massa integer, amet auctor aliquam amet, amet placerat? Tincidunt nunc enim, velit turpis magna lacus adipiscing phasellus et, velit, ac! Natoque ultrices mauris, nec amet magna augue mus purus! Duis ac, mattis scelerisque? Aliquet arcu urna, in ut, lacus ac, est, sociis platea tortor habitasse, sagittis urna, in est porta et turpis duis adipiscing cum montes aliquet enim sociis. Amet nunc, arcu pulvinar non duis? Risus pulvinar. Ac placerat amet, phasellus pellentesque tristique! Cursus integer! Lectus nunc augue purus, urna ac montes cum, et amet. Dolor nec, auctor sed.
<br>
Lorem dolor platea placerat, pellentesque! Magnis ultrices? Eros tincidunt aliquam elit! Aenean. Nec aenean urna? Vut lundium placerat lectus eu placerat, sed, eu, cursus cras parturient sociis nunc scelerisque in sed ut scelerisque ac, cras! Vel dignissim pulvinar et, dapibus amet quis cursus! Tincidunt tincidunt egestas sociis aliquam mus, placerat adipiscing? A vel porta scelerisque! Dis adipiscing augue urna, integer nunc magna vel cras, lundium lundium a nec tincidunt in elit ut ultricies porta magnis massa dapibus ac. Phasellus ultrices arcu, ut sed? A! Et et sociis! Quis cras, lacus turpis urna nascetur eu vel! Lundium nec! Magnis, cum! Odio, amet? Vel, scelerisque, aenean scelerisque nisi in, sed nec velit. Placerat? Eu facilisis, nunc dis dapibus et duis pid.
<br>
Auctor mauris, rhoncus montes arcu auctor augue lundium, elit velit quis scelerisque tempor penatibus! Sed pellentesque adipiscing adipiscing! Auctor mid? Et, lorem! Ultricies, massa ut rhoncus elementum risus magna! Nunc magna ac. Amet, ridiculus elementum! Porttitor enim integer enim, dignissim sagittis, urna natoque, rhoncus, vel! Montes risus, egestas integer dictumst augue vut et. Cursus! Nec? Montes, porttitor in diam? Non magnis et etiam! Nisi rhoncus nisi mattis. Non, ac, turpis ut, etiam penatibus urna, rhoncus scelerisque. Magna proin penatibus montes adipiscing amet facilisis magnis cras turpis nec integer dictumst? Auctor enim ridiculus enim vut? Pulvinar? Lundium tristique in turpis, in platea in a scelerisque turpis eros a! Risus ridiculus tempor in, lectus aliquam ultricies, in! Ut etiam aliquam enim.</div>

							<div id="ulp-layer-371" class="ulp-layer animated slideInLeft" style="width: 147px; height: 36px; font-size: 12px; left: 57px; top: 384px;"><a onclick="return ulp_self_close();" class="ulp-link-button ulp-link-button-red" href="#">No, I don't agree.</a></div>
							<div id="ulp-layer-372" class="ulp-layer animated slideInRight" style="width: 147px; height: 36px; font-size: 12px; left: 237px; top: 384px;"><a onclick="return ulp_close_forever();" class="ulp-link-button ulp-link-button-green" href="#">YES, I AGREE!</a></div>
						</div>

						
						<div id="blackscreen" style='width:100%; height:100%; background:#000; opacity:0.7; top:0; left:0; position:fixed; z-index:20000; display:none;'></div></div></div>
                        
                        
                        
<script>
function ulp_self_close()
{
	$("#popupform_preview").hide();
	$("#blackscreen").hide();
	$("#popup_content_data").html('');
}
</script>                        