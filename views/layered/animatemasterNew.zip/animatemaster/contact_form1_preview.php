<link rel="stylesheet" href="http://www.cliks.it/click/views/layered/animatemaster/animate.min.css">
<style>
body
{
margin:0px;
padding:0px;
}
.ulp-content {
    position: relative;
}
.ulp-window {
    text-align: left;
}
#ulp-layer-72 {
    background-color: rgba(141, 194, 62, 1);
    box-shadow: 0 4px 20px rgba(32, 32, 32, 1);
    text-align: left;
    z-index: 1000003;
}
#ulp-layer-72, #ulp-layer-72 p, #ulp-layer-72 a, #ulp-layer-72 span, #ulp-layer-72 li, #ulp-layer-72 input, #ulp-layer-72 button, #ulp-layer-72 textarea {
    color: #000000;
    font-family: "arial",arial;
    font-weight: 400;
}
.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}
#ulp-layer-73 {
    background-color: rgba(255, 255, 255, 1);
    text-align: left;
    z-index: 1000003;
}
#ulp-layer-73, #ulp-layer-73 p, #ulp-layer-73 a, #ulp-layer-73 span, #ulp-layer-73 li, #ulp-layer-73 input, #ulp-layer-73 button, #ulp-layer-73 textarea {
    color: #000000;
    font-family: "arial",arial;
    font-weight: 400;
}
.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}
iframe {
    width: 100%;
}
#ulp-layer-74 {
    background-color: rgba(0, 60, 117, 1);
    text-align: left;
    z-index: 1000007;
}
#ulp-layer-74, #ulp-layer-74 p, #ulp-layer-74 a, #ulp-layer-74 span, #ulp-layer-74 li, #ulp-layer-74 input, #ulp-layer-74 button, #ulp-layer-74 textarea {
    color: #34495e;
    font-family: "arial",arial;
    font-weight: 400;
}
.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}
#ulp-layer-75 {
    text-align: right;
    z-index: 1000007;
}
#ulp-layer-75, #ulp-layer-75 p, #ulp-layer-75 a, #ulp-layer-75 span, #ulp-layer-75 li, #ulp-layer-75 input, #ulp-layer-75 button, #ulp-layer-75 textarea {
    color: #f5f7f2;
    font-family: "arial",arial;
    font-weight: 700;
}
.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}
#ulp-layer-76 {
    text-align: right;
    z-index: 1000007;
}
#ulp-layer-76, #ulp-layer-76 p, #ulp-layer-76 a, #ulp-layer-76 span, #ulp-layer-76 li, #ulp-layer-76 input, #ulp-layer-76 button, #ulp-layer-76 textarea {
    color: #ffffff;
    font-family: "arial",arial;
    font-weight: 400;
}
.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}
#ulp-layer-76 {
    text-align: right;
}
#ulp-layer-77 {
    text-align: left;
    z-index: 1000007;
}
#ulp-layer-77, #ulp-layer-77 p, #ulp-layer-77 a, #ulp-layer-77 span, #ulp-layer-77 li, #ulp-layer-77 input, #ulp-layer-77 button, #ulp-layer-77 textarea {
    color: #000000;
    font-family: "arial",arial;
    font-weight: 400;
}
.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}
#ulp-layer-77 input.ulp-input {
    padding-left: 32px !important;
}
#ulp-aAQIvL3OZtSupwtI .ulp-input, #ulp-aAQIvL3OZtSupwtI .ulp-input:hover, #ulp-aAQIvL3OZtSupwtI .ulp-input:active, #ulp-aAQIvL3OZtSupwtI .ulp-input:focus {
    background-color: rgba(245, 247, 242, 1) !important;
    border-color: #ffffff;
    border-radius: 2px !important;
    border-width: 1px !important;
}
#ulp-layer-77, #ulp-layer-77 p, #ulp-layer-77 a, #ulp-layer-77 span, #ulp-layer-77 li, #ulp-layer-77 input, #ulp-layer-77 button, #ulp-layer-77 textarea {
    color: #000000;
    font-family: "arial",arial;
    font-weight: 400;
}
.ulp-input {
    background: none repeat scroll 0 0 rgba(255, 255, 255, 0.8);
    border-radius: 2px !important;
    border-spacing: 0 !important;
    border-style: solid !important;
    border-width: 1px !important;
    box-shadow: none !important;
    box-sizing: border-box !important;
    clear: both !important;
    font-size: inherit !important;
    height: 100% !important;
    line-height: 1.5 !important;
    margin: 0 !important;
    padding: 0 6px !important;
    vertical-align: middle !important;
    width: 100% !important;
}
input:-moz-read-write, textarea:-moz-read-write {
    -moz-user-modify: read-write !important;
}
input {
    -moz-appearance: textfield;
    -moz-binding: url("chrome://global/content/platformHTMLBindings.xml#inputFields");
    -moz-user-select: text;
    cursor: text;
    font: ;
    letter-spacing: normal;
    line-height: normal;
    padding: 1px;
    text-align: start;
    text-indent: 0;
    text-rendering: optimizelegibility;
    text-shadow: none;
    text-transform: none;
    word-spacing: normal;
}

.ulp-fa-input-table {
    display: table;
    height: 100%;
    left: 0;
    line-height: 100%;
    position: absolute;
    top: 0;
    vertical-align: middle;
}
#ulp-layer-77 {
    text-align: left;
}
#ulp-layer-77 div.ulp-fa-input-cell {
    padding-left: 4px !important;
    width: 28px !important;
}
.ulp-fa-input-cell {
    display: table-cell;
    opacity: 0.7;
    text-align: center;
    vertical-align: middle;
}
.fa-user:before {
    content: "";
}
.fa {
    display: inline-block;
    font-family: FontAwesome;
    font-feature-settings: normal;
    font-kerning: auto;
    font-language-override: normal;
    font-size: inherit;
    font-size-adjust: none;
    font-stretch: normal;
    font-style: normal;
    font-synthesis: weight style;
    font-variant: normal;
    font-weight: normal;
    line-height: 1;
    text-rendering: auto;
}
#ulp-layer-78 {
    text-align: left;
    z-index: 1000007;
}
#ulp-layer-78, #ulp-layer-78 p, #ulp-layer-78 a, #ulp-layer-78 span, #ulp-layer-78 li, #ulp-layer-78 input, #ulp-layer-78 button, #ulp-layer-78 textarea {
    color: #000000;
    font-family: "arial",arial;
    font-weight: 400;
    text-shadow: 1px 1px 1px #ffffff;
}
.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}
#ulp-layer-78 input.ulp-input {
    padding-left: 32px !important;
}
#ulp-aAQIvL3OZtSupwtI .ulp-input, #ulp-aAQIvL3OZtSupwtI .ulp-input:hover, #ulp-aAQIvL3OZtSupwtI .ulp-input:active, #ulp-aAQIvL3OZtSupwtI .ulp-input:focus {
    background-color: rgba(245, 247, 242, 1) !important;
    border-color: #ffffff;
    border-radius: 2px !important;
    border-width: 1px !important;
}
#ulp-layer-78, #ulp-layer-78 p, #ulp-layer-78 a, #ulp-layer-78 span, #ulp-layer-78 li, #ulp-layer-78 input, #ulp-layer-78 button, #ulp-layer-78 textarea {
    color: #000000;
    font-family: "arial",arial;
    font-weight: 400;
    text-shadow: 1px 1px 1px #ffffff;
}
.ulp-input {
    background: none repeat scroll 0 0 rgba(255, 255, 255, 0.8);
    border-radius: 2px !important;
    border-spacing: 0 !important;
    border-style: solid !important;
    border-width: 1px !important;
    box-shadow: none !important;
    box-sizing: border-box !important;
    clear: both !important;
    font-size: inherit !important;
    height: 100% !important;
    line-height: 1.5 !important;
    margin: 0 !important;
    padding: 0 6px !important;
    vertical-align: middle !important;
    width: 100% !important;
}
input:-moz-read-write, textarea:-moz-read-write {
    -moz-user-modify: read-write !important;
}
input {
    -moz-appearance: textfield;
    -moz-binding: url("chrome://global/content/platformHTMLBindings.xml#inputFields");
    -moz-user-select: text;
    cursor: text;
    font: ;
    letter-spacing: normal;
    line-height: normal;
    padding: 1px;
    text-align: start;
    text-indent: 0;
    text-rendering: optimizelegibility;
    text-transform: none;
    word-spacing: normal;
}

.ulp-fa-input-table {
    display: table;
    height: 100%;
    left: 0;
    line-height: 100%;
    position: absolute;
    top: 0;
    vertical-align: middle;
}
#ulp-layer-78 {
    text-align: left;
}
#ulp-layer-78, #ulp-layer-78 p, #ulp-layer-78 a, #ulp-layer-78 span, #ulp-layer-78 li, #ulp-layer-78 input, #ulp-layer-78 button, #ulp-layer-78 textarea {
    color: #000000;
    text-shadow: 1px 1px 1px #ffffff;
}
#ulp-layer-78 div.ulp-fa-input-cell {
    padding-left: 4px !important;
    width: 28px !important;
}
.ulp-fa-input-cell {
    display: table-cell;
    opacity: 0.7;
    text-align: center;
    vertical-align: middle;
}
.fa-envelope:before {
    content: "";
}
.fa {
    display: inline-block;
    font-family: FontAwesome;
    font-feature-settings: normal;
    font-kerning: auto;
    font-language-override: normal;
    font-size: inherit;
    font-size-adjust: none;
    font-stretch: normal;
    font-style: normal;
    font-synthesis: weight style;
    font-variant: normal;
    font-weight: normal;
    line-height: 1;
    text-rendering: auto;
}
#ulp-layer-79 {
    text-align: left;
    z-index: 1000007;
}
#ulp-layer-79, #ulp-layer-79 p, #ulp-layer-79 a, #ulp-layer-79 span, #ulp-layer-79 li, #ulp-layer-79 input, #ulp-layer-79 button, #ulp-layer-79 textarea {
    color: #000000;
    font-family: "arial",arial;
    font-weight: 400;
    text-shadow: 1px 1px 1px #ffffff;
}
.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}
#ulp-aAQIvL3OZtSupwtI .ulp-input, #ulp-aAQIvL3OZtSupwtI .ulp-input:hover, #ulp-aAQIvL3OZtSupwtI .ulp-input:active, #ulp-aAQIvL3OZtSupwtI .ulp-input:focus {
    background-color: rgba(245, 247, 242, 1) !important;
    border-color: #ffffff;
    border-radius: 2px !important;
    border-width: 1px !important;
}
#ulp-layer-79, #ulp-layer-79 p, #ulp-layer-79 a, #ulp-layer-79 span, #ulp-layer-79 li, #ulp-layer-79 input, #ulp-layer-79 button, #ulp-layer-79 textarea {
    color: #000000;
    font-family: "arial",arial;
    font-weight: 400;
    text-shadow: 1px 1px 1px #ffffff;
}
.ulp-input {
    background: none repeat scroll 0 0 rgba(255, 255, 255, 0.8);
    border-radius: 2px !important;
    border-spacing: 0 !important;
    border-style: solid !important;
    border-width: 1px !important;
    box-shadow: none !important;
    box-sizing: border-box !important;
    clear: both !important;
    font-size: inherit !important;
    height: 100% !important;
    line-height: 1.5 !important;
    margin: 0 !important;
    padding: 0 6px !important;
    vertical-align: middle !important;
    width: 100% !important;
}
input:-moz-read-write, textarea:-moz-read-write {
    -moz-user-modify: read-write !important;
}
textarea {
    -moz-appearance: textfield-multiline;
    -moz-binding: url("chrome://global/content/platformHTMLBindings.xml#textAreas");
    -moz-user-select: text;
    cursor: text;
    letter-spacing: normal;
    margin: 1px 0;
    padding: 0 1px;
    resize: both;
    text-align: start;
    text-indent: 0;
    text-rendering: optimizelegibility;
    text-transform: none;
    vertical-align: text-bottom;
    word-spacing: normal;
    word-wrap: break-word;
}
#ulp-layer-80 {
    text-align: center;
    z-index: 1000007;
}
#ulp-layer-80, #ulp-layer-80 p, #ulp-layer-80 a, #ulp-layer-80 span, #ulp-layer-80 li, #ulp-layer-80 input, #ulp-layer-80 button, #ulp-layer-80 textarea {
    color: #ffffff;
    font-family: "arial",arial;
    font-weight: 400;
    text-shadow: 1px 1px 1px #000000;
}
.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}
#ulp-aAQIvL3OZtSupwtI .ulp-submit, #ulp-aAQIvL3OZtSupwtI .ulp-submit:visited {
    background: linear-gradient(#002c56, #003c75) repeat scroll 0 0 #003c75;
    border: 1px solid #003c75;
    border-radius: 2px !important;
}
#ulp-layer-80, #ulp-layer-80 p, #ulp-layer-80 a, #ulp-layer-80 span, #ulp-layer-80 li, #ulp-layer-80 input, #ulp-layer-80 button, #ulp-layer-80 textarea {
    color: #ffffff;
    font-family: "arial",arial;
    font-weight: 400;
    text-shadow: 1px 1px 1px #000000;
}
.ulp-window a {
    text-decoration: none !important;
}
.ulp-submit, .ulp-submit:visited, .ulp-submit-button, .ulp-submit-button:visited {
    border-radius: 2px;
    box-shadow: none;
    cursor: pointer;
    display: inline-block;
    font-size: inherit !important;
    height: auto;
    line-height: 1.5;
    margin: 0;
    padding: 5px 20px;
    position: relative;
    text-decoration: none !important;
    transition-duration: 0.3s;
    white-space: nowrap;
    width: auto;
}
#ulp-layer-80, #ulp-layer-80 p, #ulp-layer-80 a, #ulp-layer-80 span, #ulp-layer-80 li, #ulp-layer-80 input, #ulp-layer-80 button, #ulp-layer-80 textarea {
    color: #ffffff;
    text-shadow: 1px 1px 1px #000000;
}
.ulp-submit, .ulp-submit:visited, .ulp-submit-button, .ulp-submit-button:visited {
    cursor: pointer;
    font-size: inherit !important;
    white-space: nowrap;
	background: linear-gradient(#002c56, #003c75) repeat scroll 0 0 #003c75;
}
.fa-sign-in:before {
    content: "";
}
.fa {
    display: inline-block;
    font-family: FontAwesome;
    font-feature-settings: normal;
    font-kerning: auto;
    font-language-override: normal;
    font-size: inherit;
    font-size-adjust: none;
    font-stretch: normal;
    font-style: normal;
    font-synthesis: weight style;
    font-variant: normal;
    font-weight: normal;
    line-height: 1;
    text-rendering: auto;
}

#ulp-layer-81 {
    text-align: right;
    z-index: 1000007;
}
#ulp-layer-81, #ulp-layer-81 p, #ulp-layer-81 a, #ulp-layer-81 span, #ulp-layer-81 li, #ulp-layer-81 input, #ulp-layer-81 button, #ulp-layer-81 textarea {
    color: #ffffff;
    font-family: "arial",arial;
    font-weight: 400;
    text-shadow: 1px 1px 1px #000000;
}
.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}
</style>


<div id='popupform_preview' style="display:none;"><div class='ulp-content' style='z-index:99999;width: 700px; height: 430px; margin:auto;position:fixed; left:28%; top:15%;'>
							<div id="ulp-layer-72" class="ulp-layer" style="width: 700px; height: 400px; font-size: 14px; left: 0px; top: 0px;"></div>
							<div id="ulp-layer-73" class="ulp-layer animated fadeInLeftBig" style="width: 350px; height: 400px; font-size: 14px; left: 0px; top: 0px;"><iframe width="100%" height="100%" frameborder="0" style="border:0" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d6044.275637456805!2d-73.98346368325204!3d40.75899341147853!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x55194ec5a1ae072e!2sTimes+Square!5e0!3m2!1sen!2s!4v1392901318461"></iframe></div>
							<div id="ulp-layer-74" class="ulp-layer animated bounceIn" style="width: 3px; height: 400px; font-size: 14px; left: 350px; top: 0px;"></div>
							<div id="ulp-layer-75" class="ulp-layer animated fadeInRight" style="width: 330px; font-size: 22px; left: 350px; top: 15px;">CONTACT US</div>
							<div id="ulp-layer-76" class="ulp-layer animated fadeInRightBig" style="width: 310px; font-size: 14px; left: 370px; top: 52px;">221, Mount Olimpus, Rheasilvia, Mars,<br> Solar System, Milky Way Galaxy<br> +1 (999) 999-99-99</div>
							<div id="ulp-layer-77" class="ulp-layer animated fadeInDownBig" style="width: 310px; height: 36px; font-size: 14px; left: 370px; top: 125px;"><input type="text" onfocus="jQuery(this).removeClass('ulp-input-error');" value="" placeholder="Enter your name..." name="ulp-name" class="ulp-input"><div class="ulp-fa-input-table"><div class="ulp-fa-input-cell"><i class="fa fa-user"></i></div></div></div>
							<div id="ulp-layer-78" class="ulp-layer animated fadeInDownBig" style="width: 310px; height: 36px; font-size: 14px; left: 370px; top: 170px;"><input type="text" onfocus="jQuery(this).removeClass('ulp-input-error');" value="" placeholder="Enter your e-mail..." name="ulp-email" class="ulp-input"><div class="ulp-fa-input-table"><div class="ulp-fa-input-cell"><i class="fa fa-envelope"></i></div></div></div>
							<div id="ulp-layer-80" class="ulp-layer" style="width: 310px; height: 38px; font-size: 16px; left: 370px; top: 290px;"><a data-loading="Sending..." data-label="Send Message" data-icon="fa-sign-in" onclick="return ulp_subscribe(this);" class="ulp-submit"><i class="fa fa-sign-in"></i>&nbsp; Send Message</a></div>
							<div id="ulp-layer-81" class="ulp-layer" style="width: 40px; height: 20px; font-size: 24px; left: 660px; top: -30px;"><a onclick="return ulp_self_close();" href="#">×</a></div>
							<div id="ulp-layer-82" class="ulp-layer" style="display: none; width: 700px; font-size: 14px; left: 0px; top: 410px;">Thank You. We will contact you as soon as possible.</div>
						</div>
						
											<div id="blackscreen" style='width:100%; height:100%; background:#000; opacity:0.7; top:0; left:0; position:fixed; z-index:20000; display:none;'></div>
						
					</div>
						
                        <script>
function ulp_self_close()
{
	$("#popupform_preview").hide();
	$("#blackscreen").hide();
	$("#popup_content_data").html('');
}
</script>
                     