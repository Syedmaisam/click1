<link rel="stylesheet" href="<?php echo SITE_ROOT_URL; ?>views/layered/animatemaster/animate.min.css">
<style>
body
{
margin:0px;
padding:0px;
}
.ulp-content {
    position: relative;
}
.ulp-window {
    text-align: left;
}
#ulp-layer-72 {
    background-color: rgba(141, 194, 62, 1);
    box-shadow: 0 4px 20px rgba(32, 32, 32, 1);
    text-align: left;
    z-index: 1000003;
}
#ulp-layer-72, #ulp-layer-72 p, #ulp-layer-72 a, #ulp-layer-72 span, #ulp-layer-72 li, #ulp-layer-72 input, #ulp-layer-72 button, #ulp-layer-72 textarea {
    color: #000000;
    font-family: "arial",arial;
    font-weight: 400;
}
.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}
#ulp-layer-73 {
    background-color: rgba(255, 255, 255, 1);
    text-align: left;
    z-index: 1000003;
}
#ulp-layer-73, #ulp-layer-73 p, #ulp-layer-73 a, #ulp-layer-73 span, #ulp-layer-73 li, #ulp-layer-73 input, #ulp-layer-73 button, #ulp-layer-73 textarea {
    color: #000000;
    font-family: "arial",arial;
    font-weight: 400;
}
.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}
iframe {
    width: 100%;
}
#ulp-layer-74 {
    background-color: rgba(0, 60, 117, 1);
    text-align: left;
    z-index: 1000007;
}
#ulp-layer-74, #ulp-layer-74 p, #ulp-layer-74 a, #ulp-layer-74 span, #ulp-layer-74 li, #ulp-layer-74 input, #ulp-layer-74 button, #ulp-layer-74 textarea {
    color: #34495e;
    font-family: "arial",arial;
    font-weight: 400;
}
.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}
#ulp-layer-75 {
    text-align: right;
    z-index: 1000007;
}
#ulp-layer-75, #ulp-layer-75 p, #ulp-layer-75 a, #ulp-layer-75 span, #ulp-layer-75 li, #ulp-layer-75 input, #ulp-layer-75 button, #ulp-layer-75 textarea {
    color: #f5f7f2;
    font-family: "arial",arial;
    font-weight: 700;
}
.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}
#ulp-layer-76 {
    text-align: right;
    z-index: 1000007;
}
#ulp-layer-76, #ulp-layer-76 p, #ulp-layer-76 a, #ulp-layer-76 span, #ulp-layer-76 li, #ulp-layer-76 input, #ulp-layer-76 button, #ulp-layer-76 textarea {
    color: #ffffff;
    font-family: "arial",arial;
    font-weight: 400;
}
.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}
#ulp-layer-76 {
    text-align: right;
}
#ulp-layer-77 {
    text-align: left;
    z-index: 1000007;
}
#ulp-layer-77, #ulp-layer-77 p, #ulp-layer-77 a, #ulp-layer-77 span, #ulp-layer-77 li, #ulp-layer-77 input, #ulp-layer-77 button, #ulp-layer-77 textarea {
    color: #000000;
    font-family: "arial",arial;
    font-weight: 400;
}
.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}
#ulp-layer-77 input.ulp-input {
    padding-left: 32px !important;
}
#ulp-aAQIvL3OZtSupwtI .ulp-input, #ulp-aAQIvL3OZtSupwtI .ulp-input:hover, #ulp-aAQIvL3OZtSupwtI .ulp-input:active, #ulp-aAQIvL3OZtSupwtI .ulp-input:focus {
    background-color: rgba(245, 247, 242, 1) !important;
    border-color: #ffffff;
    border-radius: 2px !important;
    border-width: 1px !important;
}
#ulp-layer-77, #ulp-layer-77 p, #ulp-layer-77 a, #ulp-layer-77 span, #ulp-layer-77 li, #ulp-layer-77 input, #ulp-layer-77 button, #ulp-layer-77 textarea {
    color: #000000;
    font-family: "arial",arial;
    font-weight: 400;
}
.ulp-input {
    background: none repeat scroll 0 0 rgba(255, 255, 255, 0.8);
    border-radius: 2px !important;
    border-spacing: 0 !important;
    border-style: solid !important;
    border-width: 1px !important;
    box-shadow: none !important;
    box-sizing: border-box !important;
    clear: both !important;
    font-size: inherit !important;
    height: 100% !important;
    line-height: 1.5 !important;
    margin: 0 !important;
    padding: 0 6px !important;
    vertical-align: middle !important;
    width: 100% !important;
}
input:-moz-read-write, textarea:-moz-read-write {
    -moz-user-modify: read-write !important;
}
input {
    -moz-appearance: textfield;
    -moz-binding: url("chrome://global/content/platformHTMLBindings.xml#inputFields");
    -moz-user-select: text;
    cursor: text;
    font: ;
    letter-spacing: normal;
    line-height: normal;
    padding: 1px;
    text-align: start;
    text-indent: 0;
    text-rendering: optimizelegibility;
    text-shadow: none;
    text-transform: none;
    word-spacing: normal;
}

.ulp-fa-input-table {
    display: table;
    height: 100%;
    left: 0;
    line-height: 100%;
    position: absolute;
    top: 0;
    vertical-align: middle;
}
#ulp-layer-77 {
    text-align: left;
}
#ulp-layer-77 div.ulp-fa-input-cell {
    padding-left: 4px !important;
    width: 28px !important;
}
.ulp-fa-input-cell {
    display: table-cell;
    opacity: 0.7;
    text-align: center;
    vertical-align: middle;
}
.fa {
    display: inline-block;
    font-family: FontAwesome;
    font-feature-settings: normal;
    font-kerning: auto;
    font-language-override: normal;
    font-size: inherit;
    font-size-adjust: none;
    font-stretch: normal;
    font-style: normal;
    font-synthesis: weight style;
    font-variant: normal;
    font-weight: normal;
    line-height: 1;
    text-rendering: auto;
}
#ulp-layer-78 {
    text-align: left;
    z-index: 1000007;
}
#ulp-layer-78, #ulp-layer-78 p, #ulp-layer-78 a, #ulp-layer-78 span, #ulp-layer-78 li, #ulp-layer-78 input, #ulp-layer-78 button, #ulp-layer-78 textarea {
    color: #000000;
    font-family: "arial",arial;
    font-weight: 400;
    text-shadow: 1px 1px 1px #ffffff;
}
.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}
#ulp-layer-78 input.ulp-input {
    padding-left: 32px !important;
}
#ulp-aAQIvL3OZtSupwtI .ulp-input, #ulp-aAQIvL3OZtSupwtI .ulp-input:hover, #ulp-aAQIvL3OZtSupwtI .ulp-input:active, #ulp-aAQIvL3OZtSupwtI .ulp-input:focus {
    background-color: rgba(245, 247, 242, 1) !important;
    border-color: #ffffff;
    border-radius: 2px !important;
    border-width: 1px !important;
}
#ulp-layer-78, #ulp-layer-78 p, #ulp-layer-78 a, #ulp-layer-78 span, #ulp-layer-78 li, #ulp-layer-78 input, #ulp-layer-78 button, #ulp-layer-78 textarea {
    color: #000000;
    font-family: "arial",arial;
    font-weight: 400;
    text-shadow: 1px 1px 1px #ffffff;
}
.ulp-input {
    background: none repeat scroll 0 0 rgba(255, 255, 255, 0.8);
    border-radius: 2px !important;
    border-spacing: 0 !important;
    border-style: solid !important;
    border-width: 1px !important;
    box-shadow: none !important;
    box-sizing: border-box !important;
    clear: both !important;
    font-size: inherit !important;
    height: 100% !important;
    line-height: 1.5 !important;
    margin: 0 !important;
    padding: 0 6px !important;
    vertical-align: middle !important;
    width: 100% !important;
}
input:-moz-read-write, textarea:-moz-read-write {
    -moz-user-modify: read-write !important;
}
input {
    -moz-appearance: textfield;
    -moz-binding: url("chrome://global/content/platformHTMLBindings.xml#inputFields");
    -moz-user-select: text;
    cursor: text;
    font: ;
    letter-spacing: normal;
    line-height: normal;
    padding: 1px;
    text-align: start;
    text-indent: 0;
    text-rendering: optimizelegibility;
    text-transform: none;
    word-spacing: normal;
}

.ulp-fa-input-table {
    display: table;
    height: 100%;
    left: 0;
    line-height: 100%;
    position: absolute;
    top: 0;
    vertical-align: middle;
}
#ulp-layer-78 {
    text-align: left;
}
#ulp-layer-78, #ulp-layer-78 p, #ulp-layer-78 a, #ulp-layer-78 span, #ulp-layer-78 li, #ulp-layer-78 input, #ulp-layer-78 button, #ulp-layer-78 textarea {
    color: #000000;
    text-shadow: 1px 1px 1px #ffffff;
}
#ulp-layer-78 div.ulp-fa-input-cell {
    padding-left: 4px !important;
    width: 28px !important;
}
.ulp-fa-input-cell {
    display: table-cell;
    opacity: 0.7;
    text-align: center;
    vertical-align: middle;
}

.fa {
    display: inline-block;
    font-family: FontAwesome;
    font-feature-settings: normal;
    font-kerning: auto;
    font-language-override: normal;
    font-size: inherit;
    font-size-adjust: none;
    font-stretch: normal;
    font-style: normal;
    font-synthesis: weight style;
    font-variant: normal;
    font-weight: normal;
    line-height: 1;
    text-rendering: auto;
}
#ulp-layer-79 {
    text-align: left;
    z-index: 1000007;
}
#ulp-layer-79, #ulp-layer-79 p, #ulp-layer-79 a, #ulp-layer-79 span, #ulp-layer-79 li, #ulp-layer-79 input, #ulp-layer-79 button, #ulp-layer-79 textarea {
    color: #000000;
    font-family: "arial",arial;
    font-weight: 400;
    text-shadow: 1px 1px 1px #ffffff;
}
.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}
#ulp-aAQIvL3OZtSupwtI .ulp-input, #ulp-aAQIvL3OZtSupwtI .ulp-input:hover, #ulp-aAQIvL3OZtSupwtI .ulp-input:active, #ulp-aAQIvL3OZtSupwtI .ulp-input:focus {
    background-color: rgba(245, 247, 242, 1) !important;
    border-color: #ffffff;
    border-radius: 2px !important;
    border-width: 1px !important;
}
#ulp-layer-79, #ulp-layer-79 p, #ulp-layer-79 a, #ulp-layer-79 span, #ulp-layer-79 li, #ulp-layer-79 input, #ulp-layer-79 button, #ulp-layer-79 textarea {
    color: #000000;
    font-family: "arial",arial;
    font-weight: 400;
    text-shadow: 1px 1px 1px #ffffff;
}
.ulp-input {
    background: none repeat scroll 0 0 rgba(255, 255, 255, 0.8);
    border-radius: 2px !important;
    border-spacing: 0 !important;
    border-style: solid !important;
    border-width: 1px !important;
    box-shadow: none !important;
    box-sizing: border-box !important;
    clear: both !important;
    font-size: inherit !important;
    height: 100% !important;
    line-height: 1.5 !important;
    margin: 0 !important;
    padding: 0 6px !important;
    vertical-align: middle !important;
    width: 100% !important;
}
input:-moz-read-write, textarea:-moz-read-write {
    -moz-user-modify: read-write !important;
}
textarea {
    -moz-appearance: textfield-multiline;
    -moz-binding: url("chrome://global/content/platformHTMLBindings.xml#textAreas");
    -moz-user-select: text;
    cursor: text;
    letter-spacing: normal;
    margin: 1px 0;
    padding: 0 1px;
    resize: both;
    text-align: start;
    text-indent: 0;
    text-rendering: optimizelegibility;
    text-transform: none;
    vertical-align: text-bottom;
    word-spacing: normal;
    word-wrap: break-word;
}
#ulp-layer-80 {
    text-align: center;
    z-index: 1000007;
}
#ulp-layer-80, #ulp-layer-80 p, #ulp-layer-80 a, #ulp-layer-80 span, #ulp-layer-80 li, #ulp-layer-80 input, #ulp-layer-80 button, #ulp-layer-80 textarea {
    color: #ffffff;
    font-family: "arial",arial;
    font-weight: 400;
    text-shadow: 1px 1px 1px #000000;
}
.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}
#ulp-aAQIvL3OZtSupwtI .ulp-submit, #ulp-aAQIvL3OZtSupwtI .ulp-submit:visited {
    background: linear-gradient(#002c56, #003c75) repeat scroll 0 0 #003c75;
    border: 1px solid #003c75;
    border-radius: 2px !important;
}
#ulp-layer-80, #ulp-layer-80 p, #ulp-layer-80 a, #ulp-layer-80 span, #ulp-layer-80 li, #ulp-layer-80 input, #ulp-layer-80 button, #ulp-layer-80 textarea {
    color: #ffffff;
    font-family: "arial",arial;
    font-weight: 400;
    text-shadow: 1px 1px 1px #000000;
}
.ulp-window a {
    text-decoration: none !important;
}
.ulp-submit, .ulp-submit:visited, .ulp-submit-button, .ulp-submit-button:visited {
    border-radius: 2px;
    box-shadow: none;
    cursor: pointer;
    display: inline-block;
    font-size: inherit !important;
    height: auto;
    line-height: 1.5;
    margin: 0;
    padding: 5px 20px;
    position: relative;
    text-decoration: none !important;
    transition-duration: 0.3s;
    white-space: nowrap;
    width: auto;
}
#ulp-layer-80, #ulp-layer-80 p, #ulp-layer-80 a, #ulp-layer-80 span, #ulp-layer-80 li, #ulp-layer-80 input, #ulp-layer-80 button, #ulp-layer-80 textarea {
    color: #ffffff;
    text-shadow: 1px 1px 1px #000000;
}
.ulp-submit, .ulp-submit:visited, .ulp-submit-button, .ulp-submit-button:visited {
    cursor: pointer;
    font-size: inherit !important;
    white-space: nowrap;
	background: linear-gradient(#002c56, #003c75) repeat scroll 0 0 #003c75;
}

.fa {
    display: inline-block;
    font-family: FontAwesome;
    font-feature-settings: normal;
    font-kerning: auto;
    font-language-override: normal;
    font-size: inherit;
    font-size-adjust: none;
    font-stretch: normal;
    font-style: normal;
    font-synthesis: weight style;
    font-variant: normal;
    font-weight: normal;
    line-height: 1;
    text-rendering: auto;
}

#ulp-layer-81 {
    text-align: right;
    z-index: 1000007;
}
#ulp-layer-81, #ulp-layer-81 p, #ulp-layer-81 a, #ulp-layer-81 span, #ulp-layer-81 li, #ulp-layer-81 input, #ulp-layer-81 button, #ulp-layer-81 textarea {
    color: #ffffff;
    font-family: "arial",arial;
    font-weight: 400;
    text-shadow: 1px 1px 1px #000000;
}
.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}
table
{
	margin:20px;
	background:#f8f8f8;
	
}
table td
{
	padding:10px;
	border:1px solid #ccc;
}
table td label
{
	font-family:Arial, Helvetica, sans-serif;
	font-size:14px;
	font-weight:normal;
}
table td input[type='text']
{
	border:none;
	padding:10px;
	font-size:12px;
	font-weight:normal;
	border:1px solid #ccc;
	width:300px;
}
table td textarea
{
	width:300px;
	font-size:12px;
}
#updateform
{
	background:#019ad2;
	color:#fff;
	font-size:16px;
	padding:10px;
	border:1px solid #019ad2;
	width:100px;
}
</style>

<?php

$txthtml="<div id='popupform' style='position:relative;'><div class='ulp-content ' style='width: 700px; height: 430px; margin: 5% auto auto;'>
							<div id='ulp-layer-72' class='ulp-layer' style='width: 700px; height: 400px; font-size: 14px; left: 0px; top: 0px;'></div>
							<div id='ulp-layer-73' class='ulp-layer animated fadeInLeftBig' style='width: 350px; height: 400px; font-size: 14px; left: 0px; top: 0px;'><iframe width='100%' height='100%' frameborder='0' style='border:0' src='https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d6044.275637456805!2d-73.98346368325204!3d40.75899341147853!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x55194ec5a1ae072e!2sTimes+Square!5e0!3m2!1sen!2s!4v1392901318461'></iframe></div>
							<div id='ulp-layer-74' class='ulp-layer animated bounceIn' style='width: 3px; height: 400px; font-size: 14px; left: 350px; top: 0px;'></div>
							<div id='ulp-layer-75' class='ulp-layer animated fadeInRight' style='width: 330px; font-size: 22px; left: 350px; top: 15px;'>CONTACT US</div>
							<div id='ulp-layer-76' class='ulp-layer animated fadeInRightBig' style='width: 310px; font-size: 14px; left: 370px; top: 52px;'>221, Mount Olimpus, Rheasilvia, Mars,<br> Solar System, Milky Way Galaxy<br> +1 (999) 999-99-99</div>
							<div id='ulp-layer-77' class='ulp-layer animated fadeInDownBig' style='width: 310px; height: 36px; font-size: 14px; left: 370px; top: 125px;'><input type='text' onfocus='jQuery(this).removeClass('ulp-input-error');' value='' placeholder='Enter your name...' name='ulp-name' class='ulp-input'><div class='ulp-fa-input-table'><div class='ulp-fa-input-cell'><i class='fa fa-user'></i></div></div></div>
							<div id='ulp-layer-78' class='ulp-layer animated fadeInDownBig' style='width: 310px; height: 36px; font-size: 14px; left: 370px; top: 170px;'><input type='text' onfocus='jQuery(this).removeClass('ulp-input-error');' value='' placeholder='Enter your e-mail...' name='ulp-email' class='ulp-input'><div class='ulp-fa-input-table'><div class='ulp-fa-input-cell'><i class='fa fa-envelope'></i></div></div></div>
							<div id='ulp-layer-80' class='ulp-layer' style='width: 310px; height: 38px; font-size: 16px; left: 370px; top: 290px;'><a data-loading='Sending...' data-label='Send Message' data-icon='fa-sign-in' onclick='return ulp_subscribe(this);' class='ulp-submit'><i class='fa fa-sign-in'></i>&nbsp; Send Message</a></div>
							<div id='ulp-layer-81' class='ulp-layer' style='width: 40px; height: 20px; font-size: 24px; left: 660px; top: -30px;'><a onclick='return ulp_self_close();' href='#'>X</a></div>
							<div id='ulp-layer-82' class='ulp-layer' style='display: none; width: 700px; font-size: 14px; left: 0px; top: 410px;'>Thank You. We will contact you as soon as possible.</div>
						</div>
												
						</div>
						";
						echo $txthtml;
						?>
						
                        <div >

<table width="97%" border="0">
  <tr>
    
    <td><label>Popup Background Color :</label></td>
    <td><input class="color boxcolor" value="66ff00" id="popbgcolor" onchange="popup_bg();"></td>
    <!-- <td><label>Header Background Color :</label></td> 
    <td><input class="color boxcolor" value="66ff00" id="bkgcolor" onchange="header_bg();"></td>-->
    <td></td>
    <td></td>
    
  </tr>
  <tr>
    <td><label>Layer one Color :</label></td>
    <td><input class="color boxcolor" value="66ff00" id="layer1_color" onchange="layer1_color();"></td>
    <td><label>Layer One Text :</label></td>
    <td><input type="text" value="" id="layer1_txt" onkeypress="layer1_txt();" maxlength="30" /></td>
    <!-- <td>&nbsp;</td>
    <td>&nbsp;</td> -->
  </tr>
   <tr>
    <td><label>Layer Two Color :</label></td>
    <td><input class="color boxcolor" value="66ff00" id="layer2_color" onchange="layer2_color();"></td>
    <td><label>Layer Two Text :</label></td>
    <td><textarea id="layer2_txt" onkeypress="layer2_txt();"></textarea></td>
    <!-- <td>&nbsp;</td>
    <td>&nbsp;</td>-->
  </tr>
      <!-- <tr>
    <td><label>Layer Three Color :</label></td>
    <td><input class="color boxcolor" value="66ff00" id="layer3_color" onchange="layer3_color();"></td>
    <td><label>Layer Three Text :</label></td>
    <td><textarea id="layer3_txt" onkeypress="layer3_txt();"></textarea></td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr> -->
      <tr>
    <td><label>Label One Color :</label></td>
    <td><input class="color boxcolor" value="66ff00" id="label1_color" onchange="label1_color();"></td>
    <!--  <td><label>Label One Text :</label></td>
    <td><input type="text" value="" id="label1_txt" onkeypress="label1_txt();"  /></td>-->
    <td><label>Placeholder one text :</label></td>
    <td><input type="text" value="" id="placeholder1_txt" onkeypress="placeholder1_txt();"  /></td>
  </tr>
  
     <tr>
    <td><label>Label Two Color :</label></td>
    <td><input class="color boxcolor" value="66ff00" id="label2_color" onchange="label2_color();"></td>
    <!-- <td><label>Label Two Text :</label></td>
    <td><input type="text" value="" id="label2_txt" onkeypress="label2_txt();"  /></td> -->
    <td><label>Placeholder Two text :</label></td>
    <td><input type="text" value="" id="placeholder2_txt" onkeypress="placeholder2_txt();"  /></td>
  </tr>
  
  
    
    <tr>
    <td><label>Button Color:</label></td>
    <td><input class="color boxcolor" value="66ff00" id="button1_color" onchange="button1_color();"></td>
    <td><label>Button Background Color :</label></td>
    <td><input class="color boxcolor" value="66ff00" id="button1_bkgcolor" onchange="button1_bkgcolor();"></td>
    <td><label>Button Text :</label></td>
    <td><input type="text" value="" id="button1_txt" onkeypress="button1_txt();"  /></td>
  
  </tr>
  
   <!--<tr>
    <td><label>Layer Four Color :</label></td>
    <td><input class="color boxcolor" value="66ff00" id="layer4_color" onchange="layer4_color();"></td>
    <td><label>Layer Four Text :</label></td>
    <td><input type="text" value="" onkeypress="layer4_txt();" id="layer4_txt" /></td>
    <td>Close Button Background</td>
    <td><input class="color boxcolor" value="66ff00" id="buttonclose_bkgcolor" onchange="buttonclose_bkgcolor();"></td>
  </tr> -->
  
  
  
  
    <tr>
<td>&nbsp;</td>    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
</table>



  
  
  
  
 
</div>     
<script type="text/javascript">
function pop_layer_data()
{
	var layer1_txt=$("#ulp-layer-75").html();
	var layer2_txt=$("#ulp-layer-76").html();
	//var layer3_txt=$("#ulp-layer-174").html();
	var label1_txt=$("#ulp-layer-77 .ulp-input").attr('placeholder');
	var label2_txt=$("#ulp-layer-78 .ulp-input").attr('placeholder');
	var label3_txt=$("#ulp-layer-79 .ulp-input").attr('placeholder');
	//var layer4_txt=$("#ulp-layer-182").html();
	var placeholder1_txt=$("#ulp-layer-77 .ulp-input").attr('placeholder');
	var placeholder2_txt=$("#ulp-layer-78 .ulp-input").attr('placeholder');
	var placeholder3_txt=$("#ulp-layer-79 .ulp-input").attr('placeholder');
	var button1_txt=$("#ulp-layer-80 .ulp-submit").html();

	$("#layer1_txt").val(layer1_txt);
	$("#layer2_txt").val(layer2_txt);
	//$("#layer3_txt").val(layer3_txt);
	$("#label1_txt").val(label1_txt);
	$("#label2_txt").val(label2_txt);
	$("#label3_txt").val(label3_txt);
	//$("#layer4_txt").val(layer4_txt);
	$("#placeholder1_txt").val(placeholder1_txt);
	$("#placeholder2_txt").val(placeholder2_txt);
	$("#placeholder3_txt").val(placeholder3_txt);
	$("#button1_txt").val(button1_txt);
}

						function popup_bg()
						{
							
							var popbgcolor="#"+$("#popbgcolor").val();
							//alert(bgcolor);
							$("#ulp-layer-72").css("background-color",popbgcolor);
						}
						/*function header_bg()
						{
							var bkgcolor="#"+$("#bkgcolor").val();
							//alert(bgcolor);
							$("#ulp-layer-171").css("background-color",bkgcolor);
						}
						*/
						function layer1_color()
						{
							var fcolor="#"+$("#layer1_color").val();
							//alert(bgcolor);
							$("#ulp-layer-75").css("color",fcolor);
						}
						function layer1_txt()
						{
							var layer1_txt=$("#layer1_txt").val();
							//alert(bgcolor);
							$("#ulp-layer-75").html(layer1_txt);
						}
						function layer2_color()
						{
							var fcolor="#"+$("#layer2_color").val();
							//alert(bgcolor);
							$("#ulp-layer-76").css("color",fcolor);
						}
						function layer2_txt()
						{
							var layer2_txt=$("#layer2_txt").val();
							//alert(bgcolor);
							$("#ulp-layer-76").html(layer2_txt);
						}
						/*function layer3_color()
						{
							var fcolor="#"+$("#layer3_color").val();
							//alert(bgcolor);
							$("#ulp-layer-174").css("color",fcolor);
						}*/
						/*function layer3_txt()
						{
							var layer3_txt=$("#layer3_txt").val();
							//alert(bgcolor);
							$("#ulp-layer-174").html(layer3_txt);
						}*/
						function label1_color()
						{
							var fcolor="#"+$("#label1_color").val();
							//alert(bgcolor);
							$("#ulp-layer-77").css("color",fcolor);
						}
						/*function label1_txt()
						{
							var label1_txt=$("#label1_txt").val();
							//alert(bgcolor);
							$("#ulp-layer-77 .ulp-input").attr('value',label1_txt);
						}*/
						function placeholder1_txt()
						{
							var placeholder1_txt=$("#placeholder1_txt").val();
							//alert(bgcolor);
							$("#ulp-layer-77 .ulp-input").attr('placeholder',placeholder1_txt);
						}
						
						function label2_color()
						{
							var fcolor="#"+$("#label2_color").val();
							//alert(bgcolor);
							$("#ulp-layer-78").css("color",fcolor);
						}
						/*function label2_txt()
						{
							var label2_txt=$("#label2_txt").val();
							//alert(bgcolor);
							$("#ulp-layer-177").html(label2_txt);
						}*/
						function placeholder2_txt()
						{
							var placeholder2_txt=$("#placeholder2_txt").val();
							//alert(bgcolor);
							$("#ulp-layer-78 .ulp-input").attr('placeholder',placeholder2_txt);
						}
						function label3_color()
						{
							var fcolor="#"+$("#label3_color").val();
							//alert(bgcolor);
							$("#ulp-layer-79").css("color",fcolor);
						}
						/*function label3_txt()
						{
							var label3_txt=$("#label3_txt").val();
							//alert(bgcolor);
							$("#ulp-layer-179").html(label3_txt);
						}*/
						function placeholder3_txt()
						{
							var placeholder3_txt=$("#placeholder3_txt").val();
							//alert(bgcolor);
							$("#ulp-layer-79 .ulp-input").attr('placeholder',placeholder3_txt);
						}
						
						function button1_color()
						{
							var fcolor="#"+$("#button1_color").val();
							//alert(bgcolor);
							$("#ulp-layer-80 .ulp-submit").css("color",fcolor);
						}
						function button1_bkgcolor()
						{
							var button1_bkgcolor="#"+$("#button1_bkgcolor").val();
							//alert(button1_bkgcolor);
							$("#ulp-layer-80 .ulp-submit").css('background',button1_bkgcolor);
						}
						function button1_txt()
						{
							var button1_txt=$("#button1_txt").val();
							//alert(bgcolor);
							$("#ulp-layer-80 .ulp-submit").html(button1_txt);
						}
						
						function layer4_color()
						{
							var fcolor="#"+$("#layer4_color").val();
							//alert(bgcolor);
							$("#ulp-layer-182").css("color",fcolor);
						}
						function layer4_txt()
						{
							var layer4_txt=$("#layer4_txt").val();
							//alert(bgcolor);
							$("#ulp-layer-182").html(layer4_txt);
						}
						
						function buttonclose_bkgcolor()
						{
							var bkgcolor="#"+$("#buttonclose_bkgcolor").val();
							//alert(bgcolor);
							$("#ulp-layer-183").css("background-color",bkgcolor);
						}
						
						
						function updateform()
						{
							var popupform= $("#popupform").html();
							
							$.ajax({
							type: "post",
							url: 'animatemaster/updatepop1.php',
							data: {
							popupform: popupform,
							},			
							success: function(response) {
								alert(response);
							},
							error:function 
							(XMLHttpRequest, textStatus, errorThrown) {
							}
							});  
							
						}
						</script>
