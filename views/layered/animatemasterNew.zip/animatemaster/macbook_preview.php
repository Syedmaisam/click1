<link rel="stylesheet" href="http://www.cliks.it/click/views/layered/animatemaster/animate.min.css">
<style>
body
{
margin:0px;
padding:0px;
}
.ulp-content {
    position: relative;
}
#ulp-layer-116 {
    text-align: left;
    z-index: 1000002;
}
#ulp-layer-116, #ulp-layer-116 p, #ulp-layer-116 a, #ulp-layer-116 span, #ulp-layer-116 li, #ulp-layer-116 input, #ulp-layer-116 button, #ulp-layer-116 textarea {
    color: #000000;
    font-family: "arial",arial;
    font-weight: 400;
}
.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}
.ulp-layer img {
    border: medium none !important;
    box-shadow: none !important;
    margin: 0 !important;
    max-width: 100% !important;
    min-width: 0 !important;
    padding: 0 !important;
}
img {
    max-width: 100%;
}
#ulp-layer-117 {
    text-align: left;
    z-index: 1000004;
}
#ulp-layer-117, #ulp-layer-117 p, #ulp-layer-117 a, #ulp-layer-117 span, #ulp-layer-117 li, #ulp-layer-117 input, #ulp-layer-117 button, #ulp-layer-117 textarea {
    color: #000000;
    font-family: "arial",arial;
    font-weight: 400;
}
.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}
.ulp-layer img {
    border: medium none !important;
    box-shadow: none !important;
    margin: 0 !important;
    max-width: 100% !important;
    min-width: 0 !important;
    padding: 0 !important;
}
img {
    max-width: 100%;
}
#ulp-layer-118 {
    text-align: right;
    z-index: 1000007;
}
#ulp-layer-118, #ulp-layer-118 p, #ulp-layer-118 a, #ulp-layer-118 span, #ulp-layer-118 li, #ulp-layer-118 input, #ulp-layer-118 button, #ulp-layer-118 textarea {
    color: #ffffff;
    font-family: "Open Sans",arial;
    font-weight: 100;
    text-shadow: 1px 1px 1px #000000;
}
.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}
#ulp-layer-119 {
    text-align: left;
    z-index: 1000007;
}
#ulp-layer-119, #ulp-layer-119 p, #ulp-layer-119 a, #ulp-layer-119 span, #ulp-layer-119 li, #ulp-layer-119 input, #ulp-layer-119 button, #ulp-layer-119 textarea {
    color: #ffffff;
    font-family: "Open Sans",arial;
    font-weight: 100;
    text-shadow: 1px 1px 1px #000000;
}
.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}
#ulp-layer-119 {
    text-align: left;
}
#ulp-layer-119, #ulp-layer-119 p, #ulp-layer-119 a, #ulp-layer-119 span, #ulp-layer-119 li, #ulp-layer-119 input, #ulp-layer-119 button, #ulp-layer-119 textarea {
    color: #ffffff;
    font-family: "Open Sans",arial;
    font-weight: 100;
    text-shadow: 1px 1px 1px #000000;
}
.ulp-layer {
    line-height: 1.475;
}
#ulp-layer-120 {
    text-align: left;
    z-index: 1000007;
}
#ulp-layer-120, #ulp-layer-120 p, #ulp-layer-120 a, #ulp-layer-120 span, #ulp-layer-120 li, #ulp-layer-120 input, #ulp-layer-120 button, #ulp-layer-120 textarea {
    color: #ffffff;
    font-family: "Open Sans",arial;
    font-weight: 100;
    text-shadow: 1px 1px 1px #000000;
}
.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}
#ulp-layer-120, #ulp-layer-120 p, #ulp-layer-120 a, #ulp-layer-120 span, #ulp-layer-120 li, #ulp-layer-120 input, #ulp-layer-120 button, #ulp-layer-120 textarea {
    color: #ffffff;
    font-family: "Open Sans",arial;
    font-weight: 100;
    text-shadow: 1px 1px 1px #000000;
}
.ulp-window a {
    text-decoration: none !important;
}
.ulp-buynow-blue, .ulp-buynow-blue:visited {
    background-color: #019ad2;
    background-image: linear-gradient(#33bcef, #019ad2);
    background-repeat: repeat-x;
    border: 1px solid #019ad2;
    border-radius: 5px;
    box-shadow: none;
    display: inline-block;
    height: auto;
    margin: 0;
    padding: 5px 20px;
    transition-duration: 0.3s;
    white-space: nowrap;
    width: auto;
}
.fo-right-ribbon a:hover, .fo-right-ribbon a:focus, a {
    text-decoration: none;
}
a, a:active, a:hover {
    outline: medium none;
}
#ulp-layer-121 {
    text-align: left;
    z-index: 1000007;
}
#ulp-layer-121, #ulp-layer-121 p, #ulp-layer-121 a, #ulp-layer-121 span, #ulp-layer-121 li, #ulp-layer-121 input, #ulp-layer-121 button, #ulp-layer-121 textarea {
    color: #ffffff;
    font-family: "Open Sans",arial;
    font-weight: 100;
    text-shadow: 1px 1px 1px #000000;
}
.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}
#ulp-layer-121, #ulp-layer-121 p, #ulp-layer-121 a, #ulp-layer-121 span, #ulp-layer-121 li, #ulp-layer-121 input, #ulp-layer-121 button, #ulp-layer-121 textarea {
    color: #ffffff;
    font-family: "Open Sans",arial;
    font-weight: 100;
    text-shadow: 1px 1px 1px #000000;
}
.ulp-window a {
    text-decoration: none !important;
}
.fo-right-ribbon a:hover, .fo-right-ribbon a:focus, a {
    text-decoration: none;
}
a, .contactForm input[type="text"]:focus, .contactForm input[type="email"]:focus, .contactForm textarea:focus, input#formSubmit, .errorForm, #subscribe input[type="email"]:focus, .errorSubs, .servSingle, #toTop i, #notForm input[type="email"]:focus, .contactForm input#submit, #loginForm input, #loginForm input[type="text"]:focus, #loginForm input[type="password"]:focus {
    transition: all 0.5s ease 0s;
}
a, a:active, a:hover {
    outline: medium none;
}



</style>


<div id='popupform_preview' style="display:none;"><div class='ulp-content' style='width: 640px; height: 400px; margin:auto;position:fixed; left:30%; top:15%;'>
							<div id='ulp-layer-116' class='ulp-layer animated fadeInLeftBig' style='width: 332px; font-size: 14px; left: 0px; top: 100px;'><img alt='' src='http://www.cliks.it/click/images/macbookpro.png'></div>
							<div id='ulp-layer-117' class='ulp-layer animated fadeInRightBig' style='width: 467px; font-size: 14px; left: 173px; top: 45px;'><img alt='' src='https://layeredpopups.com/layered-popups/images/default/pointer01.png'></div>
							<div id='ulp-layer-118' class='ulp-layer animated fadeInLeft' style='width: 640px; font-size: 32px; left: 0px; top: 0px;'>Macbook Pro</div>
							<div id='ulp-layer-119' class='ulp-layer animated fadeInRight' style='width: 300px; font-size: 16px; left: 380px; top: 75px;'>* Intel Core i7 (3.8GHz, 6MB cache)<br>
* Retina Display (2880 x 1880 px)<br>
* NVIDIA GeForce GT 750M (Iris)<br>
* 802.11ac Wi-Fi and Bluetooth 4.0<br>
* Thunderbolt 2 (up to 20Gb/s)<br>
* Faster All-Flash Storage (X1)<br>
* Long Lasting Battery (9 hours)</div>
							<div id='ulp-layer-120' class='ulp-layer animated fadeInUpBig' style='width: 200px; font-size: 24px; left: 430px; top: 280px;'><a href='http://www.apple.com/macbook-pro/' target='_blank' class='ulp-buynow-blue'>BUY NOW!</a></div>
							<div id='ulp-layer-121' class='ulp-layer animated fadeInLeft' style='width: 100px; height: 20px; font-size: 13px; left: 0px; top: 0px;'><a onclick='return ulp_self_close();' href='#'>close</a></div>
					
						<div id="blackscreen" style='width:100%; height:100%; background:#000; opacity:0.7; top:0; left:0; position:fixed; z-index:20000; display:none;'></div>
                        
                        
                        
                        </div>
						
						</div>
		<script type="text/javascript">
function ulp_self_close()
 {
    $("#popupform_preview").hide();
    $("#blackscreen").hide();
   $("#popup_content_data").html('');
}
		


		</script>				
				