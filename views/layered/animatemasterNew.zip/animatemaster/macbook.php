<link rel="stylesheet" href="<?php echo SITE_ROOT_URL; ?>views/layered/animatemaster/animate.min.css">
<style>
body
{
margin:0px;
padding:0px;
}
.ulp-content {
    position: relative;
}
#ulp-layer-116 {
    text-align: left;
    z-index: 1000002;
}
#ulp-layer-116, #ulp-layer-116 p, #ulp-layer-116 a, #ulp-layer-116 span, #ulp-layer-116 li, #ulp-layer-116 input, #ulp-layer-116 button, #ulp-layer-116 textarea {
    color: #000000;
    font-family: "arial",arial;
    font-weight: 400;
}
.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}
.ulp-layer img {
    border: medium none !important;
    box-shadow: none !important;
    margin: 0 !important;
    max-width: 100% !important;
    min-width: 0 !important;
    padding: 0 !important;
}
img {
    max-width: 100%;
}
#ulp-layer-117 {
    text-align: left;
    z-index: 1000004;
}
#ulp-layer-117, #ulp-layer-117 p, #ulp-layer-117 a, #ulp-layer-117 span, #ulp-layer-117 li, #ulp-layer-117 input, #ulp-layer-117 button, #ulp-layer-117 textarea {
    color: #000000;
    font-family: "arial",arial;
    font-weight: 400;
}
.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}
.ulp-layer img {
    border: medium none !important;
    box-shadow: none !important;
    margin: 0 !important;
    max-width: 100% !important;
    min-width: 0 !important;
    padding: 0 !important;
}
img {
    max-width: 100%;
}
#ulp-layer-118 {
    text-align: right;
    z-index: 1000007;
}
#ulp-layer-118, #ulp-layer-118 p, #ulp-layer-118 a, #ulp-layer-118 span, #ulp-layer-118 li, #ulp-layer-118 input, #ulp-layer-118 button, #ulp-layer-118 textarea {
    color: #ffffff;
    font-family: "Open Sans",arial;
    font-weight: 100;
    text-shadow: 1px 1px 1px #000000;
}
.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}
#ulp-layer-119 {
    text-align: left;
    z-index: 1000007;
}
#ulp-layer-119, #ulp-layer-119 p, #ulp-layer-119 a, #ulp-layer-119 span, #ulp-layer-119 li, #ulp-layer-119 input, #ulp-layer-119 button, #ulp-layer-119 textarea {
    color: #ffffff;
    font-family: "Open Sans",arial;
    font-weight: 100;
    text-shadow: 1px 1px 1px #000000;
}
.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}
#ulp-layer-119 {
    text-align: left;
}
#ulp-layer-119, #ulp-layer-119 p, #ulp-layer-119 a, #ulp-layer-119 span, #ulp-layer-119 li, #ulp-layer-119 input, #ulp-layer-119 button, #ulp-layer-119 textarea {
    color: #ffffff;
    font-family: "Open Sans",arial;
    font-weight: 100;
    text-shadow: 1px 1px 1px #000000;
}
.ulp-layer {
    line-height: 1.475;
}
#ulp-layer-120 {
    text-align: left;
    z-index: 1000007;
}
#ulp-layer-120, #ulp-layer-120 p, #ulp-layer-120 a, #ulp-layer-120 span, #ulp-layer-120 li, #ulp-layer-120 input, #ulp-layer-120 button, #ulp-layer-120 textarea {
    color: #ffffff;
    font-family: "Open Sans",arial;
    font-weight: 100;
    text-shadow: 1px 1px 1px #000000;
}
.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}
#ulp-layer-120, #ulp-layer-120 p, #ulp-layer-120 a, #ulp-layer-120 span, #ulp-layer-120 li, #ulp-layer-120 input, #ulp-layer-120 button, #ulp-layer-120 textarea {
    color: #ffffff;
    font-family: "Open Sans",arial;
    font-weight: 100;
    text-shadow: 1px 1px 1px #000000;
}
.ulp-window a {
    text-decoration: none !important;
}
.ulp-buynow-blue, .ulp-buynow-blue:visited {
    background-color: #019ad2;
    background-image: linear-gradient(#33bcef, #019ad2);
    background-repeat: repeat-x;
    border: 1px solid #019ad2;
    border-radius: 5px;
    box-shadow: none;
    display: inline-block;
    height: auto;
    margin: 0;
    padding: 5px 20px;
    transition-duration: 0.3s;
    white-space: nowrap;
    width: auto;
}
.fo-right-ribbon a:hover, .fo-right-ribbon a:focus, a {
    text-decoration: none;
}
a, a:active, a:hover {
    outline: medium none;
}
#ulp-layer-121 {
    text-align: left;
    z-index: 1000007;
}
#ulp-layer-121, #ulp-layer-121 p, #ulp-layer-121 a, #ulp-layer-121 span, #ulp-layer-121 li, #ulp-layer-121 input, #ulp-layer-121 button, #ulp-layer-121 textarea {
    color: #ffffff;
    font-family: "Open Sans",arial;
    font-weight: 100;
    text-shadow: 1px 1px 1px #000000;
}
.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}
#ulp-layer-121, #ulp-layer-121 p, #ulp-layer-121 a, #ulp-layer-121 span, #ulp-layer-121 li, #ulp-layer-121 input, #ulp-layer-121 button, #ulp-layer-121 textarea {
    color: #ffffff;
    font-family: "Open Sans",arial;
    font-weight: 100;
    text-shadow: 1px 1px 1px #000000;
}
.ulp-window a {
    text-decoration: none !important;
}
.fo-right-ribbon a:hover, .fo-right-ribbon a:focus, a {
    text-decoration: none;
}
a, .contactForm input[type="text"]:focus, .contactForm input[type="email"]:focus, .contactForm textarea:focus, input#formSubmit, .errorForm, #subscribe input[type="email"]:focus, .errorSubs, .servSingle, #toTop i, #notForm input[type="email"]:focus, .contactForm input#submit, #loginForm input, #loginForm input[type="text"]:focus, #loginForm input[type="password"]:focus {
    transition: all 0.5s ease 0s;
}
a, a:active, a:hover {
    outline: medium none;
}

table
{
	margin:20px;
	background:#f8f8f8;
	
}
table td
{
	padding:10px;
	border:1px solid #ccc;
}
table td label
{
	font-family:Arial, Helvetica, sans-serif;
	font-size:14px;
	font-weight:normal;
}
table td input[type='text']
{
	border:none;
	padding:10px;
	font-size:12px;
	font-weight:normal;
	border:1px solid #ccc;
	width:300px;
}
table td textarea
{
	width:300px;
	font-size:12px;
}
#updateform
{
	background:#019ad2;
	color:#fff;
	font-size:16px;
	padding:10px;
	border:1px solid #019ad2;
	width:100px;
}


</style>

<?php

$txthtml="<div id='popupform' style='position:relative;'><div class='ulp-content ' style='width: 640px; height: 400px; margin: 5% auto auto;'>
							<div id='ulp-layer-116' class='ulp-layer animated fadeInLeftBig' style='width: 332px; font-size: 14px; left: 0px; top: 100px;'><img alt='' src='http://www.cliks.it/click/images/macbookpro.png' style='width:332px;height:200px;'></div>
							<div id='ulp-layer-117' class='ulp-layer animated fadeInRightBig' style='width: 467px; font-size: 14px; left: 173px; top: 45px;'><img alt='' src='https://layeredpopups.com/layered-popups/images/default/pointer01.png'></div>
							<div id='ulp-layer-118' class='ulp-layer animated fadeInLeft' style='width: 640px; font-size: 32px; left: 0px; top: 0px;'>Macbook Pro</div>
							<div id='ulp-layer-119' class='ulp-layer animated fadeInRight' style='width: 300px; font-size: 16px; left: 380px; top: 75px;'>* Intel Core i7 (3.8GHz, 6MB cache)<br>
* Retina Display (2880 x 1880 px)<br>
* NVIDIA GeForce GT 750M (Iris)<br>
* 802.11ac Wi-Fi and Bluetooth 4.0<br>
* Thunderbolt 2 (up to 20Gb/s)<br>
* Faster All-Flash Storage (X1)<br>
* Long Lasting Battery (9 hours)</div>
							<div id='ulp-layer-120' class='ulp-layer animated fadeInUpBig' style='width: 200px; font-size: 24px; left: 430px; top: 280px;'><a href='http://www.apple.com/macbook-pro/' target='_blank' class='ulp-buynow-blue'>BUY NOW!</a></div>
							<div id='ulp-layer-121' class='ulp-layer animated fadeInLeft' style='width: 100px; height: 20px; font-size: 13px; left: 0px; top: 0px;'><a onclick='return ulp_self_close();' href='#'>close</a></div>
						</div>
					</div>
					";
					echo $txthtml;
					?>
					
                     <div>

<table width="97%" border="0">
  <tr>
    
    <td><label>Layer One Text :</label></td>
    <td><input type="text" value="" id="headingText" onkeyup="popup_HeadingText();" maxlength="30" /></td>
    <td><label>Heading Two Text :</label></td>
    <td><input type="text" value="" id="heading2_txt" onkeyup="heading2_txt();" maxlength="130" /></td>
 </tr>

<tr>
    
    <td><label>Layer One Color :</label></td>
    <td><input class="color boxcolor" value="66ff00" id="heading1_color" onchange="heading1_color();"></td>
     <td><label>Heading Two Color :</label></td>
    <td><input class="color boxcolor" value="66ff00" id="heading2_color" onchange="heading2_color();"></td>
        
  </tr>
  
  <tr>
    <td><label>Buy Now Button Text :</label></td>
    <td><input type="text" value="" id="button1_txt" maxlength="25" onkeyup="button1_txt();"  /></td>
     <td><label>Buy Now Url :</label></td>
    <td><input type="text" value="" id="button2_txt" onkeyup="button2_txt();"  /></td>
  </tr>
  
  <tr>
    <td><label>Image URL :</label></td>
    <td><input type="text" value="" id="chnagemacurl" onblur="macimgchange(this.value);"  /></td>
  </tr>
 
 
</table>

</div>                       
<script type="text/javascript">
function pop_layer_data()
{
	var heading1_txt=$("#ulp-layer-118").html();
	var heading2_txt=$("#ulp-layer-119").html();
	
    var button1_txt=$("#ulp-layer-120 .ulp-buynow-blue").html();
    var button2_txt=$("#ulp-layer-120 .ulp-buynow-blue").attr('href');
   var imgurl=$("#ulp-layer-116 img").attr("src");
    $("#chnagemacurl").val(imgurl);
   

	 $("#headingText").val(heading1_txt);
	 $("#heading2_txt").val(heading2_txt);
	 $("#button1_txt").val(button1_txt);
     $("#button2_txt").val(button2_txt);
   
}
                 		               function popup_HeadingText()
						{
							
							var layer1_txt =$("#headingText").val();
							$("#ulp-layer-118").html(layer1_txt);
						}
                                                function heading1_color()
						{
							var fcolor="#"+$("#heading1_color").val();
							$("#ulp-layer-118").css("color",fcolor);
							
						}
						function heading2_color()
						{
							var fcolor="#"+$("#heading2_color").val();
							$("#ulp-layer-119").css("color",fcolor);
							
						}
						
						function heading2_txt()
						{
							var layer2_txt=$("#heading2_txt").val();
							$("#ulp-layer-119").html(layer2_txt);
						}
						
						function button1_txt()
						{
							var button1_txt=$("#button1_txt").val();
							//alert(bgcolor);
							$("#ulp-layer-120 .ulp-buynow-blue").html(button1_txt);
						}

						function button2_txt()
						{
							var button2_txt=$("#button2_txt").val();
							$("#ulp-layer-120 a").attr('href',button2_txt);
						}


						function macimgchange(urldata)
						{
							var imgurl=$("#ulp-layer-116 img").attr("src");
									
							$("#ulp-layer-116 img").attr("src",urldata);
						}
					
					
						
						function updateform()
						{
							var popupform= $("#popupform").html();
							
							$.ajax({
							type: "post",
							url: 'animatemaster/updatepop1.php',
							data: {
							popupform: popupform,
							},			
							success: function(response) {
								//alert(response);
							},
							error:function 
							(XMLHttpRequest, textStatus, errorThrown) {
							}
							});  
							
						}
						</script>












                     