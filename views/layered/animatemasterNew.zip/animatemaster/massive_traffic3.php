<link rel="stylesheet" href="<?php echo SITE_ROOT_URL; ?>views/layered/animatemaster/animate.min.css">
<style>
body
{
margin:0px;
padding:0px;
}
.ulp-content {
    position: relative;
}
#ulp-layer-218 {
    background-color: rgba(255, 255, 255, 1);
    background-image: url("https://layeredpopups.com/layered-popups/images/default/graybg03.png");
    background-repeat: repeat;
    border-radius: 3px;
    box-shadow: 0 4px 20px rgba(32, 32, 32, 1);
    text-align: left;
    z-index: 1000003;
}
#ulp-layer-218, #ulp-layer-218 p, #ulp-layer-218 a, #ulp-layer-218 span, #ulp-layer-218 li, #ulp-layer-218 input, #ulp-layer-218 button, #ulp-layer-218 textarea {
    color: #000000;
    font-family: "arial",arial;
    font-weight: 400;
}
.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}
#ulp-layer-219 {
    border-radius: 3px;
    box-shadow: 0 0 90px rgba(32, 32, 32, 0.1) inset;
    text-align: left;
    z-index: 1000005;
}
#ulp-layer-219, #ulp-layer-219 p, #ulp-layer-219 a, #ulp-layer-219 span, #ulp-layer-219 li, #ulp-layer-219 input, #ulp-layer-219 button, #ulp-layer-219 textarea {
    color: #000000;
    font-family: "arial",arial;
    font-weight: 400;
}
.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}
#ulp-layer-220 {
    font-style: italic;
    letter-spacing: -1px;
    text-align: center;
    z-index: 1000007;
}
#ulp-layer-220, #ulp-layer-220 p, #ulp-layer-220 a, #ulp-layer-220 span, #ulp-layer-220 li, #ulp-layer-220 input, #ulp-layer-220 button, #ulp-layer-220 textarea {
    color: #1b5aad;
    font-family: "arial",arial;
    font-weight: 700;
}
.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}
#ulp-layer-221 {
    font-style: italic;
    line-height: 1.2;
    text-align: justify;
    z-index: 1000007;
}
#ulp-layer-221, #ulp-layer-221 p, #ulp-layer-221 a, #ulp-layer-221 span, #ulp-layer-221 li, #ulp-layer-221 input, #ulp-layer-221 button, #ulp-layer-221 textarea {
    color: #888888;
    font-family: "arial",arial;
    font-weight: 400;
}
.ulp-layer {
    box-sizing: border-box;
    position: absolute;
}
#ulp-layer-222 {
    text-align: left;
    z-index: 1000007;
}
#ulp-layer-222, #ulp-layer-222 p, #ulp-layer-222 a, #ulp-layer-222 span, #ulp-layer-222 li, #ulp-layer-222 input, #ulp-layer-222 button, #ulp-layer-222 textarea {
    color: #333333;
    font-family: "arial",arial;
    font-weight: 700;
}
.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}
ul.ulp-sf14-popup {
    list-style: outside none none !important;
    margin: 0 !important;
    padding: 0 !important;
}
#ulp-layer-223 {
    text-align: center;
    z-index: 1000007;
}
#ulp-layer-223, #ulp-layer-223 p, #ulp-layer-223 a, #ulp-layer-223 span, #ulp-layer-223 li, #ulp-layer-223 input, #ulp-layer-223 button, #ulp-layer-223 textarea {
    color: #ffffff;
    font-family: "arial",arial;
    font-weight: 700;
    text-shadow: 1px 1px 1px #000000;
}
.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}
iframe {
    border: 0 none;
    width: 100%;
}

html {
    overflow: hidden;
}
#ulp-layer-224 {
    text-align: left;
    z-index: 1000005;
}
#ulp-layer-224, #ulp-layer-224 p, #ulp-layer-224 a, #ulp-layer-224 span, #ulp-layer-224 li, #ulp-layer-224 input, #ulp-layer-224 button, #ulp-layer-224 textarea {
    color: #000000;
    font-family: "arial",arial;
    font-weight: 400;
}
.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}
.ulp-layer img {
    border: medium none !important;
    box-shadow: none !important;
    margin: 0 !important;
    max-width: 100% !important;
    min-width: 0 !important;
    padding: 0 !important;
}
img {
    max-width: 100%;
}
#ulp-layer-225 {
    text-align: left;
    z-index: 1000008;
}
#ulp-layer-225, #ulp-layer-225 p, #ulp-layer-225 a, #ulp-layer-225 span, #ulp-layer-225 li, #ulp-layer-225 input, #ulp-layer-225 button, #ulp-layer-225 textarea {
    color: #000000;
    font-family: "arial",arial;
    font-weight: 400;
    text-shadow: 1px 1px 1px #ffffff;
}
.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}
#ulp-layer-225 input.ulp-input {
    padding-left: 32px !important;
}
#ulp-435TbuZuEUUshKm9 .ulp-input, #ulp-435TbuZuEUUshKm9 .ulp-input:hover, #ulp-435TbuZuEUUshKm9 .ulp-input:active, #ulp-435TbuZuEUUshKm9 .ulp-input:focus {
    background-color: rgba(255, 255, 255, 1) !important;
    border-color: #ffffff;
    border-radius: 2px !important;
    border-width: 1px !important;
}
#ulp-layer-225, #ulp-layer-225 p, #ulp-layer-225 a, #ulp-layer-225 span, #ulp-layer-225 li, #ulp-layer-225 input, #ulp-layer-225 button, #ulp-layer-225 textarea {
    color: #000000;
    font-family: "arial",arial;
    font-weight: 400;
    text-shadow: 1px 1px 1px #ffffff;
}
.ulp-input {
    background: none repeat scroll 0 0 rgba(255, 255, 255, 0.8);
    border-radius: 2px !important;
    border-spacing: 0 !important;
    border-style: solid !important;
    border-width: 1px !important;
    box-shadow: none !important;
    box-sizing: border-box !important;
    clear: both !important;
    font-size: inherit !important;
    height: 100% !important;
    line-height: 1.5 !important;
    margin: 0 !important;
    padding: 0 6px !important;
    vertical-align: middle !important;
    width: 100% !important;
}
input:-moz-read-write, textarea:-moz-read-write {
    -moz-user-modify: read-write !important;
}
input {
    -moz-appearance: textfield;
    -moz-binding: url("chrome://global/content/platformHTMLBindings.xml#inputFields");
    -moz-user-select: text;
    cursor: text;
    font: ;
    letter-spacing: normal;
    line-height: normal;
    padding: 1px;
    text-align: start;
    text-indent: 0;
    text-rendering: optimizelegibility;
    text-transform: none;
    word-spacing: normal;
}
textarea > .anonymous-div, input > .anonymous-div, input::-moz-placeholder, textarea::-moz-placeholder, *|*::-moz-button-content, *|*::-moz-display-comboboxcontrol-frame, optgroup:before {
    text-overflow: inherit;
    unicode-bidi: inherit;
}
input::-moz-placeholder, textarea::-moz-placeholder {
    display: inline-block !important;
    opacity: 0.54;
    overflow: hidden !important;
    pointer-events: none !important;
    resize: none !important;
}
textarea > .anonymous-div, input > .anonymous-div, input::-moz-placeholder, textarea::-moz-placeholder {
    -moz-control-character-visibility: visible;
    border: 0 none !important;
    display: inline-block;
    ime-mode: inherit;
    margin: 0;
    overflow: auto;
    padding: inherit !important;
    resize: inherit;
    text-decoration: inherit;
    white-space: pre;
}
input > .anonymous-div, input::-moz-placeholder {
    line-height: -moz-block-height;
    word-wrap: normal !important;
}
.ulp-fa-input-table {
    display: table;
    height: 100%;
    left: 0;
    line-height: 100%;
    position: absolute;
    top: 0;
    vertical-align: middle;
}
#ulp-layer-225 div.ulp-fa-input-cell {
    padding-left: 4px !important;
    width: 28px !important;
}
.ulp-fa-input-cell {
    display: table-cell;
    opacity: 0.7;
    text-align: center;
    vertical-align: middle;
}
.fa-envelope:before {
    content: "";
}
.fa {
    display: inline-block;
    font-family: FontAwesome;
    font-feature-settings: normal;
    font-kerning: auto;
    font-language-override: normal;
    font-size: inherit;
    font-size-adjust: none;
    font-stretch: normal;
    font-style: normal;
    font-synthesis: weight style;
    font-variant: normal;
    font-weight: normal;
    line-height: 1;
    text-rendering: auto;
}
.ulp-fa-input-cell {
    text-align: center;
}
#ulp-layer-226 {
    text-align: center;
    z-index: 1000009;
}
#ulp-layer-226, #ulp-layer-226 p, #ulp-layer-226 a, #ulp-layer-226 span, #ulp-layer-226 li, #ulp-layer-226 input, #ulp-layer-226 button, #ulp-layer-226 textarea {
    color: #ffffff;
    font-family: "arial",arial;
    font-weight: 400;
    text-shadow: 1px 1px 1px #000000;
}
.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}
#ulp-435TbuZuEUUshKm9 .ulp-submit, #ulp-435TbuZuEUUshKm9 .ulp-submit:visited {
    background: none repeat scroll 0 0 #1b5aad;
    border: 1px solid #1b5aad;
    border-radius: 2px !important;
}
#ulp-layer-226, #ulp-layer-226 p, #ulp-layer-226 a, #ulp-layer-226 span, #ulp-layer-226 li, #ulp-layer-226 input, #ulp-layer-226 button, #ulp-layer-226 textarea {
    color: #ffffff;
    font-family: "arial",arial;
    font-weight: 400;
    text-shadow: 1px 1px 1px #000000;
}
.ulp-window a {
    text-decoration: none !important;
}
.ulp-submit, .ulp-submit:visited, .ulp-submit-button, .ulp-submit-button:visited {
    border-radius: 2px;
    box-shadow: none;
    cursor: pointer;
    display: inline-block;
    font-size: inherit !important;
    height: auto;
    line-height: 1.5;
    margin: 0;
    padding: 5px 20px;
    position: relative;
    text-decoration: none !important;
    transition-duration: 0.3s;
    white-space: nowrap;
    width: auto;
}
a, a:active, a:hover {
    outline: medium none;
}
.fa-check:before {
    content: "";
}
.fa {
    display: inline-block;
    font-family: FontAwesome;
    font-feature-settings: normal;
    font-kerning: auto;
    font-language-override: normal;
    font-size: inherit;
    font-size-adjust: none;
    font-stretch: normal;
    font-style: normal;
    font-synthesis: weight style;
    font-variant: normal;
    font-weight: normal;
    line-height: 1;
    text-rendering: auto;
}
#ulp-layer-226, #ulp-layer-226 p, #ulp-layer-226 a, #ulp-layer-226 span, #ulp-layer-226 li, #ulp-layer-226 input, #ulp-layer-226 button, #ulp-layer-226 textarea {
    color: #ffffff;
    text-shadow: 1px 1px 1px #000000;
}
.ulp-submit, .ulp-submit:visited, .ulp-submit-button, .ulp-submit-button:visited {
    cursor: pointer;
    font-size: inherit !important;
    white-space: nowrap;
}
#ulp-layer-227 {
    text-align: left;
    z-index: 1000007;
}
#ulp-layer-227, #ulp-layer-227 p, #ulp-layer-227 a, #ulp-layer-227 span, #ulp-layer-227 li, #ulp-layer-227 input, #ulp-layer-227 button, #ulp-layer-227 textarea {
    color: #333333;
    font-family: "arial",arial;
    font-weight: 400;
}
.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}
#ulp-layer-228 {
    text-align: right;
    z-index: 1000007;
}
#ulp-layer-228, #ulp-layer-228 p, #ulp-layer-228 a, #ulp-layer-228 span, #ulp-layer-228 li, #ulp-layer-228 input, #ulp-layer-228 button, #ulp-layer-228 textarea {
    color: #ffffff;
    font-family: "arial",arial;
    font-weight: 400;
    text-shadow: 1px 1px 1px #000000;
}
.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}
#ulp-layer-228, #ulp-layer-228 p, #ulp-layer-228 a, #ulp-layer-228 span, #ulp-layer-228 li, #ulp-layer-228 input, #ulp-layer-228 button, #ulp-layer-228 textarea {
    color: #ffffff;
    font-family: "arial",arial;
    font-weight: 400;
    text-shadow: 1px 1px 1px #000000;
}
.ulp-window a {
    text-decoration: none !important;
}
ul.ulp-sf14-popup {margin: 0 !important; padding: 0 !important; list-style: none !important;}
ul.ulp-sf14-popup li {padding: 0 !important; margin: 0 !important; text-indent: 0 !important; line-height: 1.7 !important;}
ul.ulp-sf14-popup li:before {content: "● " !important; color: #1b5aad; margin-right: 10px !important;}

table
{
	margin:20px;
	background:#f8f8f8;
	
}
table td
{
	padding:10px;
	border:1px solid #ccc;
}
table td label
{
	font-family:Arial, Helvetica, sans-serif;
	font-size:14px;
	font-weight:normal;
}
table td input[type='text']
{
	border:none;
	padding:10px;
	font-size:12px;
	font-weight:normal;
	border:1px solid #ccc;
	width:300px;
}
table td textarea
{
	width:300px;
	font-size:12px;
}
#updateform
{
	background:#019ad2;
	color:#fff;
	font-size:16px;
	padding:10px;
	border:1px solid #019ad2;
	width:100px;
}
</style>
<?php 
 
$txthtml="<div class='ulp-content' style='width: 700px; height: 400px; margin: 10% auto auto;'>
							<div id='ulp-layer-218' class='ulp-layer' style='width: 660px; height: 400px; font-size: 14px; left: 20px; top: 0px;'></div>
							<div id='ulp-layer-219' class='ulp-layer' style='width: 660px; height: 400px; font-size: 14px; left: 20px; top: 0px;'></div>
							<div id='ulp-layer-220' class='ulp-layer animated bounceInDown' style='width: 660px; font-size: 28px; left: 20px; top: 15px;'>Do you want massive traffic?</div>
							<div id='ulp-layer-221' class='ulp-layer animated bounceInRight' style='width: 300px; font-size: 14px; left: 360px; top: 60px;'>Scelerisque augue ac hac, aliquet, nascetur turpis. Augue diam phasellus odio lorem integer, aliquam aliquam sociis nisi adipiscing hacac.</div>
							<div id='ulp-layer-222' class='ulp-layer animated bounceIn' style='width: 420px; font-size: 14px; left: 360px; top: 130px;'>
<ul class='ulp-sf14-popup'>
<li>Goblinus globalus fantumo tubus dia</li>
<li>Scelerisque cursus dignissim lopatico</li>
<li>Montes vutario lacus quis preambul</li>
<li>Leftomato denitro oculus softam lorum</li>
<li>Spiratio dodenus christmas gulleria tix</li>
<li>Dualo fitemus lacus quis preambul bela</li>
</ul></div>
							<div id='ulp-layer-223' class='ulp-layer' style='width: 300px; height: 200px; font-size: 25px; left: 40px; top: 70px;'><iframe width='100%' height='100%' frameborder='0' allowfullscreen='' src='//www.youtube.com/embed/j8lScHO2mM0'></iframe></div>
							<div id='ulp-layer-224' class='ulp-layer animated bounceIn' style='width: 700px; font-size: 14px; left: 0px; top: 280px;'><img alt='' src='https://layeredpopups.com/layered-popups/images/default/red-ribbon.png'></div>
							<div id='ulp-layer-225' class='ulp-layer animated fadeInDown' style='width: 370px; height: 34px; font-size: 14px; left: 70px; top: 311px;'><input type='text' onfocus='jQuery(this).removeClass('ulp-input-error');' value='' placeholder='Enter your e-mail...' name='ulp-email' class='ulp-input'><div class='ulp-fa-input-table'><div class='ulp-fa-input-cell'><i class='fa fa-envelope'></i></div></div></div>
							<div id='ulp-layer-226' class='ulp-layer animated fadeInDown' style='width: 180px; height: 38px; font-size: 15px; left: 450px; top: 311px;'><a data-loading='Loading Data...' data-label='Get Instant Access' data-icon='fa-check' onclick='return ulp_subscribe(this);' class='ulp-submit'><i class='fa fa-check'></i>&nbsp; Get Instant Access</a></div>
							<div id='ulp-layer-227' class='ulp-layer animated fadeInDownBig' style='width: 600px; font-size: 13px; left: 40px; top: 372px;'>* we never share your details with third parties.</div>
							<div id='ulp-layer-228' class='ulp-layer animated fadeInDownBig' style='width: 40px; height: 20px; font-size: 24px; left: 640px; top: -30px;'><a onclick='return ulp_self_close();' href='#'>x</a></div>
						</div>";
						echo $txthtml;
						
						?>