﻿<link rel="stylesheet" href="<?php echo SITE_ROOT_URL; ?>views/layered/animatemaster/animate.min.css">
<script type="text/javascript" src="<?php echo SITE_ROOT_URL; ?>colorjs/jscolor.js"></script>
<style>
body
{

margin:0px;
padding:0px;
}
.ulp-content {
    position: relative;
}
.ulp-window {
    text-align: left;
}

#ulp-layer-324 {
    background-color: rgba(240, 98, 46, 1);
    border-radius: 2px 2px 0 0;
    text-align: left;
    z-index: 1000003;
}
#ulp-layer-324, #ulp-layer-324 p, #ulp-layer-324 a, #ulp-layer-324 span, #ulp-layer-324 li, #ulp-layer-324 input, #ulp-layer-324 button, #ulp-layer-324 textarea {
    color: #000000;
    font-family: "arial",arial;
    font-weight: 400;
}

.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}

#ulp-layer-325 {
    background-color: rgba(218, 210, 191, 1);
    border-radius: 0 0 2px 2px;
    text-align: left;
    z-index: 1000003;
}

#ulp-layer-325, #ulp-layer-325 p, #ulp-layer-325 a, #ulp-layer-325 span, #ulp-layer-325 li, #ulp-layer-325 input, #ulp-layer-325 button, #ulp-layer-325 textarea {
    color: #000000;
    font-family: "arial",arial;
    font-weight: 400;
}

.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}

#ulp-layer-326 {
    border-radius: 2px;
    box-shadow: 0 4px 20px rgba(32, 32, 32, 1), -6px -6px 0 rgba(0, 0, 0, 0.1) inset;
    text-align: left;
    z-index: 1000004;
}

#ulp-layer-326, #ulp-layer-326 p, #ulp-layer-326 a, #ulp-layer-326 span, #ulp-layer-326 li, #ulp-layer-326 input, #ulp-layer-326 button, #ulp-layer-326 textarea {
    color: #000000;
    font-family: "arial",arial;
    font-weight: 400;
}

.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}

#ulp-layer-327 {
    background-color: rgba(1, 113, 141, 1);
    border-radius: 2px;
    box-shadow: -3px -3px 0 rgba(0, 0, 0, 0.1) inset;
    text-align: center;
    z-index: 1000007;
}
#ulp-layer-327, #ulp-layer-327 p, #ulp-layer-327 a, #ulp-layer-327 span, #ulp-layer-327 li, #ulp-layer-327 input, #ulp-layer-327 button, #ulp-layer-327 textarea {
    color: #ffffff;
    font-family: "arial",arial;
    font-weight: 700;
}

.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}

#ulp-layer-328 {
    letter-spacing: -1px;
    text-align: center;
    z-index: 1000007;
}

#ulp-layer-328, #ulp-layer-328 p, #ulp-layer-328 a, #ulp-layer-328 span, #ulp-layer-328 li, #ulp-layer-328 input, #ulp-layer-328 button, #ulp-layer-328 textarea {
    color: #ffffff;
    font-family: "arial",arial;
    font-weight: 700;
}
.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}

#ulp-layer-329 {
    line-height: 1.3;
    text-align: justify;
    z-index: 1000007;
}
#ulp-layer-329, #ulp-layer-329 p, #ulp-layer-329 a, #ulp-layer-329 span, #ulp-layer-329 li, #ulp-layer-329 input, #ulp-layer-329 button, #ulp-layer-329 textarea {
    color: #ffffff;
    font-family: "arial",arial;
    font-weight: 400;
}
.ulp-layer {
    box-sizing: border-box;
    position: absolute;
}

#ulp-layer-330 {
    text-align: left;
    z-index: 1000007;
}
#ulp-layer-330, #ulp-layer-330 p, #ulp-layer-330 a, #ulp-layer-330 span, #ulp-layer-330 li, #ulp-layer-330 input, #ulp-layer-330 button, #ulp-layer-330 textarea {
    color: #000000;
    font-family: "arial",arial;
    font-weight: 400;
}
.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}

#ulp-layer-330 input.ulp-input {
    padding-left: 32px !important;
}

.ulp-input {
    background: none repeat scroll 0 0 rgba(255, 255, 255, 0.8);
    border-radius: 2px !important;
    border-spacing: 0 !important;
    border-style: solid !important;
    border-width: 1px !important;
    box-shadow: none !important;
    box-sizing: border-box !important;
    clear: both !important;
    font-size: inherit !important;
    height: 100% !important;
    line-height: 1.5 !important;
    margin: 0 !important;
    padding: 0 6px !important;
    vertical-align: middle !important;
    width: 100% !important;
}

#ulp-layer-331 {
    text-align: left;
    z-index: 1000007;
}
#ulp-layer-331, #ulp-layer-331 p, #ulp-layer-331 a, #ulp-layer-331 span, #ulp-layer-331 li, #ulp-layer-331 input, #ulp-layer-331 button, #ulp-layer-331 textarea {
    color: #000000;
    font-family: "arial",arial;
    font-weight: 400;
    text-shadow: 1px 1px 1px #ffffff;
}
.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}

#ulp-layer-332 {
    text-align: center;
    z-index: 1000007;
}
#ulp-layer-332, #ulp-layer-332 p, #ulp-layer-332 a, #ulp-layer-332 span, #ulp-layer-332 li, #ulp-layer-332 input, #ulp-layer-332 button, #ulp-layer-332 textarea {
    color: #ffffff;
    font-family: "arial",arial;
    font-weight: 400;
}
.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}

.ulp-inherited:before {
    content: "";
    display: inline-block;
    height: 100%;
    padding-top: 3px;
    vertical-align: middle;
}
#ulp-bWaEIuDwaA6kwFYA .ulp-submit, #ulp-bWaEIuDwaA6kwFYA .ulp-submit:visited {
    background: none repeat scroll 0 0 #555555;
    border: 1px solid #555555;
    border-radius: 2px !important;
    box-shadow: -4px -4px 0 rgba(0, 0, 0, 0.1) inset;
}
.ulp-window a {
    text-decoration: none !important;
}
.ulp-inherited {
    box-sizing: border-box !important;
    display: block !important;
    height: 100% !important;
}
.ulp-submit, .ulp-submit:visited, .ulp-submit-button, .ulp-submit-button:visited {
    border-radius: 2px;
    cursor: pointer;
    display: inline-block;
    font-size: inherit !important;
    height: auto;
    line-height: 1.5;
    margin: 0;
    padding: 5px 20px;
    position: relative;
    text-decoration: none !important;
    text-shadow: 0 -1px 1px rgba(0, 0, 0, 0.25);
    transition-duration: 0.3s;
    white-space: nowrap;
    width: auto;
}

#ulp-bWaEIuDwaA6kwFYA .ulp-submit, #ulp-bWaEIuDwaA6kwFYA .ulp-submit:visited {
    background: none repeat scroll 0 0 #555555;
    border: 1px solid #555555;
    border-radius: 2px !important;
    box-shadow: -4px -4px 0 rgba(0, 0, 0, 0.1) inset;
}
#ulp-layer-333 {
    text-align: center;
    z-index: 1000007;
}
#ulp-layer-333, #ulp-layer-333 p, #ulp-layer-333 a, #ulp-layer-333 span, #ulp-layer-333 li, #ulp-layer-333 input, #ulp-layer-333 button, #ulp-layer-333 textarea {
    color: #ffffff;
    font-family: "arial",arial;
    font-weight: 400;
}
.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}

#ulp-layer-334 {
    text-align: center;
    z-index: 1000007;
}
#ulp-layer-334, #ulp-layer-334 p, #ulp-layer-334 a, #ulp-layer-334 span, #ulp-layer-334 li, #ulp-layer-334 input, #ulp-layer-334 button, #ulp-layer-334 textarea {
    color: #ffffff;
    font-family: "arial",arial;
    font-weight: 400;
}
.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}

#ulp-layer-335 {
    text-align: right;
    z-index: 1000007;
}
#ulp-layer-335, #ulp-layer-335 p, #ulp-layer-335 a, #ulp-layer-335 span, #ulp-layer-335 li, #ulp-layer-335 input, #ulp-layer-335 button, #ulp-layer-335 textarea {
    color: #ffffff;
    font-family: "arial",arial;
    font-weight: 400;
    text-shadow: 1px 1px 1px #000000;
}
.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}

#ulp-bWaEIuDwaA6kwFYA .ulp-input, #ulp-bWaEIuDwaA6kwFYA .ulp-input:hover, #ulp-bWaEIuDwaA6kwFYA .ulp-input:active, #ulp-bWaEIuDwaA6kwFYA .ulp-input:focus {
    background-color: rgba(255, 255, 255, 1) !important;
    border-color: #ffffff;
    border-radius: 2px !important;
    border-width: 1px !important;
}

.fa-edit:before, .fa-pencil-square-o:before {
    content: "";
}
.fa {
    display: inline-block;
    font-family: FontAwesome;
    font-feature-settings: normal;
    font-kerning: auto;
    font-language-override: normal;
    font-size: inherit;
    font-size-adjust: none;
    font-stretch: normal;
    font-style: normal;
    font-synthesis: weight style;
    font-variant: normal;
    font-weight: normal;
    line-height: 1;
    text-rendering: auto;
}

.inp-t{
    background: none repeat scroll 0 0 #555555;
    border: 1px solid #555555;
    border-radius: 2px !important;
    box-shadow: -4px -4px 0 rgba(0, 0, 0, 0.1) inset;
	}

	#ulp-bWaEIuDwaA6kwFYA .ulp-submit-facebook, #ulp-bWaEIuDwaA6kwFYA .ulp-submit-facebook:visited {
    background: none repeat scroll 0 0 #3b5998;
    border: 1px solid #3b5998;
}

#ulp-bWaEIuDwaA6kwFYA .ulp-submit-button, #ulp-bWaEIuDwaA6kwFYA .ulp-submit-button:visited {
    box-shadow: -4px -4px 0 rgba(0, 0, 0, 0.1) inset;
}
#ulp-bWaEIuDwaA6kwFYA .ulp-submit-button, #ulp-bWaEIuDwaA6kwFYA .ulp-submit-button:visited, #ulp-bWaEIuDwaA6kwFYA .ulp-submit-button:hover, #ulp-bWaEIuDwaA6kwFYA .ulp-submit-button:active {
    border-radius: 2px !important;
}

.inp-t2{
    background: none repeat scroll 0 0 #3b5998;
    border: 1px solid #3b5998;
	}

.inp-t3{
    background: none repeat scroll 0 0 #d34836;
    border: 1px solid #d34836;
}

#ulp-layer-331 div.ulp-fa-input-cell {
    padding-left: 4px !important;
    width: 28px !important;
}
.ulp-fa-input-cell {
    display: table-cell;
    opacity: 0.7;
    text-align: center;
    vertical-align: middle;
}
#ulp-layer-331 input.ulp-input {
    padding-left: 32px !important;
}	

table
{
	margin:20px;
	background:#f8f8f8;
	
}
table td
{
	padding:10px;
	border:1px solid #ccc;
}
table td label
{
	font-family:Arial, Helvetica, sans-serif;
	font-size:14px;
	font-weight:normal;
}
table td input[type='text']
{
	border:none;
	padding:10px;
	font-size:12px;
	font-weight:normal;
	border:1px solid #ccc;
	width:300px;
}
table td textarea
{
	width:300px;
	font-size:12px;
}
#updateform
{
	background:#019ad2;
	color:#fff;
	font-size:16px;
	padding:10px;
	border:1px solid #019ad2;
	width:100px;
}
</style>

<?php


$txthtml="<div id='popupform' style='position:relative;'><div class='ulp-content ' style='width: 390px; height: 449px; margin: 5% auto auto;'>
							<div id='ulp-layer-324' class='ulp-layer animated bounce' style='width: 390px; height: 302px; font-size: 13px; left: 0px; top: 0px;'></div>
							<div id='ulp-layer-325' class='ulp-layer' style='width: 390px; height: 146px; font-size: 13px; left: 0px; top: 302px;'></div>
							<div id='ulp-layer-326' class='ulp-layer animated fadeOut' style='width: 390px; height: 449px; font-size: 13px; left: 0px; top: 0px;'></div>
							<div id='ulp-layer-328' class='ulp-layer animated slideInLeft' style='width: 390px; font-size: 21px; left: 0px; top: 14px;'>ARE YOU READY? GET IT NOW!</div>
							<div id='ulp-layer-329' class='ulp-layer animated slideInRight' style='width: 331px; font-size: 13px; left: 29px; top: 48px;'>Vel eros amet amet mauris a habitasse scel erisque? Vel urna dis et, placerat phasellus, diam in! Placerat nec facilisis, tortor tristique. Arcu placerat sagittis, velit lorem scelerisque egestas placerat.</div>
							<div id='ulp-layer-330' class='ulp-layer animated flipInX' style='width: 292px; height: 35px; font-size: 13px; left: 48px; top: 136px;'>
							<input type='text' onfocus='jQuery(this).removeClass('ulp-input-error');' value='' placeholder='Enter your name...' name='ulp-name' class='ulp-input'>
							<div class='ulp-fa-input-table' style='margin-left: 13px; margin-top: -24px;'><div class='ulp-fa-input-cell'><i class='fa fa-user'></i></div>
							</div>
							</div>
							<div id='ulp-layer-331' class='ulp-layer  animated flipInX' style='width: 292px; height: 35px; font-size: 13px; left: 48px; top: 182px;'><input type='text' onfocus='jQuery(this).removeClass('ulp-input-error');' value='' placeholder='Enter your e-mail...' name='ulp-email' class='ulp-input'><div class='ulp-fa-input-table' style='margin-left: 0px; margin-top: -24px;'><div class='ulp-fa-input-cell'><i class='fa fa-envelope'></i></div></div></div>
							<div id='ulp-layer-332' class='ulp-layer animated zoomIn' style='width: 175px; height: 39px; font-size: 15px; left: 107px; top: 229px;'><a data-loading='Loading...' data-label='Subscribe' data-icon='fa-pencil-square-o' onclick='return ulp_subscribe(this);' class=' inp-t ulp-submit ulp-inherited'><i class='fa fa-pencil-square-o'></i>&nbsp; Subscribe</a></div>
							<div id='ulp-layer-335' class='ulp-layer' style='width: 39px; height: 19px; font-size: 23px; left: 348px; top: -9px;'><a onclick='return ulp_self_close();' href='#'>x</a></div>
						</div>
					
						
						</div>
						";
						echo $txthtml;
						?>
						
                        
 <div >

<table width="97%" border="0">
  <tr>
    
    <td><label>Popup Background Color :</label></td>
    <td><input class="color boxcolor" value="66ff00" id="popbgcolor" onchange="popup_bg();"></td>
    <td><label>Footer Background Color :</label></td>
    <td><input class="color boxcolor" value="66ff00" id="bkgcolor" onchange="footer_bg();"></td>
    <td></td>
    <td></td>
    
  </tr>
  <tr>
    <td><label>Layer one Color :</label></td>
    <td><input class="color boxcolor" value="66ff00" id="layer1_color" onchange="layer1_color();"></td>
    <td><label>Layer One Text :</label></td>
    <td><input type="text" value="" id="layer1_txt" onkeypress="layer1_txt();" maxlength="30" /></td>
   <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
   <tr>
    <td><label>Layer Two Color :</label></td>
    <td><input class="color boxcolor" value="66ff00" id="layer2_color" onchange="layer2_color();"></td>
    <td><label>Layer Two Text :</label></td>
    <td><input type="text" value="" id="layer2_txt" onkeypress="layer2_txt();"  /></td>
   <td>&nbsp;</td>
    <td>&nbsp;</td> 
  </tr>
   <tr>
    <td><label>Placeholder one text :</label></td>
    <td><input type="text" value="" id="placeholder1_txt" onkeypress="placeholder1_txt();"  /></td>
    <td><label>Placeholder Two text :</label></td>
    <td><input type="text" value="" id="placeholder2_txt" onkeypress="placeholder2_txt();"  /></td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  
    <tr>
    <td><label>Subscribe Text Color:</label></td>
    <td><input class="color boxcolor" value="66ff00" id="button1_color" onchange="button1_color();"></td>
    <td><label> Subscribe Background Color :</label></td>
    <td><input class="color boxcolor" value="66ff00" id="button1_bkgcolor" onchange="button1_bkgcolor();"></td>
    <td><label> Subscribe Text :</label></td>
    <td><input type="text" value="" maxlength="20" id="button1_txt" onkeypress="button1_txt();"  /></td>
  
  </tr>

  
    <tr>
<td>&nbsp;</td>    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  
  
 
</table>

</div>                       
<script type="text/javascript">
function pop_layer_data()
{
	var layer1_txt=$("#ulp-layer-328").html();
    var layer2_txt=$("#ulp-layer-329").html();
    var layer3_txt=$("#ulp-layer-327").html();
   
    var placeholder1_txt=$("#ulp-layer-330 .ulp-input").attr('placeholder');
    var placeholder2_txt=$("#ulp-layer-331 .ulp-input").attr('placeholder');
    var button1_txt=$("#ulp-layer-332 .ulp-inherited").html();
    var button2_txt=$("#ulp-layer-333 .ulp-submit-facebook").html();
    var button3_txt=$("#ulp-layer-334 .ulp-submit-google").html();
    
	/*
	
	var layer4_txt=$("#ulp-layer-182").html();
	
	
	var placeholder3_txt=$("#ulp-layer-180 .ulp-input").attr('placeholder');
	 */

	$("#layer1_txt").val(layer1_txt);
    $("#layer2_txt").val(layer2_txt);
    $("#layer3_txt").val(layer3_txt);
    $("#placeholder1_txt").val(placeholder1_txt);
    $("#placeholder2_txt").val(placeholder2_txt);
    $("#button1_txt").val(button1_txt);
    $("#button2_txt").val(button2_txt);
    $("#button3_txt").val(button3_txt);
    
	/*
	$("#label1_txt").val(label1_txt);
	$("#label2_txt").val(label2_txt);
	$("#label3_txt").val(label3_txt);
	$("#layer4_txt").val(layer4_txt);
	
	
	$("#placeholder3_txt").val(placeholder3_txt);
	 */ 
}
                 		function popup_bg()
						{
							
							var popbgcolor="#"+$("#popbgcolor").val();
							//alert(bgcolor);
							$("#ulp-layer-324").css("background-color",popbgcolor);
						}
						function footer_bg()
						{
							var bkgcolor="#"+$("#bkgcolor").val();
							//alert(bgcolor);
							$("#ulp-layer-325").css("background-color",bkgcolor);
						}
						
						function layer1_color()
						{
							
							var fcolor="#"+$("#layer1_color").val();
							//alert(bgcolor);
							$("#ulp-layer-328").css("color",fcolor);
						}
						function layer1_txt()
						{
							var layer1_txt=$("#layer1_txt").val();
							//alert(bgcolor);
							$("#ulp-layer-328").html(layer1_txt);
						}
						function layer2_color()
						{
							var fcolor="#"+$("#layer2_color").val();
							//alert(bgcolor);
							$("#ulp-layer-329").css("color",fcolor);
						}
						function layer2_txt()
						{
							var layer2_txt=$("#layer2_txt").val();
							//alert(bgcolor);
							$("#ulp-layer-329").html(layer2_txt);
						}
						function layer3_color()
						{
							var fcolor="#"+$("#layer3_color").val();
							//alert(bgcolor);
							$("#ulp-layer-327").css("color",fcolor);
						}
						function layer3_txt()
						{
							var layer3_txt=$("#layer3_txt").val();
							//alert(bgcolor);
							$("#ulp-layer-327").html(layer3_txt);
						}
						function layer3_BgColor()
						{
							var bgcolor=$("#layer3_BgColor").val();
							//alert(bgcolor);
							$("#ulp-layer-327 .animated bounce").html("color",bgcolor);
						}
                        
						
						
						
						function placeholder1_txt()
						{
							var placeholder1_txt=$("#placeholder1_txt").val();
							//alert(bgcolor);
							$("#ulp-layer-330 .ulp-input").attr('placeholder',placeholder1_txt);
						}
						
						
						function placeholder2_txt()
						{
							var placeholder2_txt=$("#placeholder2_txt").val();
							//alert(bgcolor);
							$("#ulp-layer-331 .ulp-input").attr('placeholder',placeholder2_txt);
						}
						
						
						function button1_color()
						{
							var fcolor="#"+$("#button1_color").val();
							//alert(bgcolor);
							$("#ulp-layer-332 .ulp-inherited").css("color",fcolor);
						}
						function button1_bkgcolor()
						{
							var button1_bkgcolor="#"+$("#button1_bkgcolor").val();
							//alert(button1_bkgcolor);
							$("#ulp-layer-332 .ulp-inherited").css('background',button1_bkgcolor);
						}
						function button1_txt()
						{
							var button1_txt=$("#button1_txt").val();
							//alert(bgcolor);
							$("#ulp-layer-332 .ulp-inherited").html(button1_txt);
						}


						
						function button2_color()
						{
							var fcolor="#"+$("#button2_color").val();
							
							//alert(bgcolor);
							$("#ulp-layer-333 .ulp-submit-facebook").css("color",fcolor);
						}
						function button2_bkgcolor()
						{
							var button2_bkgcolor="#"+$("#button2_bkgcolor").val();
							
							//alert(button1_bkgcolor);
							$("#ulp-layer-333 .ulp-submit-facebook").css('background',button2_bkgcolor);
						}
						function button2_txt()
						{
							var button2_txt=$("#button2_txt").val();
							//alert(button2_txt);
							//alert(bgcolor);
							$("#ulp-layer-333 .ulp-submit-facebook").html(button2_txt);
						}



						function button3_color()
						{
							var fcolor="#"+$("#button3_color").val();
							
							//alert(bgcolor);
							$("#ulp-layer-334 .ulp-submit-google").css("color",fcolor);
						}
						function button3_bkgcolor()
						{
							var button3_bkgcolor="#"+$("#button3_bkgcolor").val();
							
							//alert(button1_bkgcolor);
							$("#ulp-layer-334 .ulp-submit-google").css('background',button3_bkgcolor);
						}
						function button3_txt()
						{
							var button3_txt=$("#button3_txt").val();
							//alert(bgcolor);
							$("#ulp-layer-334 .ulp-submit-google").html(button3_txt);
						}
						
						
						function updateform()
						{
							var popupform= $("#popupform").html();
							
							$.ajax({
							type: "post",
							url: 'animatemaster/updatepop1.php',
							data: {
							popupform: popupform,
							},			
							success: function(response) {
								alert(response);
							},
							error:function 
							(XMLHttpRequest, textStatus, errorThrown) {
							}
							});  
							
						}
						</script>











