<link rel="stylesheet" href="http://www.cliks.it/click/views/layered/animatemaster/animate.min.css">
<style>
body
{
margin:0px;
padding:0px;
}
.ulp-content {
    position: relative;
}
.ulp-window {
    text-align: left;
}#ulp-layer-149 {
    background-color: rgba(0, 0, 0, 0.9);
    box-shadow: 0 4px 30px rgba(32, 32, 32, 1);
    text-align: left;
    z-index: 1000002;
}
#ulp-layer-149, #ulp-layer-149 p, #ulp-layer-149 a, #ulp-layer-149 span, #ulp-layer-149 li, #ulp-layer-149 input, #ulp-layer-149 button, #ulp-layer-149 textarea {
    color: #000000;
    font-family: "arial",arial;
    font-weight: 400;
}
.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}
.ulp-layer img {
    border: medium none !important;
    box-shadow: none !important;
    margin: 0 !important;
    max-width: 100% !important;
    min-width: 0 !important;
    padding: 0 !important;
}
img {
    max-width: 100%;
}
#ulp-layer-149 {
    text-align: left;
}
#ulp-layer-149, #ulp-layer-149 p, #ulp-layer-149 a, #ulp-layer-149 span, #ulp-layer-149 li, #ulp-layer-149 input, #ulp-layer-149 button, #ulp-layer-149 textarea {
    color: #000000;
}
#ulp-layer-150 {
    background-color: rgba(10, 10, 10, 0.6);
    padding: 5px 20px;
    text-align: left;
    z-index: 1000003;
}
#ulp-layer-150, #ulp-layer-150 p, #ulp-layer-150 a, #ulp-layer-150 span, #ulp-layer-150 li, #ulp-layer-150 input, #ulp-layer-150 button, #ulp-layer-150 textarea {
    color: #ffffff;
    font-family: "Open Sans",arial;
    font-weight: 100;
    text-shadow: 1px 1px 1px #000000;
}
.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}
#ulp-layer-151 {
    background-color: rgba(0, 0, 0, 0.7);
    text-align: left;
    z-index: 1000007;
}
#ulp-layer-151, #ulp-layer-151 p, #ulp-layer-151 a, #ulp-layer-151 span, #ulp-layer-151 li, #ulp-layer-151 input, #ulp-layer-151 button, #ulp-layer-151 textarea {
    color: #000000;
    font-family: "arial",arial;
    font-weight: 400;
}
.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}
#ulp-layer-152 {
    text-align: justify;
    z-index: 1000007;
}
#ulp-layer-152, #ulp-layer-152 p, #ulp-layer-152 a, #ulp-layer-152 span, #ulp-layer-152 li, #ulp-layer-152 input, #ulp-layer-152 button, #ulp-layer-152 textarea {
    color: #ffffff;
    font-family: "Open Sans",arial;
    font-weight: 100;
    text-shadow: 1px 1px 1px #000000;
}
.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}
#ulp-layer-153 {
    text-align: left;
    z-index: 1000007;
}
#ulp-layer-153, #ulp-layer-153 p, #ulp-layer-153 a, #ulp-layer-153 span, #ulp-layer-153 li, #ulp-layer-153 input, #ulp-layer-153 button, #ulp-layer-153 textarea {
    color: #ffffff;
    font-family: "Open Sans",arial;
    font-weight: 100;
    text-shadow: 1px 1px 1px #000000;
}
.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}
#ulp-layer-153 input.ulp-input {
    padding-left: 34px !important;
}
#ulp-KiNSkXji3bqvBVUB .ulp-input, #ulp-KiNSkXji3bqvBVUB .ulp-input:hover, #ulp-KiNSkXji3bqvBVUB .ulp-input:active, #ulp-KiNSkXji3bqvBVUB .ulp-input:focus {
    background-color: rgba(0, 0, 0, 0.8) !important;
    border-color: #606060;
    border-radius: 3px !important;
    border-width: 1px !important;
}
#ulp-layer-153, #ulp-layer-153 p, #ulp-layer-153 a, #ulp-layer-153 span, #ulp-layer-153 li, #ulp-layer-153 input, #ulp-layer-153 button, #ulp-layer-153 textarea {
    color: #ffffff;
    font-family: "Open Sans",arial;
    font-weight: 100;
    text-shadow: 1px 1px 1px #000000;
}
.ulp-input {
    background: none repeat scroll 0 0 rgba(255, 255, 255, 0.8);
    border-radius: 2px !important;
    border-spacing: 0 !important;
    border-style: solid !important;
    border-width: 1px !important;
    box-shadow: none !important;
    box-sizing: border-box !important;
    clear: both !important;
    font-size: inherit !important;
    height: 100% !important;
    line-height: 1.5 !important;
    margin: 0 !important;
    padding: 0 6px !important;
    vertical-align: middle !important;
    width: 100% !important;
}
input:-moz-read-write, textarea:-moz-read-write {
    -moz-user-modify: read-write !important;
}
input {
    -moz-appearance: textfield;
    -moz-binding: url("chrome://global/content/platformHTMLBindings.xml#inputFields");
    -moz-user-select: text;
    cursor: text;
    font: ;
    letter-spacing: normal;
    line-height: normal;
    padding: 1px;
    text-align: start;
    text-indent: 0;
    text-rendering: optimizelegibility;
    text-transform: none;
    word-spacing: normal;
}
textarea > .anonymous-div, input > .anonymous-div, input::-moz-placeholder, textarea::-moz-placeholder, *|*::-moz-button-content, *|*::-moz-display-comboboxcontrol-frame, optgroup:before {
    text-overflow: inherit;
    unicode-bidi: inherit;
}
input::-moz-placeholder, textarea::-moz-placeholder {
    display: inline-block !important;
    opacity: 0.54;
    overflow: hidden !important;
    pointer-events: none !important;
    resize: none !important;
}
textarea > .anonymous-div, input > .anonymous-div, input::-moz-placeholder, textarea::-moz-placeholder {
    -moz-control-character-visibility: visible;
    border: 0 none !important;
    display: inline-block;
    ime-mode: inherit;
    margin: 0;
    overflow: auto;
    padding: inherit !important;
    resize: inherit;
    text-decoration: inherit;
    white-space: pre;
}
input > .anonymous-div, input::-moz-placeholder {
    line-height: -moz-block-height;
    word-wrap: normal !important;
}

.ulp-fa-input-table {
    display: table;
    height: 100%;
    left: 0;
    line-height: 100%;
    position: absolute;
    top: 0;
    vertical-align: middle;
}
#ulp-layer-153 div.ulp-fa-input-cell {
    padding-left: 4px !important;
    width: 30px !important;
}
.ulp-fa-input-cell {
    display: table-cell;
    opacity: 0.7;
    text-align: center;
    vertical-align: middle;
}
#ulp-layer-153, #ulp-layer-153 p, #ulp-layer-153 a, #ulp-layer-153 span, #ulp-layer-153 li, #ulp-layer-153 input, #ulp-layer-153 button, #ulp-layer-153 textarea {
    color: #ffffff;
    text-shadow: 1px 1px 1px #000000;
}
.fa-user:before {
    content: "";
}
.fa-user:before {
    content: "";
}
.fa {
    display: inline-block;
    font-family: FontAwesome;
    font-feature-settings: normal;
    font-kerning: auto;
    font-language-override: normal;
    font-size: inherit;
    font-size-adjust: none;
    font-stretch: normal;
    font-style: normal;
    font-synthesis: weight style;
    font-variant: normal;
    font-weight: normal;
    line-height: 1;
    text-rendering: auto;
}
.ulp-fa-input-cell {
    text-align: center;
}
#ulp-layer-154 {
    text-align: left;
    z-index: 1000007;
}
#ulp-layer-154, #ulp-layer-154 p, #ulp-layer-154 a, #ulp-layer-154 span, #ulp-layer-154 li, #ulp-layer-154 input, #ulp-layer-154 button, #ulp-layer-154 textarea {
    color: #ffffff;
    font-family: "Open Sans",arial;
    font-weight: 100;
    text-shadow: 1px 1px 1px #000000;
}
.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}
#ulp-layer-154 input.ulp-input {
    padding-left: 34px !important;
}
#ulp-KiNSkXji3bqvBVUB .ulp-input, #ulp-KiNSkXji3bqvBVUB .ulp-input:hover, #ulp-KiNSkXji3bqvBVUB .ulp-input:active, #ulp-KiNSkXji3bqvBVUB .ulp-input:focus {
    background-color: rgba(0, 0, 0, 0.8) !important;
    border-color: #606060;
    border-radius: 3px !important;
    border-width: 1px !important;
}
#ulp-layer-154, #ulp-layer-154 p, #ulp-layer-154 a, #ulp-layer-154 span, #ulp-layer-154 li, #ulp-layer-154 input, #ulp-layer-154 button, #ulp-layer-154 textarea {
    color: #ffffff;
    font-family: "Open Sans",arial;
    font-weight: 100;
    text-shadow: 1px 1px 1px #000000;
}
.ulp-input {
    background: none repeat scroll 0 0 rgba(255, 255, 255, 0.8);
    border-radius: 2px !important;
    border-spacing: 0 !important;
    border-style: solid !important;
    border-width: 1px !important;
    box-shadow: none !important;
    box-sizing: border-box !important;
    clear: both !important;
    font-size: inherit !important;
    height: 100% !important;
    line-height: 1.5 !important;
    margin: 0 !important;
    padding: 0 6px !important;
    vertical-align: middle !important;
    width: 100% !important;
	background: none repeat scroll 0 0 #000;
	opacity:0.8;
}
input:-moz-read-write, textarea:-moz-read-write {
    -moz-user-modify: read-write !important;
}
input {
    -moz-appearance: textfield;
    -moz-binding: url("chrome://global/content/platformHTMLBindings.xml#inputFields");
    -moz-user-select: text;
    cursor: text;
    font: ;
    letter-spacing: normal;
    line-height: normal;
    padding: 1px;
    text-align: start;
    text-indent: 0;
    text-rendering: optimizelegibility;
    text-transform: none;
    word-spacing: normal;
}
textarea > .anonymous-div, input > .anonymous-div, input::-moz-placeholder, textarea::-moz-placeholder, *|*::-moz-button-content, *|*::-moz-display-comboboxcontrol-frame, optgroup:before {
    text-overflow: inherit;
    unicode-bidi: inherit;
}
input::-moz-placeholder, textarea::-moz-placeholder {
    display: inline-block !important;
    opacity: 0.54;
    overflow: hidden !important;
    pointer-events: none !important;
    resize: none !important;
}
textarea > .anonymous-div, input > .anonymous-div, input::-moz-placeholder, textarea::-moz-placeholder {
    -moz-control-character-visibility: visible;
    border: 0 none !important;
    display: inline-block;
    ime-mode: inherit;
    margin: 0;
    overflow: auto;
    padding: inherit !important;
    resize: inherit;
    text-decoration: inherit;
    white-space: pre;
}
input > .anonymous-div, input::-moz-placeholder {
    line-height: -moz-block-height;
    word-wrap: normal !important;
}
.ulp-fa-input-table {
    display: table;
    height: 100%;
    left: 0;
    line-height: 100%;
    position: absolute;
    top: 0;
    vertical-align: middle;
}
#ulp-layer-154 {
    text-align: left;
}
#ulp-layer-154, #ulp-layer-154 p, #ulp-layer-154 a, #ulp-layer-154 span, #ulp-layer-154 li, #ulp-layer-154 input, #ulp-layer-154 button, #ulp-layer-154 textarea {
    color: #ffffff;
    text-shadow: 1px 1px 1px #000000;
}
#ulp-layer-154 div.ulp-fa-input-cell {
    padding-left: 4px !important;
    width: 30px !important;
}
.ulp-fa-input-cell {
    display: table-cell;
    opacity: 0.7;
    text-align: center;
    vertical-align: middle;
}
.fa-envelope:before {
    content: "";
}
.fa-envelope:before {
    content: "";
}
.fa {
    display: inline-block;
    font-family: FontAwesome;
    font-feature-settings: normal;
    font-kerning: auto;
    font-language-override: normal;
    font-size: inherit;
    font-size-adjust: none;
    font-stretch: normal;
    font-style: normal;
    font-synthesis: weight style;
    font-variant: normal;
    font-weight: normal;
    line-height: 1;
    text-rendering: auto;
}
.ulp-fa-input-cell {
    text-align: center;
}
#ulp-layer-155 {
    text-align: right;
    z-index: 1000007;
}
#ulp-layer-155, #ulp-layer-155 p, #ulp-layer-155 a, #ulp-layer-155 span, #ulp-layer-155 li, #ulp-layer-155 input, #ulp-layer-155 button, #ulp-layer-155 textarea {
    color: #ffffff;
    font-family: "Open Sans",arial;
    font-weight: 100;
    text-shadow: 1px 1px 1px #000000;
}
.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}
#ulp-KiNSkXji3bqvBVUB .ulp-submit, #ulp-KiNSkXji3bqvBVUB .ulp-submit:visited {
    background: linear-gradient(#94b336, #a6c93c) repeat scroll 0 0 #a6c93c;
    border: 1px solid #a6c93c;
    border-radius: 3px !important;
}
#ulp-layer-155, #ulp-layer-155 p, #ulp-layer-155 a, #ulp-layer-155 span, #ulp-layer-155 li, #ulp-layer-155 input, #ulp-layer-155 button, #ulp-layer-155 textarea {
    color: #ffffff;
    font-family: "Open Sans",arial;
    font-weight: 100;
    text-shadow: 1px 1px 1px #000000;
}
.ulp-window a {
    text-decoration: none !important;
}
.ulp-submit, .ulp-submit:visited, .ulp-submit-button, .ulp-submit-button:visited {
    border-radius: 2px;
    box-shadow: none;
    cursor: pointer;
    display: inline-block;
    font-size: inherit !important;
    height: auto;
    line-height: 1.5;
    margin: 0;
    padding: 5px 20px;
    position: relative;
    text-decoration: none !important;
    transition-duration: 0.3s;
    white-space: nowrap;
    width: auto;
	background: linear-gradient(#94b336, #a6c93c) repeat scroll 0 0 #a6c93c;
    border: 1px solid #a6c93c;
    border-radius: 3px !important;
}
.fo-right-ribbon a:hover, .fo-right-ribbon a:focus, a {
    text-decoration: none;
}
a, a:active, a:hover {
    outline: medium none;
}
.fa-sign-in:before {
    content: "";
}
.fa-sign-in:before {
    content: "";
}
.fa {
    display: inline-block;
    font-family: FontAwesome;
    font-feature-settings: normal;
    font-kerning: auto;
    font-language-override: normal;
    font-size: inherit;
    font-size-adjust: none;
    font-stretch: normal;
    font-style: normal;
    font-synthesis: weight style;
    font-variant: normal;
    font-weight: normal;
    line-height: 1;
    text-rendering: auto;
}
#ulp-layer-155, #ulp-layer-155 p, #ulp-layer-155 a, #ulp-layer-155 span, #ulp-layer-155 li, #ulp-layer-155 input, #ulp-layer-155 button, #ulp-layer-155 textarea {
    color: #ffffff;
    text-shadow: 1px 1px 1px #000000;
}
.ulp-submit, .ulp-submit:visited, .ulp-submit-button, .ulp-submit-button:visited {
    cursor: pointer;
    font-size: inherit !important;
    white-space: nowrap;
}
#ulp-layer-155 {
    text-align: right;
}
#ulp-layer-156 {
    background-color: rgba(0, 0, 0, 0.5);
    padding: 0 10px;
    text-align: left;
    z-index: 1000007;
}
#ulp-layer-156, #ulp-layer-156 p, #ulp-layer-156 a, #ulp-layer-156 span, #ulp-layer-156 li, #ulp-layer-156 input, #ulp-layer-156 button, #ulp-layer-156 textarea {
    color: #ffffff;
    font-family: "Open Sans",arial;
    font-weight: 100;
    text-shadow: 1px 1px 1px #000000;
}
.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}
#ulp-layer-156, #ulp-layer-156 p, #ulp-layer-156 a, #ulp-layer-156 span, #ulp-layer-156 li, #ulp-layer-156 input, #ulp-layer-156 button, #ulp-layer-156 textarea {
    color: #ffffff;
    font-family: "Open Sans",arial;
    font-weight: 100;
    text-shadow: 1px 1px 1px #000000;
}
.ulp-window a {
    text-decoration: none !important;
}
.fo-right-ribbon a:hover, .fo-right-ribbon a:focus, a {
    text-decoration: none;
}
a, .contactForm input[type="text"]:focus, .contactForm input[type="email"]:focus, .contactForm textarea:focus, input#formSubmit, .errorForm, #subscribe input[type="email"]:focus, .errorSubs, .servSingle, #toTop i, #notForm input[type="email"]:focus, .contactForm input#submit, #loginForm input, #loginForm input[type="text"]:focus, #loginForm input[type="password"]:focus {
    transition: all 0.5s ease 0s;
}
a, a:active, a:hover {
    outline: medium none;
}
</style>

 

<div id='popupform_preview' style="display:none;"><div class='ulp-content' style='width: 640px; height: 480px; margin:auto;position:fixed; left:30%; top:15%;'>
							<div id="ulp-layer-149" class="ulp-layer animated bounceInDown" style="width: 640px; height: 400px; font-size: 14px; left: 0px; top: 0px;"><img alt="" src="https://layeredpopups.com/layered-popups/images/default/business03.jpg"></div>
							<div id="ulp-layer-150" class="ulp-layer animated bounceInLeft" style="font-size: 28px; left: 0px; top: 20px;">SUBSCRIBE TO NEWSLETTER</div>
							<div id="ulp-layer-151" class="ulp-layer animated bounceInRight" style="width: 340px; height: 280px; font-size: 14px; left: 300px; top: 100px;"></div>
							<div id="ulp-layer-152" class="ulp-layer animated slideInDown" style="width: 300px; font-size: 14px; left: 320px; top: 120px;">Turpis dis amet adipiscing hac montes odio ac velit? Porta, non rhoncus vut, vel, et adipiscing magna pulvinar adipiscing est adipiscing urna. Dignissim rhoncus scelerisque pulvinar?</div>
							<div id="ulp-layer-153" class="ulp-layer animated zoomInRight" style="width: 300px; height: 38px; font-size: 15px; left: 320px; top: 220px;"><input type="text" onfocus="jQuery(this).removeClass('ulp-input-error');" value="" placeholder="Enter your name..." name="ulp-name" class="ulp-input"><div class="ulp-fa-input-table"><div class="ulp-fa-input-cell"><i class="fa fa-user"></i></div></div></div>
							<div id="ulp-layer-154" class="ulp-layer animated zoomInLeft" style="width: 300px; height: 38px; font-size: 15px; left: 320px; top: 265px;"><input type="text" onfocus="jQuery(this).removeClass('ulp-input-error');" value="" placeholder="Enter your e-mail..." name="ulp-email" class="ulp-input"><div class="ulp-fa-input-table"><div class="ulp-fa-input-cell"><i class="fa fa-envelope"></i></div></div></div>
							<div id="ulp-layer-155" class="ulp-layer animated slideInUp" style="width: 300px; height: 38px; font-size: 15px; left: 320px; top: 310px;"><a data-loading="Loading..." data-label="Subscribe" data-icon="fa-sign-in" onclick="return ulp_subscribe(this);" class="ulp-submit"><i class="fa fa-sign-in"></i>&nbsp; Subscribe</a></div>
							<div id="ulp-layer-156" class="ulp-layer" style="height: 20px; font-size: 12px; left: 0px; top: 380px;"><a onclick="return ulp_self_close();" href="#">close</a></div>
						</div>
	<div id="blackscreen" style='width:100%; height:100%; background:#000; opacity:0.7; top:0; left:0; position:fixed; z-index:20000; display:none;'></div>
						</div>
                        
                        
                        <script>
function ulp_self_close()
{
	$("#popupform_preview").hide();
	$("#blackscreen").hide();
	$("#popup_content_data").html('');
}
</script>                        