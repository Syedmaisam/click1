<link rel="stylesheet" href="<?php echo SITE_ROOT_URL; ?>views/layered/animatemaster/animate.min.css">
<script type="text/javascript" src="<?php echo SITE_ROOT_URL; ?>colorjs/jscolor.js"></script>
<style>
body
{
margin:0px;
padding:0px;
}
.ulp-content {
    position: relative;
}
#ulp-layer-205 {
    background-color: rgba(255, 255, 255, 1);
    border-radius: 3px;
    box-shadow: 0 4px 20px rgba(32, 32, 32, 1);
    text-align: left;
    z-index: 1000003;
}
#ulp-layer-205, #ulp-layer-205 p, #ulp-layer-205 a, #ulp-layer-205 span, #ulp-layer-205 li, #ulp-layer-205 input, #ulp-layer-205 button, #ulp-layer-205 textarea {
    color: #000000;
    font-family: "arial",arial;
    font-weight: 400;
}
.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}
#ulp-layer-206 {
    border-radius: 3px;
    box-shadow: 0 0 90px rgba(32, 32, 32, 0.1) inset;
    text-align: left;
    z-index: 1000005;
}
#ulp-layer-206, #ulp-layer-206 p, #ulp-layer-206 a, #ulp-layer-206 span, #ulp-layer-206 li, #ulp-layer-206 input, #ulp-layer-206 button, #ulp-layer-206 textarea {
    color: #000000;
    font-family: "arial",arial;
    font-weight: 400;
}
.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}
#ulp-layer-207 {
    letter-spacing: -1px;
    text-align: left;
    z-index: 1000007;
}
#ulp-layer-207, #ulp-layer-207 p, #ulp-layer-207 a, #ulp-layer-207 span, #ulp-layer-207 li, #ulp-layer-207 input, #ulp-layer-207 button, #ulp-layer-207 textarea {
    color: #56912d;
    font-family: "arial",arial;
    font-weight: 700;
}
.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}
#ulp-layer-208 {
    line-height: 1.3;
    text-align: left;
    z-index: 1000007;
}
#ulp-layer-208, #ulp-layer-208 p, #ulp-layer-208 a, #ulp-layer-208 span, #ulp-layer-208 li, #ulp-layer-208 input, #ulp-layer-208 button, #ulp-layer-208 textarea {
    color: #888888;
    font-family: "arial",arial;
    font-weight: 400;
}
.ulp-layer {
    box-sizing: border-box;
    position: absolute;
}
#ulp-layer-209 {
    text-align: left;
    z-index: 1000007;
}
#ulp-layer-209, #ulp-layer-209 p, #ulp-layer-209 a, #ulp-layer-209 span, #ulp-layer-209 li, #ulp-layer-209 input, #ulp-layer-209 button, #ulp-layer-209 textarea {
    color: #333333;
    font-family: "arial",arial;
    font-weight: 700;
}
.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}
ul.ulp-sf3-popup {
    list-style: outside none none !important;
    margin: 0 !important;
    padding: 0 !important;
}
ul, menu, dir {
    display: block;
}
#ulp-layer-210 {
    background-color: rgba(221, 153, 51, 1);
    border-radius: 3px;
    box-shadow: 0 4px 20px rgba(32, 32, 32, 1);
    text-align: left;
    z-index: 1000005;
}
#ulp-layer-210, #ulp-layer-210 p, #ulp-layer-210 a, #ulp-layer-210 span, #ulp-layer-210 li, #ulp-layer-210 input, #ulp-layer-210 button, #ulp-layer-210 textarea {
    color: #000000;
    font-family: "arial",arial;
    font-weight: 400;
}
.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}
#ulp-layer-211 {
    border-radius: 3px;
    box-shadow: 0 0 90px rgba(32, 32, 32, 0.1) inset;
    text-align: left;
    z-index: 1000005;
}
#ulp-layer-211, #ulp-layer-211 p, #ulp-layer-211 a, #ulp-layer-211 span, #ulp-layer-211 li, #ulp-layer-211 input, #ulp-layer-211 button, #ulp-layer-211 textarea {
    color: #000000;
    font-family: "arial",arial;
    font-weight: 400;
}
.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}
#ulp-layer-212 {
    letter-spacing: -1px;
    text-align: center;
    z-index: 1000007;
}
#ulp-layer-212, #ulp-layer-212 p, #ulp-layer-212 a, #ulp-layer-212 span, #ulp-layer-212 li, #ulp-layer-212 input, #ulp-layer-212 button, #ulp-layer-212 textarea {
    color: #ffffff;
    font-family: "arial",arial;
    font-weight: 700;
    text-shadow: 1px 1px 1px #000000;
}
.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}
#ulp-layer-213 {
    text-align: justify;
    z-index: 1000008;
}
#ulp-layer-213, #ulp-layer-213 p, #ulp-layer-213 a, #ulp-layer-213 span, #ulp-layer-213 li, #ulp-layer-213 input, #ulp-layer-213 button, #ulp-layer-213 textarea {
    color: #000000;
    font-family: "arial",arial;
    font-weight: 400;
    text-shadow: 1px 1px 1px #ffffff;
}
.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}
#ulp-layer-213 input.ulp-input {
    padding-left: 32px !important;
}
#ulp-RWyl85W8ZegKXhFU .ulp-input, #ulp-RWyl85W8ZegKXhFU .ulp-input:hover, #ulp-RWyl85W8ZegKXhFU .ulp-input:active, #ulp-RWyl85W8ZegKXhFU .ulp-input:focus {
    background-color: rgba(255, 255, 255, 1) !important;
    border-color: #ffffff;
    border-radius: 2px !important;
    border-width: 1px !important;
}
#ulp-layer-213, #ulp-layer-213 p, #ulp-layer-213 a, #ulp-layer-213 span, #ulp-layer-213 li, #ulp-layer-213 input, #ulp-layer-213 button, #ulp-layer-213 textarea {
    color: #000000;
    font-family: "arial",arial;
    font-weight: 400;
    text-shadow: 1px 1px 1px #ffffff;
}
.ulp-input {
    background: none repeat scroll 0 0 rgba(255, 255, 255, 0.8);
    border-radius: 2px !important;
    border-spacing: 0 !important;
    border-style: solid !important;
    border-width: 1px !important;
    box-shadow: none !important;
    box-sizing: border-box !important;
    clear: both !important;
    font-size: inherit !important;
    height: 100% !important;
    line-height: 1.5 !important;
    margin: 0 !important;
    padding: 0 6px !important;
    vertical-align: middle !important;
    width: 100% !important;
}
input:-moz-read-write, textarea:-moz-read-write {
    -moz-user-modify: read-write !important;
}
input {
    -moz-appearance: textfield;
    -moz-binding: url("chrome://global/content/platformHTMLBindings.xml#inputFields");
    -moz-user-select: text;
    cursor: text;
    font: ;
    letter-spacing: normal;
    line-height: normal;
    padding: 1px;
    text-align: start;
    text-indent: 0;
    text-rendering: optimizelegibility;
    text-transform: none;
    word-spacing: normal;
}
textarea > .anonymous-div, input > .anonymous-div, input::-moz-placeholder, textarea::-moz-placeholder, *|*::-moz-button-content, *|*::-moz-display-comboboxcontrol-frame, optgroup:before {
    text-overflow: inherit;
    unicode-bidi: inherit;
}
input::-moz-placeholder, textarea::-moz-placeholder {
    display: inline-block !important;
    opacity: 0.54;
    overflow: hidden !important;
    pointer-events: none !important;
    resize: none !important;
}
textarea > .anonymous-div, input > .anonymous-div, input::-moz-placeholder, textarea::-moz-placeholder {
    -moz-control-character-visibility: visible;
    border: 0 none !important;
    display: inline-block;
    ime-mode: inherit;
    margin: 0;
    overflow: auto;
    padding: inherit !important;
    resize: inherit;
    text-decoration: inherit;
    white-space: pre;
}
input > .anonymous-div, input::-moz-placeholder {
    line-height: -moz-block-height;
    word-wrap: normal !important;
}

.ulp-fa-input-table {
    display: table;
    height: 100%;
    left: 0;
    line-height: 100%;
    position: absolute;
    top: 0;
    vertical-align: middle;
}
.ulp-fa-input-cell {
    display: table-cell;
    opacity: 0.7;
    text-align: center;
    vertical-align: middle;
}
.fa-user:before {
    content: "";
}
.fa {
    display: inline-block;
    font-family: FontAwesome;
    font-feature-settings: normal;
    font-kerning: auto;
    font-language-override: normal;
    font-size: inherit;
    font-size-adjust: none;
    font-stretch: normal;
    font-style: normal;
    font-synthesis: weight style;
    font-variant: normal;
    font-weight: normal;
    line-height: 1;
    text-rendering: auto;
}
#ulp-layer-214 {
    text-align: justify;
    z-index: 1000008;
}
#ulp-layer-214, #ulp-layer-214 p, #ulp-layer-214 a, #ulp-layer-214 span, #ulp-layer-214 li, #ulp-layer-214 input, #ulp-layer-214 button, #ulp-layer-214 textarea {
    color: #000000;
    font-family: "arial",arial;
    font-weight: 400;
    text-shadow: 1px 1px 1px #ffffff;
}
.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}
#ulp-layer-214 input.ulp-input {
    padding-left: 32px !important;
}
#ulp-RWyl85W8ZegKXhFU .ulp-input, #ulp-RWyl85W8ZegKXhFU .ulp-input:hover, #ulp-RWyl85W8ZegKXhFU .ulp-input:active, #ulp-RWyl85W8ZegKXhFU .ulp-input:focus {
    background-color: rgba(255, 255, 255, 1) !important;
    border-color: #ffffff;
    border-radius: 2px !important;
    border-width: 1px !important;
}
#ulp-layer-214, #ulp-layer-214 p, #ulp-layer-214 a, #ulp-layer-214 span, #ulp-layer-214 li, #ulp-layer-214 input, #ulp-layer-214 button, #ulp-layer-214 textarea {
    color: #000000;
    font-family: "arial",arial;
    font-weight: 400;
    text-shadow: 1px 1px 1px #ffffff;
}
.ulp-input {
    background: none repeat scroll 0 0 rgba(255, 255, 255, 0.8);
    border-radius: 2px !important;
    border-spacing: 0 !important;
    border-style: solid !important;
    border-width: 1px !important;
    box-shadow: none !important;
    box-sizing: border-box !important;
    clear: both !important;
    font-size: inherit !important;
    height: 100% !important;
    line-height: 1.5 !important;
    margin: 0 !important;
    padding: 0 6px !important;
    vertical-align: middle !important;
    width: 100% !important;
}
input:-moz-read-write, textarea:-moz-read-write {
    -moz-user-modify: read-write !important;
}
input {
    -moz-appearance: textfield;
    -moz-binding: url("chrome://global/content/platformHTMLBindings.xml#inputFields");
    -moz-user-select: text;
    cursor: text;
    font: ;
    letter-spacing: normal;
    line-height: normal;
    padding: 1px;
    text-align: start;
    text-indent: 0;
    text-rendering: optimizelegibility;
    text-transform: none;
    word-spacing: normal;
}
textarea > .anonymous-div, input > .anonymous-div, input::-moz-placeholder, textarea::-moz-placeholder, *|*::-moz-button-content, *|*::-moz-display-comboboxcontrol-frame, optgroup:before {
    text-overflow: inherit;
    unicode-bidi: inherit;
}
input::-moz-placeholder, textarea::-moz-placeholder {
    display: inline-block !important;
    opacity: 0.54;
    overflow: hidden !important;
    pointer-events: none !important;
    resize: none !important;
}
textarea > .anonymous-div, input > .anonymous-div, input::-moz-placeholder, textarea::-moz-placeholder {
    -moz-control-character-visibility: visible;
    border: 0 none !important;
    display: inline-block;
    ime-mode: inherit;
    margin: 0;
    overflow: auto;
    padding: inherit !important;
    resize: inherit;
    text-decoration: inherit;
    white-space: pre;
}
input > .anonymous-div, input::-moz-placeholder {
    line-height: -moz-block-height;
    word-wrap: normal !important;
}
element.style {
    font-size: 14px;
}

.ulp-fa-input-table {
    display: table;
    height: 100%;
    left: 0;
    line-height: 100%;
    position: absolute;
    top: 0;
    vertical-align: middle;
}

#ulp-layer-214 div.ulp-fa-input-cell {
    padding-left: 4px !important;
    width: 28px !important;
}
.ulp-fa-input-cell {
    display: table-cell;
    opacity: 0.7;
    text-align: center;
    vertical-align: middle;
}
.fa-envelope:before {
    content: "";
}
.fa {
    display: inline-block;
    font-family: FontAwesome;
    font-feature-settings: normal;
    font-kerning: auto;
    font-language-override: normal;
    font-size: inherit;
    font-size-adjust: none;
    font-stretch: normal;
    font-style: normal;
    font-synthesis: weight style;
    font-variant: normal;
    font-weight: normal;
    line-height: 1;
    text-rendering: auto;
}
#ulp-layer-215 {
    text-align: center;
    z-index: 1000009;
}
#ulp-layer-215, #ulp-layer-215 p, #ulp-layer-215 a, #ulp-layer-215 span, #ulp-layer-215 li, #ulp-layer-215 input, #ulp-layer-215 button, #ulp-layer-215 textarea {
    color: #ffffff;
    font-family: "arial",arial;
    font-weight: 400;
    text-shadow: 1px 1px 1px #000000;
}
.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}
#ulp-RWyl85W8ZegKXhFU .ulp-submit, #ulp-RWyl85W8ZegKXhFU .ulp-submit:visited {
    background: linear-gradient(#487826, #56912d) repeat scroll 0 0 #56912d;
    border: 1px solid #56912d;
    border-radius: 2px !important;
}
#ulp-layer-215, #ulp-layer-215 p, #ulp-layer-215 a, #ulp-layer-215 span, #ulp-layer-215 li, #ulp-layer-215 input, #ulp-layer-215 button, #ulp-layer-215 textarea {
    color: #ffffff;
    font-family: "arial",arial;
    font-weight: 400;
    text-shadow: 1px 1px 1px #000000;
}
.ulp-window a {
    text-decoration: none !important;
}
.ulp-submit, .ulp-submit:visited, .ulp-submit-button, .ulp-submit-button:visited {
    border-radius: 2px;
    box-shadow: none;
    cursor: pointer;
    display: inline-block;
    font-size: inherit !important;
    height: auto;
    line-height: 1.5;
    margin: 0;
    padding: 5px 20px;
    position: relative;
    text-decoration: none !important;
    transition-duration: 0.3s;
    white-space: nowrap;
    width: auto;
	background: linear-gradient(#487826, #56912d) repeat scroll 0 0 #56912d;
    border: 1px solid #56912d;
    border-radius: 2px !important;
}
a, a:active, a:hover {
    outline: medium none;
}
.fa-sign-out:before {
    content: "";
}
.fa {
    display: inline-block;
    font-family: FontAwesome;
    font-feature-settings: normal;
    font-kerning: auto;
    font-language-override: normal;
    font-size: inherit;
    font-size-adjust: none;
    font-stretch: normal;
    font-style: normal;
    font-synthesis: weight style;
    font-variant: normal;
    font-weight: normal;
    line-height: 1;
    text-rendering: auto;
}
#ulp-layer-215, #ulp-layer-215 p, #ulp-layer-215 a, #ulp-layer-215 span, #ulp-layer-215 li, #ulp-layer-215 input, #ulp-layer-215 button, #ulp-layer-215 textarea {
    color: #ffffff;
    text-shadow: 1px 1px 1px #000000;
}
.ulp-submit, .ulp-submit:visited, .ulp-submit-button, .ulp-submit-button:visited {
    cursor: pointer;
    font-size: inherit !important;
    white-space: nowrap;
}
#ulp-layer-216 {
    text-align: left;
    z-index: 1000007;
}
#ulp-layer-216, #ulp-layer-216 p, #ulp-layer-216 a, #ulp-layer-216 span, #ulp-layer-216 li, #ulp-layer-216 input, #ulp-layer-216 button, #ulp-layer-216 textarea {
    color: #ffffff;
    font-family: "arial",arial;
    font-weight: 400;
}
.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}
#ulp-layer-217 {
    text-align: right;
    z-index: 1000007;
}
#ulp-layer-217, #ulp-layer-217 p, #ulp-layer-217 a, #ulp-layer-217 span, #ulp-layer-217 li, #ulp-layer-217 input, #ulp-layer-217 button, #ulp-layer-217 textarea {
    color: #ffffff;
    font-family: "arial",arial;
    font-weight: 400;
    text-shadow: 1px 1px 1px #000000;
}
.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}
#ulp-layer-217, #ulp-layer-217 p, #ulp-layer-217 a, #ulp-layer-217 span, #ulp-layer-217 li, #ulp-layer-217 input, #ulp-layer-217 button, #ulp-layer-217 textarea {
    color: #ffffff;
    font-family: "arial",arial;
    font-weight: 400;
    text-shadow: 1px 1px 1px #000000;
}
.ulp-window a {
    text-decoration: none !important;
}
a, .contactForm input[type="text"]:focus, .contactForm input[type="email"]:focus, .contactForm textarea:focus, input#formSubmit, .errorForm, #subscribe input[type="email"]:focus, .errorSubs, .servSingle, #toTop i, #notForm input[type="email"]:focus, .contactForm input#submit, #loginForm input, #loginForm input[type="text"]:focus, #loginForm input[type="password"]:focus {
    transition: all 0.5s ease 0s;
}
a, a:active, a:hover {
    outline: medium none;
}
	
ul.ulp-sf3-popup {margin: 0 !important; padding: 0 !important; list-style: none !important;}
ul.ulp-sf3-popup li {padding: 0 !important; margin: 0 !important; text-indent: 0 !important; line-height: 1.8 !important;}
ul.ulp-sf3-popup li:before {content: "● " !important; color: #56912d; margin-right: 10px !important;}

table
{
	margin:20px;
	background:#f8f8f8;
	
}
table td
{
	padding:10px;
	border:1px solid #ccc;
}
table td label
{
	font-family:Arial, Helvetica, sans-serif;
	font-size:14px;
	font-weight:normal;
}
table td input[type='text']
{
	border:none;
	padding:10px;
	font-size:12px;
	font-weight:normal;
	border:1px solid #ccc;
	width:300px;
}
table td textarea
{
	width:300px;
	font-size:12px;
}
#updateform
{
	background:#019ad2;
	color:#fff;
	font-size:16px;
	padding:10px;
	border:1px solid #019ad2;
	width:100px;
}

</style>

 <?php 
$txthtml="<div id='popupform' style='position:relative;'><div class='ulp-content' style='width: 700px; height: 360px; margin: 10% auto auto;'>
							<div id='ulp-layer-205' class='ulp-layer animated bounceInLeft' style='width: 640px; height: 360px; font-size: 14px; left: 0px; top: 0px;'></div>
							<div id='ulp-layer-206' class='ulp-layer ' style='width: 640px; height: 360px; font-size: 14px; left: 0px; top: 0px;'></div>
							<div id='ulp-layer-207' class='ulp-layer animated fadeInLeftBig' style='width: 580px; font-size: 28px; left: 30px; top: 20px;'>Do you want more traffic?</div>
							<div id='ulp-layer-208' class='ulp-layer animated fadeInLeft' style='width: 350px; font-size: 14px; left: 30px; top: 60px;'>Dignissim enim porta aliquam nisi pellentesque. Pulvinar rhoncus
magnis turpis sit odio pid pulvinar mattis integer aliquam!</div>
							<div id='ulp-layer-209' class='ulp-layer animated fadeInLeft' style='width: 420px; font-size: 14px; left: 30px; top: 130px;'>
<ul class='ulp-sf3-popup'>
<li>Goblinus globalus fantumo tubus dia montes </li>
<li>Scelerisque cursus dignissim lopatico vutario</li>
<li>Montes vutario lacus quis preambul den lacus </li>
<li>Leftomato denitro oculus softam lorum quis </li>
<li>Spiratio dodenus christmas gulleria tix digit </li>
<li>Dualo fitemus lacus quis preambul pat turtulis</li>
<li>Scelerisque cursus dignissim lopatico vutario</li>
<li>Montes vutario lacus quis preambul den lacus </li>
</ul></div>
							<div id='ulp-layer-210' class='ulp-layer animated fadeInRightBig' style='width: 300px; height: 400px; font-size: 14px; left: 400px; top: -20px;'></div>
							<div id='ulp-layer-211' class='ulp-layer' style='width: 300px; height: 400px; font-size: 14px; left: 400px; top: -20px;'></div>
							<div id='ulp-layer-212' class='ulp-layer animated fadeInRight' style='width: 260px; font-size: 25px; left: 420px; top: 20px;'>SUBSCRIBE TO OUR NEWSLETTER AND START INCREASING YOUR PROFITS NOW!</div>
							<div id='ulp-layer-213' class='ulp-layer animated zoomInLeft' style='width: 260px; height: 36px; font-size: 14px; left: 420px; top: 205px;'><input type='text' onfocus='jQuery(this).removeClass('ulp-input-error');' value='' placeholder='Enter your name...' name='ulp-name' class='ulp-input'><div class='ulp-fa-input-table'><div class='ulp-fa-input-cell'><i class='fa fa-user'></i></div></div></div>
							<div id='ulp-layer-214' class='ulp-layer animated zoomInRight' style='width: 260px; height: 36px; font-size: 14px; left: 420px; top: 250px;'><input type='text' onfocus='jQuery(this).removeClass('ulp-input-error');' value='' placeholder='Enter your e-mail...' name='ulp-email' class='ulp-input'><div class='ulp-fa-input-table'><div class='ulp-fa-input-cell'><i class='fa fa-envelope'></i></div></div></div>
							<div id='ulp-layer-215' class='ulp-layer animated bounceInLeft' style='width: 300px; height: 38px; font-size: 15px; left: 400px; top: 300px;'><a data-loading='Loading...' data-label='SUBSCRIBE NOW' data-icon='fa-sign-out' onclick='return ulp_subscribe(this);' class='ulp-submit'><i class='fa fa-sign-out'></i>&nbsp; SUBSCRIBE NOW</a></div>
							<div id='ulp-layer-216' class='ulp-layer animated bounceIn' style='width: 280px; font-size: 12px; left: 420px; top: 350px;'>* we never share your e-mail with third parties.</div>
							<div id='ulp-layer-217' class='ulp-layer' style='width: 40px; height: 20px; font-size: 24px; left: 655px; top: -25px;'><a onclick='return ulp_self_close();' href='#'>x</a></div>
						</div></div>";
echo $txthtml;
			?>	
	<div style="margin-top:40px;">		
			
			<table width="97%" border="0">

 <tr>
    
    <td><label>Popup1 Background Color :</label></td>
    <td><input class="color boxcolor" value="66ff00" id="popbgcolor" onchange="popup_bg();"></td>
    <td><label>Popup2 Background Color :</label></td>
    <td><input class="color boxcolor" value="66ff00" id="bkgcolor" onchange="footer_bg();"></td>
    <td></td>
    <td></td>
    
  </tr>

   
   <tr>
    <td><label>Layer one Color :</label></td>
    <td><input class="color boxcolor" value="66ff00" id="layer1_color" onchange="layer1_color();"></td>
    <td><label>Layer One Text :</label></td>
    <td><input type="text" value="" id="layer1_txt" onkeypress="layer1_txt();" maxlength="30" /></td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
   
   <tr>
    <td><label>Layer Two Color :</label></td>
    <td><input class="color boxcolor" value="66ff00" id="layer2_color" onchange="layer2_color();"></td>
    <td><label>Layer Two Text :</label></td>
    <td><textarea type="text" value="" id="layer2_txt" onkeypress="layer2_txt();"></textarea></td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  
    <tr>
    <td><label>Layer Three Color :</label></td>
    <td><input class="color boxcolor" value="66ff00" id="layer3_color" onchange="layer3_color();"></td>
    <td><label>Layer Three Text :</label></td>
    <td><textarea type="text" value="" id="layer3_txt" onkeypress="layer3_txt();"></textarea></td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    </tr>
     <tr>
    <td><label>Heading Color :</label></td>
    <td><input class="color boxcolor" value="66ff00" id="layer4_color" onchange="layer5_color();"></td>
    <td><label>Heading Text :</label></td>
    <td><textarea type="text" value="" onkeypress="layer5_txt();" id="layer5_txt"></textarea></td>
    
  </tr>
  
   <tr>
    <td><label>Placeholder one text :</label></td>
    <td><input type="text" value="" id="placeholder1_txt" onkeypress="placeholder1_txt();"  /></td>
     <td><label>Placeholder two text :</label></td>
    <td><input type="text" value="" id="placeholder2_txt" onkeypress="placeholder2_txt();"  /></td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
    
    
    <tr>
    <td><label>Subscribe Now Color:</label></td>
    <td><input class="color boxcolor" value="66ff00" id="button1_color" onchange="button1_color();"></td>
    <td><label>Subscribe Now Background Color :</label></td>
    <td><input class="color boxcolor" value="66ff00" id="button1_bkgcolor" onchange="button1_bkgcolor();"></td>
    <td><label>Subscribe Now Text :</label></td>
    <td><input type="text" value="" id="button1_txt" maxlength="25" onkeypress="button1_txt();"  /></td>
  
  </tr>
  
   <tr>
    <td><label>Layer Four Color :</label></td>
    <td><input class="color boxcolor" value="66ff00" id="layer4_color" onchange="layer4_color();"></td>
    <td><label>Layer Four Text :</label></td>
    <td><textarea type="text" value="" onkeypress="layer4_txt();" id="layer4_txt"></textarea></td>
    
  </tr>
  
  
  
  </table>

</div>              


<script type="text/javascript">
function pop_layer_data()
{
	var layer1_txt=$("#ulp-layer-207").html();
	var layer2_txt=$("#ulp-layer-208").html();
	var layer3_txt=$("#ulp-layer-209 .ulp-sf3-popup").html();
	var placeholder1_txt=$("#ulp-layer-213 .ulp-input").attr('placeholder');
	var placeholder2_txt=$("#ulp-layer-214 .ulp-input").attr('placeholder');
	
	var button1_txt=$("#ulp-layer-215 .ulp-submit").html();
	var layer4_txt=$("#ulp-layer-216").html();
	var layer5_txt=$("#ulp-layer-212").html();

	$("#layer1_txt").val(layer1_txt);
	$("#layer2_txt").val(layer2_txt);
	$("#layer3_txt").val(layer3_txt);
	$("#placeholder1_txt").val(placeholder1_txt);
	$("#placeholder2_txt").val(placeholder2_txt);
    $("#button1_txt").val(button1_txt);
	$("#layer4_txt").val(layer4_txt);
	$("#layer5_txt").val(layer5_txt);
}




						function popup_bg()
						{
						    var popbgcolor="#"+$("#popbgcolor").val();
							//alert(bgcolor);
							$("#ulp-layer-206").css("background-color",popbgcolor);
						}
						function footer_bg()
						{
							var bkgcolor="#"+$("#bkgcolor").val();
								//alert(bgcolor);
							$("#ulp-layer-211").css("background-color",bkgcolor);
					    }

						
						function layer1_color()
						{
							var fcolor="#"+$("#layer1_color").val();
							//alert(bgcolor);
							$("#ulp-layer-207").css("color",fcolor);
						}
						function layer1_txt()
						{
							var layer1_txt=$("#layer1_txt").val();
							//alert(bgcolor);
							$("#ulp-layer-207").html(layer1_txt);
						}
						function layer2_color()
						{
							var fcolor="#"+$("#layer2_color").val();
							//alert(bgcolor);
							$("#ulp-layer-208").css("color",fcolor);
						}
						function layer2_txt()
						{
							var layer2_txt=$("#layer2_txt").val();
							//alert(bgcolor);
							$("#ulp-layer-208").html(layer2_txt);
						}
						
						
						function layer3_color()
						{
							var fcolor="#"+$("#layer3_color").val();
						   // alert(fcolor);
							$("#ulp-layer-209 .ulp-sf3-popup").css("background",fcolor);
						}
						function layer3_txt()
						{
							var layer3_txt=$("#layer3_txt").val();
							//alert(bgcolor);
							$("#ulp-layer-209 .ulp-sf3-popup").html(layer3_txt);
						}
						
						
						function placeholder1_txt()
						{
							var placeholder1_txt=$("#placeholder1_txt").val();
							//alert(bgcolor);
							$("#ulp-layer-213 .ulp-input").attr('placeholder',placeholder1_txt);
						}
						function placeholder2_txt()
						{
							var placeholder2_txt=$("#placeholder2_txt").val();
							//alert(bgcolor);
							$("#ulp-layer-214 .ulp-input").attr('placeholder',placeholder2_txt);
						}
						
					  						
						
						function button1_color()
						{
							var fcolor="#"+$("#button1_color").val();
							//alert(bgcolor);
							$("#ulp-layer-215 .ulp-submit").css("color",fcolor);
						}
						function button1_bkgcolor()
						{
							var button1_bkgcolor="#"+$("#button1_bkgcolor").val();
							//alert(button1_bkgcolor);
							$("#ulp-layer-215 .ulp-submit").css('background',button1_bkgcolor);
						}
						function button1_txt()
						{
							var button1_txt=$("#button1_txt").val();
							//alert(bgcolor);
							$("#ulp-layer-215 .ulp-submit").html(button1_txt);
						}
						function layer4_color()
						{
							var fcolor="#"+$("#layer4_color").val();
							//alert(bgcolor);
							$("#ulp-layer-216").css("color",fcolor);
						}
						function layer4_txt()
						{
							var layer4_txt=$("#layer4_txt").val();
							//alert(bgcolor);
							$("#ulp-layer-216").html(layer4_txt);
						}
						function layer5_color()
						{
							var fcolor="#"+$("#layer5_color").val();
							//alert(bgcolor);
							$("#ulp-layer-212").css("color",fcolor);
						}
						function layer5_txt()
						{
							var layer5_txt=$("#layer5_txt").val();
							//alert(bgcolor);
							$("#ulp-layer-212").html(layer5_txt);
						}
					
						</script>
					
						