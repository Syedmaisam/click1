<link rel="stylesheet" href="<?php echo SITE_ROOT_URL; ?>views/layered/animatemaster/animate.min.css">
<script type="text/javascript" src="<?php echo SITE_ROOT_URL; ?>colorjs/jscolor.js"></script>
<style>
body
{
margin:0px;
padding:0px;
}
.ulp-content {
    position: relative;
}
#ulp-layer-229 {
    background-color: rgba(255, 255, 255, 0.9);
    box-shadow: 0 4px 30px rgba(32, 32, 32, 1);
    text-align: left;
    z-index: 1000002;
}
#ulp-layer-229, #ulp-layer-229 p, #ulp-layer-229 a, #ulp-layer-229 span, #ulp-layer-229 li, #ulp-layer-229 input, #ulp-layer-229 button, #ulp-layer-229 textarea {
    color: #000000;
    font-family: "arial",arial;
    font-weight: 400;
}
.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}
.ulp-layer img {
    border: medium none !important;
    box-shadow: none !important;
    margin: 0 !important;
    max-width: 100% !important;
    min-width: 0 !important;
    padding: 0 !important;
}
img {
    max-width: 100%;
}
#ulp-layer-230 {
    background-color: rgba(0, 0, 0, 0.7);
    text-align: left;
    z-index: 1000006;
}
#ulp-layer-230, #ulp-layer-230 p, #ulp-layer-230 a, #ulp-layer-230 span, #ulp-layer-230 li, #ulp-layer-230 input, #ulp-layer-230 button, #ulp-layer-230 textarea {
    color: #000000;
    font-family: "arial",arial;
    font-weight: 400;
}
.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}
#ulp-layer-231 {
    text-align: center;
    z-index: 1000007;
}
#ulp-layer-231, #ulp-layer-231 p, #ulp-layer-231 a, #ulp-layer-231 span, #ulp-layer-231 li, #ulp-layer-231 input, #ulp-layer-231 button, #ulp-layer-231 textarea {
    color: #ffffff;
    font-family: "arial",arial;
    font-weight: 700;
}
.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}
#ulp-layer-232 {
    background-color: rgba(255, 216, 4, 0.9);
    text-align: left;
    z-index: 1000008;
}
#ulp-layer-232, #ulp-layer-232 p, #ulp-layer-232 a, #ulp-layer-232 span, #ulp-layer-232 li, #ulp-layer-232 input, #ulp-layer-232 button, #ulp-layer-232 textarea {
    color: #000000;
    font-family: "arial",arial;
    font-weight: 400;
}
.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}
#ulp-layer-233 {
    text-align: center;
    z-index: 1000007;
}
#ulp-layer-233, #ulp-layer-233 p, #ulp-layer-233 a, #ulp-layer-233 span, #ulp-layer-233 li, #ulp-layer-233 input, #ulp-layer-233 button, #ulp-layer-233 textarea {
    color: #ffffff;
    font-family: "arial",arial;
    font-weight: 400;
}
.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}
#ulp-layer-234 {
    background-color: rgba(255, 216, 4, 0.9);
    text-align: left;
    z-index: 1000006;
}
#ulp-layer-234, #ulp-layer-234 p, #ulp-layer-234 a, #ulp-layer-234 span, #ulp-layer-234 li, #ulp-layer-234 input, #ulp-layer-234 button, #ulp-layer-234 textarea {
    color: #000000;
    font-family: "arial",arial;
    font-weight: 400;
}
.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}
#ulp-layer-235 {
    text-align: left;
    z-index: 1000009;
}
#ulp-layer-235, #ulp-layer-235 p, #ulp-layer-235 a, #ulp-layer-235 span, #ulp-layer-235 li, #ulp-layer-235 input, #ulp-layer-235 button, #ulp-layer-235 textarea {
    color: #000000;
    font-family: "arial",arial;
    font-weight: 400;
}
.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}
#ulp-layer-235 input.ulp-input {
    padding-left: 34px !important;
}
#ulp-GUuNYrVYFbJCsowv .ulp-input, #ulp-GUuNYrVYFbJCsowv .ulp-input:hover, #ulp-GUuNYrVYFbJCsowv .ulp-input:active, #ulp-GUuNYrVYFbJCsowv .ulp-input:focus {
    background-color: rgba(255, 255, 255, 1) !important;
    border-color: #ffffff;
    border-radius: 30px !important;
    border-width: 1px !important;
}
#ulp-layer-235, #ulp-layer-235 p, #ulp-layer-235 a, #ulp-layer-235 span, #ulp-layer-235 li, #ulp-layer-235 input, #ulp-layer-235 button, #ulp-layer-235 textarea {
    color: #000000;
    font-family: "arial",arial;
    font-weight: 400;
}
.ulp-input {
    background: none repeat scroll 0 0 rgba(255, 255, 255, 0.8);
    border-radius: 2px !important;
    border-spacing: 0 !important;
    border-style: solid !important;
    border-width: 1px !important;
    box-shadow: none !important;
    box-sizing: border-box !important;
    clear: both !important;
    font-size: inherit !important;
    height: 100% !important;
    line-height: 1.5 !important;
    margin: 0 !important;
    padding: 0 6px !important;
    vertical-align: middle !important;
    width: 100% !important;
}
input:-moz-read-write, textarea:-moz-read-write {
    -moz-user-modify: read-write !important;
}
input {
    -moz-appearance: textfield;
    -moz-binding: url("chrome://global/content/platformHTMLBindings.xml#inputFields");
    -moz-user-select: text;
    cursor: text;
    font: ;
    letter-spacing: normal;
    line-height: normal;
    padding: 1px;
    text-align: start;
    text-indent: 0;
    text-rendering: optimizelegibility;
    text-shadow: none;
    text-transform: none;
    word-spacing: normal;
}
textarea > .anonymous-div, input > .anonymous-div, input::-moz-placeholder, textarea::-moz-placeholder, *|*::-moz-button-content, *|*::-moz-display-comboboxcontrol-frame, optgroup:before {
    text-overflow: inherit;
    unicode-bidi: inherit;
}
input::-moz-placeholder, textarea::-moz-placeholder {
    display: inline-block !important;
    opacity: 0.54;
    overflow: hidden !important;
    pointer-events: none !important;
    resize: none !important;
}
textarea > .anonymous-div, input > .anonymous-div, input::-moz-placeholder, textarea::-moz-placeholder {
    -moz-control-character-visibility: visible;
    border: 0 none !important;
    display: inline-block;
    ime-mode: inherit;
    margin: 0;
    overflow: auto;
    padding: inherit !important;
    resize: inherit;
    text-decoration: inherit;
    white-space: pre;
}
input > .anonymous-div, input::-moz-placeholder {
    line-height: -moz-block-height;
    word-wrap: normal !important;
}
.ulp-fa-input-table {
    display: table;
    height: 100%;
    left: 0;
    line-height: 100%;
    position: absolute;
    top: 0;
    vertical-align: middle;
}

#ulp-layer-235 div.ulp-fa-input-cell {
    padding-left: 4px !important;
    width: 30px !important;
}
.ulp-fa-input-cell {
    display: table-cell;
    opacity: 0.7;
    text-align: center;
    vertical-align: middle;
}

.fa-user:before {
    content: "";
}
.fa {
    display: inline-block;
    font-family: FontAwesome;
    font-feature-settings: normal;
    font-kerning: auto;
    font-language-override: normal;
    font-size: inherit;
    font-size-adjust: none;
    font-stretch: normal;
    font-style: normal;
    font-synthesis: weight style;
    font-variant: normal;
    font-weight: normal;
    line-height: 1;
    text-rendering: auto;
}
.ulp-fa-input-cell {
    text-align: center;
}
#ulp-layer-236 {
    text-align: left;
    z-index: 1000009;
}
#ulp-layer-236, #ulp-layer-236 p, #ulp-layer-236 a, #ulp-layer-236 span, #ulp-layer-236 li, #ulp-layer-236 input, #ulp-layer-236 button, #ulp-layer-236 textarea {
    color: #000000;
    font-family: "arial",arial;
    font-weight: 400;
}
.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}
#ulp-layer-236 input.ulp-input {
    padding-left: 34px !important;
}
#ulp-GUuNYrVYFbJCsowv .ulp-input, #ulp-GUuNYrVYFbJCsowv .ulp-input:hover, #ulp-GUuNYrVYFbJCsowv .ulp-input:active, #ulp-GUuNYrVYFbJCsowv .ulp-input:focus {
    background-color: rgba(255, 255, 255, 1) !important;
    border-color: #ffffff;
    border-radius: 30px !important;
    border-width: 1px !important;
}
#ulp-layer-236, #ulp-layer-236 p, #ulp-layer-236 a, #ulp-layer-236 span, #ulp-layer-236 li, #ulp-layer-236 input, #ulp-layer-236 button, #ulp-layer-236 textarea {
    color: #000000;
    font-family: "arial",arial;
    font-weight: 400;
}
.ulp-input {
    background: none repeat scroll 0 0 rgba(255, 255, 255, 0.8);
    border-radius: 2px !important;
    border-spacing: 0 !important;
    border-style: solid !important;
    border-width: 1px !important;
    box-shadow: none !important;
    box-sizing: border-box !important;
    clear: both !important;
    font-size: inherit !important;
    height: 100% !important;
    line-height: 1.5 !important;
    margin: 0 !important;
    padding: 0 6px !important;
    vertical-align: middle !important;
    width: 100% !important;
}
input:-moz-read-write, textarea:-moz-read-write {
    -moz-user-modify: read-write !important;
}
input {
    -moz-appearance: textfield;
    -moz-binding: url("chrome://global/content/platformHTMLBindings.xml#inputFields");
    -moz-user-select: text;
    cursor: text;
    font: ;
    letter-spacing: normal;
    line-height: normal;
    padding: 1px;
    text-align: start;
    text-indent: 0;
    text-rendering: optimizelegibility;
    text-shadow: none;
    text-transform: none;
    word-spacing: normal;
}
textarea > .anonymous-div, input > .anonymous-div, input::-moz-placeholder, textarea::-moz-placeholder, *|*::-moz-button-content, *|*::-moz-display-comboboxcontrol-frame, optgroup:before {
    text-overflow: inherit;
    unicode-bidi: inherit;
}
input::-moz-placeholder, textarea::-moz-placeholder {
    display: inline-block !important;
    opacity: 0.54;
    overflow: hidden !important;
    pointer-events: none !important;
    resize: none !important;
}
textarea > .anonymous-div, input > .anonymous-div, input::-moz-placeholder, textarea::-moz-placeholder {
    -moz-control-character-visibility: visible;
    border: 0 none !important;
    display: inline-block;
    ime-mode: inherit;
    margin: 0;
    overflow: auto;
    padding: inherit !important;
    resize: inherit;
    text-decoration: inherit;
    white-space: pre;
}
input > .anonymous-div, input::-moz-placeholder {
    line-height: -moz-block-height;
    word-wrap: normal !important;
}

.ulp-fa-input-table {
    display: table;
    height: 100%;
    left: 0;
    line-height: 100%;
    position: absolute;
    top: 0;
    vertical-align: middle;
}

#ulp-layer-236 div.ulp-fa-input-cell {
    padding-left: 4px !important;
    width: 30px !important;
}
.ulp-fa-input-cell {
    display: table-cell;
    opacity: 0.7;
    text-align: center;
    vertical-align: middle;
}
.fa-envelope:before {
    content: "";
}
.fa {
    display: inline-block;
    font-family: FontAwesome;
    font-feature-settings: normal;
    font-kerning: auto;
    font-language-override: normal;
    font-size: inherit;
    font-size-adjust: none;
    font-stretch: normal;
    font-style: normal;
    font-synthesis: weight style;
    font-variant: normal;
    font-weight: normal;
    line-height: 1;
    text-rendering: auto;
}
#ulp-layer-237 {
    text-align: center;
    z-index: 1000009;
}
#ulp-layer-237, #ulp-layer-237 p, #ulp-layer-237 a, #ulp-layer-237 span, #ulp-layer-237 li, #ulp-layer-237 input, #ulp-layer-237 button, #ulp-layer-237 textarea {
    color: #ffffff;
    font-family: "arial",arial;
    font-weight: 400;
}
.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}
#ulp-GUuNYrVYFbJCsowv .ulp-submit, #ulp-GUuNYrVYFbJCsowv .ulp-submit:visited {
    background: none repeat scroll 0 0 #111111;
    border: 1px solid #111111;
    border-radius: 30px !important;
}
#ulp-layer-237, #ulp-layer-237 p, #ulp-layer-237 a, #ulp-layer-237 span, #ulp-layer-237 li, #ulp-layer-237 input, #ulp-layer-237 button, #ulp-layer-237 textarea {
    color: #ffffff;
    font-family: "arial",arial;
    font-weight: 400;
}
.ulp-window a {
    text-decoration: none !important;
}
.ulp-submit, .ulp-submit:visited, .ulp-submit-button, .ulp-submit-button:visited {
    border-radius: 2px;
    box-shadow: none;
    cursor: pointer;
    display: inline-block;
    font-size: inherit !important;
    height: auto;
    line-height: 1.5;
    margin: 0;
    padding: 5px 20px;
    position: relative;
    text-decoration: none !important;
    text-shadow: 0 -1px 1px rgba(0, 0, 0, 0.25);
    transition-duration: 0.3s;
    white-space: nowrap;
    width: auto;
}
a, a:active, a:hover {
    outline: medium none;
}
.fa-check-square-o:before {
    content: "";
}
.fa {
    display: inline-block;
    font-family: FontAwesome;
    font-feature-settings: normal;
    font-kerning: auto;
    font-language-override: normal;
    font-size: inherit;
    font-size-adjust: none;
    font-stretch: normal;
    font-style: normal;
    font-synthesis: weight style;
    font-variant: normal;
    font-weight: normal;
    line-height: 1;
    text-rendering: auto;
}
#ulp-layer-237, #ulp-layer-237 p, #ulp-layer-237 a, #ulp-layer-237 span, #ulp-layer-237 li, #ulp-layer-237 input, #ulp-layer-237 button, #ulp-layer-237 textarea {
    color: #ffffff;
}
.ulp-submit, .ulp-submit:visited, .ulp-submit-button, .ulp-submit-button:visited {
    cursor: pointer;
    font-size: inherit !important;
    text-shadow: 0 -1px 1px rgba(0, 0, 0, 0.25);
    white-space: nowrap;
}
#ulp-layer-238 {
    text-align: center;
    z-index: 1000007;
}
#ulp-layer-238, #ulp-layer-238 p, #ulp-layer-238 a, #ulp-layer-238 span, #ulp-layer-238 li, #ulp-layer-238 input, #ulp-layer-238 button, #ulp-layer-238 textarea {
    color: #ffffff;
    font-family: "arial",arial;
    font-weight: 400;
}
.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}
.fa-lock:before {
    content: "";
}
.fa {
    display: inline-block;
    font-family: FontAwesome;
    font-feature-settings: normal;
    font-kerning: auto;
    font-language-override: normal;
    font-size: inherit;
    font-size-adjust: none;
    font-stretch: normal;
    font-style: normal;
    font-synthesis: weight style;
    font-variant: normal;
    font-weight: normal;
    line-height: 1;
    text-rendering: auto;
}
#ulp-layer-238 {
    text-align: center;
}
#ulp-layer-239 {
    background-color: rgba(255, 216, 4, 0.9);
    border-radius: 16px;
    line-height: 32px;
    text-align: center;
    z-index: 1000009;
}
#ulp-layer-239, #ulp-layer-239 p, #ulp-layer-239 a, #ulp-layer-239 span, #ulp-layer-239 li, #ulp-layer-239 input, #ulp-layer-239 button, #ulp-layer-239 textarea {
    color: #ffffff;
    font-family: "arial",arial;
    font-weight: 400;
}
.ulp-layer {
    box-sizing: border-box;
    position: absolute;
}
#ulp-layer-239, #ulp-layer-239 p, #ulp-layer-239 a, #ulp-layer-239 span, #ulp-layer-239 li, #ulp-layer-239 input, #ulp-layer-239 button, #ulp-layer-239 textarea {
    color: #ffffff;
    font-family: "arial",arial;
    font-weight: 400;
}
.ulp-window a {
    text-decoration: none !important;
}
a, .contactForm input[type="text"]:focus, .contactForm input[type="email"]:focus, .contactForm textarea:focus, input#formSubmit, .errorForm, #subscribe input[type="email"]:focus, .errorSubs, .servSingle, #toTop i, #notForm input[type="email"]:focus, .contactForm input#submit, #loginForm input, #loginForm input[type="text"]:focus, #loginForm input[type="password"]:focus {
    transition: all 0.5s ease 0s;
}
a, a:active, a:hover {
    outline: medium none;
}

table
{
	margin:20px;
	background:#f8f8f8;
	
}
table td
{
	padding:10px;
	border:1px solid #ccc;
}
table td label
{
	font-family:Arial, Helvetica, sans-serif;
	font-size:14px;
	font-weight:normal;
}
table td input[type='text']
{
	border:none;
	padding:10px;
	font-size:12px;
	font-weight:normal;
	border:1px solid #ccc;
	width:300px;
}
table td textarea
{
	width:300px;
	font-size:12px;
}
#updateform
{
	background:#019ad2;
	color:#fff;
	font-size:16px;
	padding:10px;
	border:1px solid #019ad2;
	width:100px;
}
</style>
<?php 
 
$txthtml="<div id='popupform' style='position:relative;'><div class='ulp-content' style='width: 550px; height: 410px;  margin: 10% auto auto;'>
							<div id='ulp-layer-229' class='ulp-layer' style='width: 550px; height: 410px; font-size: 14px; left: 0px; top: 0px;'><img alt='' src='http://www.cliks.it/click/images/city.jpg' style='width:100%; height:100%;'></div>
							<div id='ulp-layer-230' class='ulp-layer' style='width: 550px; height: 410px; font-size: 14px; left: 0px; top: 0px;'></div>
							<div id='ulp-layer-231' class='ulp-layer animated bounceIn' style='width: 550px; font-size: 24px; left: 0px; top: 20px;'>ARE YOU READY? GET IT NOW!</div>
							<div id='ulp-layer-232' class='ulp-layer animated bounceIn' style='width: 300px; height: 5px; font-size: 14px; left: 125px; top: 70px;'></div>
							<div id='ulp-layer-233' class='ulp-layer animated bounceInDown' style='width: 550px; font-size: 16px; left: 0px; top: 90px;'>Increase more than 500% of Email Subscribers!</div>
							<div id='ulp-layer-234' class='ulp-layer' style='width: 550px; height: 200px; font-size: 14px; left: 0px; top: 170px;'></div>
							<div id='ulp-layer-235' class='ulp-layer animated fadeInLeftBig' style='width: 480px; height: 42px; font-size: 15px; left: 35px; top: 195px;'><input type='text' onfocus='jQuery(this).removeClass('ulp-input-error');' value='' placeholder='Enter your name...' name='ulp-name' class='ulp-input'><div class='ulp-fa-input-table'><div class='ulp-fa-input-cell'><i class='fa fa-user'></i></div></div></div>
							<div id='ulp-layer-236' class='ulp-layer animated fadeInLeftBig' style='width: 480px; height: 42px; font-size: 15px; left: 35px; top: 255px;'><input type='text' onfocus='jQuery(this).removeClass('ulp-input-error');' value='' placeholder='Enter your e-mail...' name='ulp-email' class='ulp-input'><div class='ulp-fa-input-table'><div class='ulp-fa-input-cell'><i class='fa fa-envelope'></i></div></div></div>
							<div id='ulp-layer-237' class='ulp-layer animated fadeInUp' style='width: 400px; height: 48px; font-size: 17px; left: 75px; top: 315px;'><a data-loading='PLEASE WAIT!' data-label='SUBSCRIBE NOW!' data-icon='fa-check-square-o' onclick='return ulp_subscribe(this);' class='ulp-submit'><i class='fa fa-check-square-o'></i>&nbsp; <span id='spnid'>SUBSCRIBE NOW!</span></a></div>
							<div id='ulp-layer-238' class='ulp-layer animated fadeInUpBig' style='width: 550px; font-size: 13px; left: 0px; top: 380px;'><i class='fa fa-lock'></i> <span id='info'>Your Information will never be shared with any third party.</span></div>
							<div id='ulp-layer-239' class='ulp-layer animated fadeInUpBig' style='width: 32px; height: 32px; font-size: 32px; left: 513px; top: 5px;'><a onclick='return ulp_self_close();' href='#'>x</a></div>
						</div></div>";
echo $txthtml;
						?>
						
						
<div style="margin-top:30px;">						
<table width="97%" border="0">
   
    <td><label>Layer one Color :</label></td>
    <td><input class="color boxcolor" value="66ff00" id="layer1_color" onchange="layer1_color();"></td>
    <td><label>Layer One Text :</label></td>
    <td><input type="text" value="" id="layer1_txt" onkeypress="layer1_txt();" maxlength="30" /></td>
   
  </tr>
   <tr>
    <td><label>Layer Color :</label></td>
    <td><input class="color boxcolor" value="66ff00" id="layer3_color" onchange="layer3_color();"></td>
    <td><label>Layer Two Color :</label></td>
    <td><input class="color boxcolor" value="66ff00" id="layer2_color" onchange="layer2_color();"></td>

  </tr>
  
   <tr>
    
    <td><label>Layer Two Text :</label></td>
    <td><textarea type="text" value="" id="layer2_txt" onkeypress="layer2_txt();"></textarea></td>
     <td><label>Placeholder one text :</label></td>
    <td><input type="text" value="" id="placeholder1_txt" onkeypress="placeholder1_txt();"  /></td>
  
  
  </tr>
  
   <tr>
   
    <td><label>Placeholder Two text :</label></td>
    <td><input type="text" value="" id="placeholder2_txt" onkeypress="placeholder2_txt();"  /></td>
     <td><label>Subscribe Now Color:</label></td>
    <td><input class="color boxcolor" value="66ff00" id="button1_color" onchange="button1_color();"></td>
 
  </tr>
    
    
    <tr>
   
    <td><label>Subscribe Now Background Color :</label></td>
    <td><input class="color boxcolor" value="66ff00" id="button1_bkgcolor" onchange="button1_bkgcolor();"></td>
    <td><label>Subscribe Now Text :</label></td>
    <td><input type="text" value="" id="button1_txt" maxlength="25" onkeypress="button1_txt();"  /></td>
  
  </tr>
  
   <tr>
    <td><label>Layer Four Color :</label></td>
    <td><input class="color boxcolor" value="66ff00" id="layer4_color" onchange="layer4_color();"></td>
    <td><label>Layer Four Text :</label></td>
    <td><input type="text" value="" onkeypress="layer4_txt();" id="layer4_txt" /></td>
    
  </tr>
  
   <tr>
   <td><label>Background Image URL :</label></td>
    <td><input type="text" value="" id="chnagemacurl" onblur="macimgchange(this.value);"  /></td>
   <td><label>Popup Background Color :</label></td>
    <td><input class="color boxcolor" value="66ff00" id="popbgcolor" onchange="popup_bg();"></td>
    
  </tr>
  <tr>
  <td>Close Button Background</td>
    <td><input class="color boxcolor" value="66ff00" id="buttonclose_bkgcolor" onchange="buttonclose_bkgcolor();"></td>
  </tr>
  
</table>
</div>              


<script type="text/javascript">
function pop_layer_data()
{
	 var layer1_txt=$("#ulp-layer-231").html();
	 var layer2_txt=$("#ulp-layer-233").html();
	 var placeholder1_txt=$("#ulp-layer-235 .ulp-input").attr('placeholder');
   	var placeholder2_txt=$("#ulp-layer-236 .ulp-input").attr('placeholder');
	
	var button1_txt=$("#ulp-layer-237 .ulp-submit").text();
	var layer4_txt=$("#ulp-layer-238").text();

	$("#layer1_txt").val(layer1_txt);
	$("#layer2_txt").val(layer2_txt);
	$("#placeholder1_txt").val(placeholder1_txt);
	$("#placeholder2_txt").val(placeholder2_txt);
	$("#button1_txt").val(button1_txt);
	$("#layer4_txt").val(layer4_txt);
	 var imgurl=$("#ulp-layer-229 img").attr("src");
    $("#chnagemacurl").val(imgurl);
}
						function popup_bg()
						{
						    var popbgcolor="#"+$("#popbgcolor").val();
							//alert(bgcolor);
							$("#ulp-layer-234").css("background-color",popbgcolor);
						}
						
						function layer1_color()
						{
							var fcolor="#"+$("#layer1_color").val();
							//alert(bgcolor);
							$("#ulp-layer-231").css("color",fcolor);
						}
						function layer1_txt()
						{
							var layer1_txt=$("#layer1_txt").val();
							//alert(bgcolor);
							$("#ulp-layer-231").html(layer1_txt);
						}
						function layer2_color()
						{
							var fcolor="#"+$("#layer2_color").val();
							//alert(bgcolor);
							$("#ulp-layer-233").css("color",fcolor);
						}
						function layer2_txt()
						{
							var layer2_txt=$("#layer2_txt").val();
							//alert(bgcolor);
							$("#ulp-layer-233").html(layer2_txt);
						}
						
						
						function layer3_color()
						{
							var fcolor="#"+$("#layer3_color").val();
						    //alert(fcolor);
							$("#ulp-layer-232").css("background",fcolor);
						}
						
						function placeholder1_txt()
						{
							var placeholder1_txt=$("#placeholder1_txt").val();
							//alert(bgcolor);
							$("#ulp-layer-235 .ulp-input").attr('placeholder',placeholder1_txt);
						}
						
					    function placeholder2_txt()
						{
							var placeholder2_txt=$("#placeholder2_txt").val();
							//alert(bgcolor);
							$("#ulp-layer-236 .ulp-input").attr('placeholder',placeholder2_txt);
						}
						
						
						function button1_color()
						{
							var fcolor="#"+$("#button1_color").val();
							//alert(bgcolor);
							$("#ulp-layer-237 .ulp-submit").css("color",fcolor);
                                                        $("#spnid").css("color",fcolor);
						}
						function button1_bkgcolor()
						{
							var button1_bkgcolor="#"+$("#button1_bkgcolor").val();
							//alert(button1_bkgcolor);
							$("#ulp-layer-237 .ulp-submit").css('background',button1_bkgcolor);
						}
						function button1_txt()
						{
							var button1_txt=$("#button1_txt").val();
							//alert(bgcolor);
							$("#ulp-layer-237 .ulp-submit span").text(button1_txt);
						}
						function layer4_color()
						{
							var fcolor="#"+$("#layer4_color").val();
							//alert(bgcolor);
							$("#ulp-layer-238").css("color",fcolor);
                                                        $("#info").css("color",fcolor);
						}
						function layer4_txt()
						{
							var layer4_txt=$("#layer4_txt").val();
							//alert(bgcolor);
							$("#ulp-layer-238 span").html(layer4_txt);
						}
						function buttonclose_bkgcolor()
						{
							var bkgcolor="#"+$("#buttonclose_bkgcolor").val();
							//alert(bgcolor);
							$("#ulp-layer-239").css("background-color",bkgcolor);
						}
						
						
							function macimgchange(urldata)
						{
							var imgurl=$("#ulp-layer-229 img").attr("src");
									
							$("#ulp-layer-229 img").attr("src",urldata);
						}
					
						function updateform()
						{
							var popupform= $("#popupform").html();
							
							$.ajax({
							type: "post",
							url: 'animatemaster/updatepop1.php',
							data: {
							popupform: popupform,
							},			
							success: function(response) {
								//alert(response);
							},
							error:function 
							(XMLHttpRequest, textStatus, errorThrown) {
							}
							});  
							
						}
						</script>
						
						