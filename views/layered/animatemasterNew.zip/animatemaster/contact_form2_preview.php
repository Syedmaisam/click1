<link rel="stylesheet" href="http://www.cliks.it/click/views/layered/animatemaster/animate.min.css">
<style>
body
{
margin:0px;
padding:0px;
}
.ulp-content {
    position: relative;
}
.ulp-window {
    text-align: left;
}
.ulp-content {
    position: relative;
}
#ulp-layer-25 {
    background-color: rgba(255, 255, 255, 0.9);
    background-image: url("https://layeredpopups.com/layered-popups/images/default/graybg03.png");
    background-repeat: repeat;
    box-shadow: 0 4px 20px rgba(32, 32, 32, 1);
    text-align: left;
    z-index: 1000003;
}
#ulp-layer-25, #ulp-layer-25 p, #ulp-layer-25 a, #ulp-layer-25 span, #ulp-layer-25 li, #ulp-layer-25 input, #ulp-layer-25 button, #ulp-layer-25 textarea {
    color: #000000;
    font-family: "arial",arial;
    font-weight: 400;
}
.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}
#ulp-layer-26 {
    box-shadow: 0 0 60px rgba(32, 32, 32, 0.1) inset;
    text-align: left;
    z-index: 1000005;
}
#ulp-layer-26, #ulp-layer-26 p, #ulp-layer-26 a, #ulp-layer-26 span, #ulp-layer-26 li, #ulp-layer-26 input, #ulp-layer-26 button, #ulp-layer-26 textarea {
    color: #000000;
    font-family: "arial",arial;
    font-weight: 400;
}
.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}
#ulp-layer-27 {
    border-bottom: 4px solid #e33a0c;
    text-align: left;
    z-index: 1000006;
}
#ulp-layer-27, #ulp-layer-27 p, #ulp-layer-27 a, #ulp-layer-27 span, #ulp-layer-27 li, #ulp-layer-27 input, #ulp-layer-27 button, #ulp-layer-27 textarea {
    color: #000000;
    font-family: "arial",arial;
    font-weight: 400;
}
.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}
iframe {
    width: 100%;
}
#ulp-layer-27 {
    text-align: left;
}
#ulp-layer-27, #ulp-layer-27 p, #ulp-layer-27 a, #ulp-layer-27 span, #ulp-layer-27 li, #ulp-layer-27 input, #ulp-layer-27 button, #ulp-layer-27 textarea {
    color: #000000;
}
#ulp-layer-28 {
    text-align: justify;
    z-index: 1000007;
}
#ulp-layer-28, #ulp-layer-28 p, #ulp-layer-28 a, #ulp-layer-28 span, #ulp-layer-28 li, #ulp-layer-28 input, #ulp-layer-28 button, #ulp-layer-28 textarea {
    color: #000000;
    font-family: "arial",arial;
    font-weight: 400;
}
.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}
#ulp-layer-28 input.ulp-input {
    padding-left: 32px !important;
}
#ulp-bhbP2pBNMoj7Lhvz .ulp-input, #ulp-bhbP2pBNMoj7Lhvz .ulp-input:hover, #ulp-bhbP2pBNMoj7Lhvz .ulp-input:active, #ulp-bhbP2pBNMoj7Lhvz .ulp-input:focus {
    background-color: rgba(255, 255, 255, 1) !important;
    border-color: #aaaaaa;
    border-radius: 2px !important;
    border-width: 1px !important;
}
#ulp-layer-28, #ulp-layer-28 p, #ulp-layer-28 a, #ulp-layer-28 span, #ulp-layer-28 li, #ulp-layer-28 input, #ulp-layer-28 button, #ulp-layer-28 textarea {
    color: #000000;
    font-family: "arial",arial;
    font-weight: 400;
}
.ulp-input {
    background: none repeat scroll 0 0 rgba(255, 255, 255, 0.8);
    border-radius: 2px !important;
    border-spacing: 0 !important;
    border-style: solid !important;
    border-width: 1px !important;
    box-shadow: none !important;
    box-sizing: border-box !important;
    clear: both !important;
    font-size: inherit !important;
    height: 100% !important;
    line-height: 1.5 !important;
    margin: 0 !important;
    padding: 0 6px !important;
    vertical-align: middle !important;
    width: 100% !important;
}
input:-moz-read-write, textarea:-moz-read-write {
    -moz-user-modify: read-write !important;
}
input {
    -moz-appearance: textfield;
    -moz-binding: url("chrome://global/content/platformHTMLBindings.xml#inputFields");
    -moz-user-select: text;
    cursor: text;
    font: ;
    letter-spacing: normal;
    line-height: normal;
    padding: 1px;
    text-align: start;
    text-indent: 0;
    text-rendering: optimizelegibility;
    text-shadow: none;
    text-transform: none;
    word-spacing: normal;
}
textarea > .anonymous-div, input > .anonymous-div, input::-moz-placeholder, textarea::-moz-placeholder, *|*::-moz-button-content, *|*::-moz-display-comboboxcontrol-frame, optgroup:before {
    text-overflow: inherit;
    unicode-bidi: inherit;
}
input::-moz-placeholder, textarea::-moz-placeholder {
    display: inline-block !important;
    opacity: 0.54;
    overflow: hidden !important;
    pointer-events: none !important;
    resize: none !important;
}
textarea > .anonymous-div, input > .anonymous-div, input::-moz-placeholder, textarea::-moz-placeholder {
    -moz-control-character-visibility: visible;
    border: 0 none !important;
    display: inline-block;
    ime-mode: inherit;
    margin: 0;
    overflow: auto;
    padding: inherit !important;
    resize: inherit;
    text-decoration: inherit;
    white-space: pre;
}
input > .anonymous-div, input::-moz-placeholder {
    line-height: -moz-block-height;
    word-wrap: normal !important;
}
.ulp-fa-input-table {
    display: table;
    height: 100%;
    left: 0;
    line-height: 100%;
    position: absolute;
    top: 0;
    vertical-align: middle;
}
#ulp-layer-28 {
    text-align: justify;
}
#ulp-layer-28, #ulp-layer-28 p, #ulp-layer-28 a, #ulp-layer-28 span, #ulp-layer-28 li, #ulp-layer-28 input, #ulp-layer-28 button, #ulp-layer-28 textarea {
    color: #000000;
}
#ulp-layer-28 div.ulp-fa-input-cell {
    padding-left: 4px !important;
    width: 28px !important;
}
.ulp-fa-input-cell {
    display: table-cell;
    opacity: 0.7;
    text-align: center;
    vertical-align: middle;
}
#ulp-layer-28, #ulp-layer-28 p, #ulp-layer-28 a, #ulp-layer-28 span, #ulp-layer-28 li, #ulp-layer-28 input, #ulp-layer-28 button, #ulp-layer-28 textarea {
    color: #000000;
}
.fa-user:before {
    content: "";
}
.fa-user:before {
    content: "";
}
.fa {
    display: inline-block;
    font-family: FontAwesome;
    font-feature-settings: normal;
    font-kerning: auto;
    font-language-override: normal;
    font-size: inherit;
    font-size-adjust: none;
    font-stretch: normal;
    font-style: normal;
    font-synthesis: weight style;
    font-variant: normal;
    font-weight: normal;
    line-height: 1;
    text-rendering: auto;
}
.ulp-fa-input-cell {
    text-align: center;
}
#ulp-layer-29 {
    text-align: left;
    z-index: 1000007;
}
#ulp-layer-29, #ulp-layer-29 p, #ulp-layer-29 a, #ulp-layer-29 span, #ulp-layer-29 li, #ulp-layer-29 input, #ulp-layer-29 button, #ulp-layer-29 textarea {
    color: #000000;
    font-family: "arial",arial;
    font-weight: 400;
}
.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}
#ulp-layer-29 input.ulp-input {
    padding-left: 32px !important;
}
#ulp-bhbP2pBNMoj7Lhvz .ulp-input, #ulp-bhbP2pBNMoj7Lhvz .ulp-input:hover, #ulp-bhbP2pBNMoj7Lhvz .ulp-input:active, #ulp-bhbP2pBNMoj7Lhvz .ulp-input:focus {
    background-color: rgba(255, 255, 255, 1) !important;
    border-color: #aaaaaa;
    border-radius: 2px !important;
    border-width: 1px !important;
}
#ulp-layer-29, #ulp-layer-29 p, #ulp-layer-29 a, #ulp-layer-29 span, #ulp-layer-29 li, #ulp-layer-29 input, #ulp-layer-29 button, #ulp-layer-29 textarea {
    color: #000000;
    font-family: "arial",arial;
    font-weight: 400;
}
.ulp-input {
    background: none repeat scroll 0 0 rgba(255, 255, 255, 0.8);
    border-radius: 2px !important;
    border-spacing: 0 !important;
    border-style: solid !important;
    border-width: 1px !important;
    box-shadow: none !important;
    box-sizing: border-box !important;
    clear: both !important;
    font-size: inherit !important;
    height: 100% !important;
    line-height: 1.5 !important;
    margin: 0 !important;
    padding: 0 6px !important;
    vertical-align: middle !important;
    width: 100% !important;
}
input:-moz-read-write, textarea:-moz-read-write {
    -moz-user-modify: read-write !important;
}
input {
    -moz-appearance: textfield;
    -moz-binding: url("chrome://global/content/platformHTMLBindings.xml#inputFields");
    -moz-user-select: text;
    cursor: text;
    font: ;
    letter-spacing: normal;
    line-height: normal;
    padding: 1px;
    text-align: start;
    text-indent: 0;
    text-rendering: optimizelegibility;
    text-shadow: none;
    text-transform: none;
    word-spacing: normal;
}
textarea > .anonymous-div, input > .anonymous-div, input::-moz-placeholder, textarea::-moz-placeholder, *|*::-moz-button-content, *|*::-moz-display-comboboxcontrol-frame, optgroup:before {
    text-overflow: inherit;
    unicode-bidi: inherit;
}
input::-moz-placeholder, textarea::-moz-placeholder {
    display: inline-block !important;
    opacity: 0.54;
    overflow: hidden !important;
    pointer-events: none !important;
    resize: none !important;
}
textarea > .anonymous-div, input > .anonymous-div, input::-moz-placeholder, textarea::-moz-placeholder {
    -moz-control-character-visibility: visible;
    border: 0 none !important;
    display: inline-block;
    ime-mode: inherit;
    margin: 0;
    overflow: auto;
    padding: inherit !important;
    resize: inherit;
    text-decoration: inherit;
    white-space: pre;
}
input > .anonymous-div, input::-moz-placeholder {
    line-height: -moz-block-height;
    word-wrap: normal !important;
}
.ulp-fa-input-table {
    display: table;
    height: 100%;
    left: 0;
    line-height: 100%;
    position: absolute;
    top: 0;
    vertical-align: middle;
}
#ulp-layer-29 div.ulp-fa-input-cell {
    padding-left: 4px !important;
    width: 28px !important;
}
.ulp-fa-input-cell {
    display: table-cell;
    opacity: 0.7;
    text-align: center;
    vertical-align: middle;
}
.fa-envelope:before {
    content: "";
}
.fa-envelope:before {
    content: "";
}
.fa {
    display: inline-block;
    font-family: FontAwesome;
    font-feature-settings: normal;
    font-kerning: auto;
    font-language-override: normal;
    font-size: inherit;
    font-size-adjust: none;
    font-stretch: normal;
    font-style: normal;
    font-synthesis: weight style;
    font-variant: normal;
    font-weight: normal;
    line-height: 1;
    text-rendering: auto;
}
.ulp-fa-input-cell {
    text-align: center;
}
#ulp-layer-30 {
    text-align: justify;
    z-index: 1000007;
}
#ulp-layer-30, #ulp-layer-30 p, #ulp-layer-30 a, #ulp-layer-30 span, #ulp-layer-30 li, #ulp-layer-30 input, #ulp-layer-30 button, #ulp-layer-30 textarea {
    color: #000000;
    font-family: "arial",arial;
    font-weight: 400;
}
.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}
#ulp-bhbP2pBNMoj7Lhvz .ulp-input, #ulp-bhbP2pBNMoj7Lhvz .ulp-input:hover, #ulp-bhbP2pBNMoj7Lhvz .ulp-input:active, #ulp-bhbP2pBNMoj7Lhvz .ulp-input:focus {
    background-color: rgba(255, 255, 255, 1) !important;
    border-color: #aaaaaa;
    border-radius: 2px !important;
    border-width: 1px !important;
}
#ulp-layer-30, #ulp-layer-30 p, #ulp-layer-30 a, #ulp-layer-30 span, #ulp-layer-30 li, #ulp-layer-30 input, #ulp-layer-30 button, #ulp-layer-30 textarea {
    color: #000000;
    font-family: "arial",arial;
    font-weight: 400;
}
.ulp-input {
    background: none repeat scroll 0 0 rgba(255, 255, 255, 0.8);
    border-radius: 2px !important;
    border-spacing: 0 !important;
    border-style: solid !important;
    border-width: 1px !important;
    box-shadow: none !important;
    box-sizing: border-box !important;
    clear: both !important;
    font-size: inherit !important;
    height: 100% !important;
    line-height: 1.5 !important;
    margin: 0 !important;
    padding: 0 6px !important;
    vertical-align: middle !important;
    width: 100% !important;
	 border: 1px solid #333;
}
input:-moz-read-write, textarea:-moz-read-write {
    -moz-user-modify: read-write !important;
}
textarea {
    -moz-appearance: textfield-multiline;
    -moz-binding: url("chrome://global/content/platformHTMLBindings.xml#textAreas");
    -moz-user-select: text;
    cursor: text;
    letter-spacing: normal;
    margin: 1px 0;
    padding: 0 1px;
    resize: both;
    text-align: start;
    text-indent: 0;
    text-rendering: optimizelegibility;
    text-shadow: none;
    text-transform: none;
    vertical-align: text-bottom;
    word-spacing: normal;
    word-wrap: break-word;
}
textarea > .anonymous-div, input > .anonymous-div, input::-moz-placeholder, textarea::-moz-placeholder, *|*::-moz-button-content, *|*::-moz-display-comboboxcontrol-frame, optgroup:before {
    text-overflow: inherit;
    unicode-bidi: inherit;
}
textarea::-moz-placeholder {
    white-space: pre-wrap !important;
}
input::-moz-placeholder, textarea::-moz-placeholder {
    display: inline-block !important;
    opacity: 0.54;
    overflow: hidden !important;
    pointer-events: none !important;
    resize: none !important;
}
textarea > .anonymous-div, input > .anonymous-div, input::-moz-placeholder, textarea::-moz-placeholder {
    -moz-control-character-visibility: visible;
    border: 0 none !important;
    display: inline-block;
    ime-mode: inherit;
    margin: 0;
    overflow: auto;
    padding: inherit !important;
    resize: inherit;
    text-decoration: inherit;
    white-space: pre;
}
#ulp-layer-31 {
    text-align: center;
    z-index: 1000007;
}
#ulp-layer-31, #ulp-layer-31 p, #ulp-layer-31 a, #ulp-layer-31 span, #ulp-layer-31 li, #ulp-layer-31 input, #ulp-layer-31 button, #ulp-layer-31 textarea {
    color: #ffffff;
    font-family: "arial",arial;
    font-weight: 400;
}
.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}
#ulp-bhbP2pBNMoj7Lhvz .ulp-submit, #ulp-bhbP2pBNMoj7Lhvz .ulp-submit:visited {
    background: linear-gradient(#bf310b, #e33a0c) repeat scroll 0 0 #e33a0c;
    border: 1px solid #e33a0c;
    border-radius: 2px !important;
}
#ulp-layer-31, #ulp-layer-31 p, #ulp-layer-31 a, #ulp-layer-31 span, #ulp-layer-31 li, #ulp-layer-31 input, #ulp-layer-31 button, #ulp-layer-31 textarea {
    color: #ffffff;
    font-family: "arial",arial;
    font-weight: 400;
}
.ulp-window a {
    text-decoration: none !important;
}
.ulp-submit, .ulp-submit:visited, .ulp-submit-button, .ulp-submit-button:visited {
    border-radius: 2px;
    box-shadow: none;
    cursor: pointer;
    display: inline-block;
    font-size: inherit !important;
    height: auto;
    line-height: 1.5;
    margin: 0;
    padding: 5px 20px;
    position: relative;
    text-decoration: none !important;
    text-shadow: 0 -1px 1px rgba(0, 0, 0, 0.25);
    transition-duration: 0.3s;
    white-space: nowrap;
    width: auto;
	 background: linear-gradient(#bf310b, #e33a0c) repeat scroll 0 0 #e33a0c;
    border: 1px solid #e33a0c;
    border-radius: 2px !important;
}
.fo-right-ribbon a:hover, .fo-right-ribbon a:focus, a {
    text-decoration: none;
}
a, a:active, a:hover {
    outline: medium none;
}
.fa-edit:before, .fa-pencil-square-o:before {
    content: "";
}
.fa-edit:before, .fa-pencil-square-o:before {
    content: "";
}
.fa {
    display: inline-block;
    font-family: FontAwesome;
    font-feature-settings: normal;
    font-kerning: auto;
    font-language-override: normal;
    font-size: inherit;
    font-size-adjust: none;
    font-stretch: normal;
    font-style: normal;
    font-synthesis: weight style;
    font-variant: normal;
    font-weight: normal;
    line-height: 1;
    text-rendering: auto;
	
}
#ulp-layer-31, #ulp-layer-31 p, #ulp-layer-31 a, #ulp-layer-31 span, #ulp-layer-31 li, #ulp-layer-31 input, #ulp-layer-31 button, #ulp-layer-31 textarea {
    color: #ffffff;
}
.ulp-submit, .ulp-submit:visited, .ulp-submit-button, .ulp-submit-button:visited {
    cursor: pointer;
    font-size: inherit !important;
    text-shadow: 0 -1px 1px rgba(0, 0, 0, 0.25);
    white-space: nowrap;
}
#ulp-layer-32 {
    text-align: right;
    z-index: 1000007;
}
#ulp-layer-32, #ulp-layer-32 p, #ulp-layer-32 a, #ulp-layer-32 span, #ulp-layer-32 li, #ulp-layer-32 input, #ulp-layer-32 button, #ulp-layer-32 textarea {
    color: #ffffff;
    font-family: "arial",arial;
    font-weight: 400;
    text-shadow: 1px 1px 1px #000000;
}
.ulp-layer {
    box-sizing: border-box;
    line-height: 1.475;
    position: absolute;
}
#ulp-layer-32, #ulp-layer-32 p, #ulp-layer-32 a, #ulp-layer-32 span, #ulp-layer-32 li, #ulp-layer-32 input, #ulp-layer-32 button, #ulp-layer-32 textarea {
    color: #ffffff;
    font-family: "arial",arial;
    font-weight: 400;
    text-shadow: 1px 1px 1px #000000;
}
.ulp-window a {
    text-decoration: none !important;
}
.fo-right-ribbon a:hover, .fo-right-ribbon a:focus, a {
    text-decoration: none;
}
a, .contactForm input[type="text"]:focus, .contactForm input[type="email"]:focus, .contactForm textarea:focus, input#formSubmit, .errorForm, #subscribe input[type="email"]:focus, .errorSubs, .servSingle, #toTop i, #notForm input[type="email"]:focus, .contactForm input#submit, #loginForm input, #loginForm input[type="text"]:focus, #loginForm input[type="password"]:focus {
    transition: all 0.5s ease 0s;
}
a, a:active, a:hover {
    outline: medium none;
}

	

</style>

<div id='popupform_preview' style="display:none;"><div class='ulp-content' style='z-index:99999;width: 466px; height: 420px; margin:auto;position:fixed; left:36%; top:15%;'>
							<div id="ulp-layer-25" class="ulp-layer animated bounceInDown" style="width: 466px; height: 396px; font-size: 10px; left: 0px; top: 0px;"></div>
							<div id="ulp-layer-26" class="ulp-layer" style="width: 466px; height: 396px; font-size: 10px; left: 0px; top: 0px;"></div>
							<div id="ulp-layer-27" class="ulp-layer animated slideInDown" style="width: 466px; height: 189px; font-size: 10px; left: 0px; top: 0px;"><iframe width="100%" height="100%" frameborder="0" style="border:0" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d6044.275637456805!2d-73.98346368325204!3d40.75899341147853!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x55194ec5a1ae072e!2sTimes+Square!5e0!3m2!1sen!2s!4v1392901318461"></iframe></div>
							<div id="ulp-layer-28" class="ulp-layer animated fadeInLeftBig" style="width: 213px; height: 28px; font-size: 10px; left: 15px; top: 235px;"><input type="text" onfocus="jQuery(this).removeClass('ulp-input-error');" value="" placeholder="Enter your name..." name="ulp-name" class="ulp-input"><div class="ulp-fa-input-table"><div class="ulp-fa-input-cell"><i class="fa fa-user"></i></div></div></div>
							<div id="ulp-layer-29" class="ulp-layer animated fadeInRightBig" style="width: 213px; height: 28px; font-size: 10px; left: 237px; top: 235px;"><input type="text" onfocus="jQuery(this).removeClass('ulp-input-error');" value="" placeholder="Enter your e-mail..." name="ulp-email" class="ulp-input"><div class="ulp-fa-input-table"><div class="ulp-fa-input-cell"><i class="fa fa-envelope"></i></div></div></div>
							<div id="ulp-layer-31" class="ulp-layer animated zoomInUp" style="width: 466px; height: 29px; font-size: 12px; left: 0px; top: 310px;"><a data-loading="SENDING..." data-label="SEND MESSAGE" data-icon="fa-pencil-square-o" onclick="return ulp_subscribe(this);" class="ulp-submit"><i class="fa fa-pencil-square-o"></i>&nbsp; SEND MESSAGE</a></div>
							<div id="ulp-layer-32" class="ulp-layer" style="width: 31px; height: 15px; font-size: 18px; left: 435px; top: -23px;"><a onclick="return ulp_self_close();" href="#">×</a></div>
							<div id="ulp-layer-33" class="ulp-layer" style="display: none; width: 466px; font-size: 10px; left: 0px; top: 404px;">Thank You. We will contact you as soon as possible.</div>
						</div>

						
						<div id="blackscreen" style='width:100%; height:100%; background:#000; opacity:0.7; top:0; left:0; position:fixed; z-index:20000; display:none;'></div>
						
					</div>
						
                        <script>
function ulp_self_close()
{
	$("#popupform_preview").hide();
	$("#blackscreen").hide();
	$("#popup_content_data").html('');
}
</script>