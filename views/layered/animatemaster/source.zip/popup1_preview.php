<link rel="stylesheet" href="http://www.cliks.it/click/views/layered/animatemaster/animate.min.css">


<style>

#ulp-layer-170 {
	background-color: rgba(136, 209, 111, 1);
	box-shadow: 0 4px 20px rgba(32, 32, 32, 1);
	text-align: left;
	z-index: 1000003;
}
#ulp-layer-170, #ulp-layer-170 p, #ulp-layer-170 a, #ulp-layer-170 span, #ulp-layer-170 li, #ulp-layer-170 input, #ulp-layer-170 button, #ulp-layer-170 textarea {
	color: #000000;
	font-family: "arial", arial;
	font-weight: 400;
}
.ulp-layer {
	box-sizing: border-box;
	line-height: 1.475;
	position: absolute;
	text-align: justify;
}
#ulp-layer-171 {
	background-color: rgba(116, 68, 158, 1);
	text-align: left;
	z-index: 1000005;
}
#ulp-layer-171, #ulp-layer-171 p, #ulp-layer-171 a, #ulp-layer-171 span, #ulp-layer-171 li, #ulp-layer-171 input, #ulp-layer-171 button, #ulp-layer-171 textarea {
	color: #000000;
	font-family: "arial", arial;
	font-weight: 400;
}
#ulp-layer-172 {
	letter-spacing: -1px;
	text-align: center;
	z-index: 1000007;
}
#ulp-layer-172, #ulp-layer-172 p, #ulp-layer-172 a, #ulp-layer-172 span, #ulp-layer-172 li, #ulp-layer-172 input, #ulp-layer-172 button, #ulp-layer-172 textarea {
	color: #ffffff;
	font-family: "arial", arial;
	font-weight: 700;
}
#ulp-layer-173 {
	line-height: 1.3;
	text-align: center;
	z-index: 1000007;
}
#ulp-layer-173, #ulp-layer-173 p, #ulp-layer-173 a, #ulp-layer-173 span, #ulp-layer-173 li, #ulp-layer-173 input, #ulp-layer-173 button, #ulp-layer-173 textarea {
	color: #cda8d7;
	font-family: "arial", arial;
	font-weight: 700;
}
#ulp-layer-174 {
	text-align: center;
	z-index: 1000007;
}
#ulp-layer-174, #ulp-layer-174 p, #ulp-layer-174 a, #ulp-layer-174 span, #ulp-layer-174 li, #ulp-layer-174 input, #ulp-layer-174 button, #ulp-layer-174 textarea {
	color: #cda8d7;
	font-family: "arial", arial;
	font-weight: 400;
}
#ulp-layer-175 {
	text-align: left;
	z-index: 1000007;
}
#ulp-layer-175, #ulp-layer-175 p, #ulp-layer-175 a, #ulp-layer-175 span, #ulp-layer-175 li, #ulp-layer-175 input, #ulp-layer-175 button, #ulp-layer-175 textarea {
	color: #ffffff;
	font-family: "arial", arial;
	font-weight: 700;
}
#ulp-layer-176 {
	text-align: left;
	z-index: 1000008;
}
#ulp-layer-176, #ulp-layer-176 p, #ulp-layer-176 a, #ulp-layer-176 span, #ulp-layer-176 li, #ulp-layer-176 input, #ulp-layer-176 button, #ulp-layer-176 textarea {
	color: #000000;
	font-family: "arial", arial;
	font-weight: 400;
}
#ulp-layer-177 {
	text-align: left;
	z-index: 1000007;
}
#ulp-layer-177, #ulp-layer-177 p, #ulp-layer-177 a, #ulp-layer-177 span, #ulp-layer-177 li, #ulp-layer-177 input, #ulp-layer-177 button, #ulp-layer-177 textarea {
	color: #ffffff;
	font-family: "arial", arial;
	font-weight: 700;
}
#ulp-layer-178 {
	text-align: left;
	z-index: 1000008;
}
#ulp-layer-178, #ulp-layer-178 p, #ulp-layer-178 a, #ulp-layer-178 span, #ulp-layer-178 li, #ulp-layer-178 input, #ulp-layer-178 button, #ulp-layer-178 textarea {
	color: #000000;
	font-family: "arial", arial;
	font-weight: 400;
}
#ulp-layer-179 {
	text-align: left;
	z-index: 1000007;
}
#ulp-layer-179, #ulp-layer-179 p, #ulp-layer-179 a, #ulp-layer-179 span, #ulp-layer-179 li, #ulp-layer-179 input, #ulp-layer-179 button, #ulp-layer-179 textarea {
	color: #ffffff;
	font-family: "arial", arial;
	font-weight: 700;
}
#ulp-layer-180 {
	text-align: left;
	z-index: 1000008;
}
#ulp-layer-180, #ulp-layer-180 p, #ulp-layer-180 a, #ulp-layer-180 span, #ulp-layer-180 li, #ulp-layer-180 input, #ulp-layer-180 button, #ulp-layer-180 textarea {
	color: #000000;
	font-family: "arial", arial;
	font-weight: 400;
}
#ulp-layer-181 {
	text-align: center;
	z-index: 1000009;
}
#ulp-layer-181, #ulp-layer-181 p, #ulp-layer-181 a, #ulp-layer-181 span, #ulp-layer-181 li, #ulp-layer-181 input, #ulp-layer-181 button, #ulp-layer-181 textarea {
	color: #ffffff;
	font-family: "arial", arial;
	font-weight: 400;
}
#ulp-layer-182 {
	text-align: center;
	z-index: 1000007;
}
#ulp-layer-182, #ulp-layer-182 p, #ulp-layer-182 a, #ulp-layer-182 span, #ulp-layer-182 li, #ulp-layer-182 input, #ulp-layer-182 button, #ulp-layer-182 textarea {

	color: #ffffff;
	font-family: "arial", arial;
	font-weight: 400;
}
#ulp-layer-183 {
	background-color: rgba(81, 27, 124, 0.9);
	line-height: 36px;
	text-align: center;
	z-index: 1000007;
}
#ulp-layer-183, #ulp-layer-183 p, #ulp-layer-183 a, #ulp-layer-183 span, #ulp-layer-183 li, #ulp-layer-183 input, #ulp-layer-183 button, #ulp-layer-183 textarea {
	color: #cda8d7;
	font-family: "arial", arial;
	font-weight: 400;
}
#ulp-9fLtd5LgfcKQ7Erp .ulp-input, #ulp-9fLtd5LgfcKQ7Erp .ulp-input:hover, #ulp-9fLtd5LgfcKQ7Erp .ulp-input:active, #ulp-9fLtd5LgfcKQ7Erp .ulp-input:focus {
	background-color: rgba(255, 255, 255, 1) !important;
	border-color: #ffffff;
	border-radius: 0 !important;
	border-width: 1px !important;
}
#ulp-layer-176, #ulp-layer-176 p, #ulp-layer-176 a, #ulp-layer-176 span, #ulp-layer-176 li, #ulp-layer-176 input, #ulp-layer-176 button, #ulp-layer-176 textarea {
	color: #000000;
	font-family: "arial", arial;
	font-weight: 400;
}
.ulp-input {
	background: none repeat scroll 0 0 rgba(255, 255, 255, 0.8);
	border-color: #888;
	border-radius: 2px !important;
	border-spacing: 0 !important;
	border-style: solid !important;
	border-width: 1px !important;
	box-shadow: none !important;
	box-sizing: border-box !important;
	clear: both !important;
	font-size: inherit !important;
	height: 100% !important;
	line-height: 1.5 !important;
	margin: 0 !important;
	padding: 0 6px !important;
	vertical-align: middle !important;
	width: 100% !important;
}
#ulp-9fLtd5LgfcKQ7Erp .ulp-submit, #ulp-9fLtd5LgfcKQ7Erp .ulp-submit:visited {
	background: none repeat scroll 0 0 #0e6b2f;
	border: 1px solid #0e6b2f;
	border-radius: 0 !important;
}
#ulp-layer-181, #ulp-layer-181 p, #ulp-layer-181 a, #ulp-layer-181 span, #ulp-layer-181 li, #ulp-layer-181 input, #ulp-layer-181 button, #ulp-layer-181 textarea {
	color: #ffffff;
	font-family: "arial", arial;
	font-weight: 400;
}
.ulp-window a {
	text-decoration: none !important;
}
.ulp-submit, .ulp-submit:visited, .ulp-submit-button, .ulp-submit-button:visited {
	background-color: #019ad2;
	background-image: linear-gradient(#33bcef, #019ad2);
	background-repeat: repeat-x;
	border-radius: 2px;
	box-shadow: none;
	cursor: pointer;
	display: inline-block;
	font-size: inherit !important;
	height: auto;
	line-height: 1.5;
	margin: 0;
	padding: 5px 20px;
	position: relative;
	text-decoration: none !important;
	text-shadow: 0 -1px 1px rgba(0, 0, 0, 0.25);
	transition-duration: 0.3s;
	white-space: nowrap;
	width: auto;
}

table
{
	margin:20px;
	background:#f8f8f8;
	
}
table td
{
	padding:10px;
	border:1px solid #ccc;
}
table td label
{
	font-family:Arial, Helvetica, sans-serif;
	font-size:14px;
	font-weight:normal;
}
table td input[type='text']
{
	border:none;
	padding:10px;
	font-size:12px;
	font-weight:normal;
	border:1px solid #ccc;
	width:300px;
}
table td textarea
{
	width:300px;
	font-size:12px;
}
#updateform
{
	background:#019ad2;
	color:#fff;
	font-size:16px;
	padding:10px;
	border:1px solid #019ad2;
	width:100px;
}
</style>
<div id='popupform_preview' style="display:none;"><div class='ulp-content' style='z-index:99999;width: 560px; height: 480px; margin:auto;position:fixed; left:30%; top:15%;'>
							<div id='ulp-layer-170' class='ulp-layer animated bounce' style='width: 560px; height: 480px; font-size: 14px;  top: 0px;'></div>
							<div  id='ulp-layer-171' class='ulp-layer' style='width: 560px; height: 160px; font-size: 14px;  top: 0px;'></div>
							<div  id='ulp-layer-172' class='ulp-layer animated slideInLeft' style='width: 560px; font-size: 24px;  top: 15px;'>ARE YOU READY? GET IT NOW!</div>
							<div  id='ulp-layer-173' class='ulp-layer animated slideInRight' style='width: 560px; font-size: 16px;  top: 60px;'>Increase more than 500% of Email Subscribers!</div>
							<div id='ulp-layer-174' class='ulp-layer animated slideInUp' style='width: 560px; font-size: 13px;  top: 100px;'>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis viverra, urna vitae 
vehicula congue, purus nibh vestibulum lacus, sit amet tristique ante odio.</div>
							<div  id='ulp-layer-175' class='ulp-layer animated slideInLeft' style='width: 520px; font-size: 15px;  top: 180px; margin-left:20px;'>ENTER YOUR NAME</div>
							<div  id='ulp-layer-176' class='ulp-layer  animated slideInRight' style='width: 520px; height: 40px; font-size: 14px;  top: 205px; margin-left:20px;'><input type='text' onfocus='jQuery(this).removeClass('ulp-input-error');' value='' placeholder='Enter your name...' name='ulp-name' class='ulp-input'></div>
							<div id='ulp-layer-177' class='ulp-layer animated slideInLeft' style='width: 520px; font-size: 15px;  top: 250px;  margin-left:20px;'>ENTER YOUR E-MAIL</div>
							<div  id='ulp-layer-178' class='ulp-layer  animated slideInRight' style='width: 520px; height: 40px; font-size: 14px;  top: 275px;  margin-left:20px;'><input type='text' onfocus='jQuery(this).removeClass('ulp-input-error');' value='' placeholder='Enter your e-mail...' name='ulp-email' class='ulp-input'></div>
							<div  id='ulp-layer-181' class='ulp-layer animated slideInLeft' style='width: 520px; height: 40px; font-size: 17px;  top: 365px;'><a data-loading='Loading...' data-label='SUBSCRIBE NOW' data-icon='fa-check' onclick='return ulp_subscribe(this);' class='ulp-submit'><i class='fa fa-check'></i>&nbsp; SUBSCRIBE NOW</a></div>
							<div id='ulp-layer-182' class='ulp-layer  animated slideInRight' style='width: 520px; font-size: 13px;  top: 450px;'><i class='fa fa-lock'></i> Your Information will never be shared with any third party.</div>
							<div id='ulp-layer-183' class='ulp-layer animated slideInUp' style='width: 36px; height: 36px; font-size: 32px; left: 524px; top: 0px;'><a onclick='return ulp_self_close();' href='#'><img src='animatemaster/close.gif' style='padding-top:8px;'></a></div>
						</div>
						
						<div id="blackscreen" style='width:100%; height:100%; background:#000; opacity:0.7; top:0; left:0; position:fixed; z-index:20000; display:none;'></div></div>
						
					




<script>
function ulp_self_close()
{
	$("#popupform_preview").hide();
	$("#blackscreen").hide();
	$("#popup_content_data").html('');
}
</script>