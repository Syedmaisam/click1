<?php
include "../../../config/config.php";
$id=$_REQUEST['id'];
if($id==1)
{
	
	html_entity_decode(include SOURCE_ROOT."views/layered/animatemaster/index.php");
	
	
}
if($id==2)
{
	
	html_entity_decode(include SOURCE_ROOT."views/layered/animatemaster/terms_popup.php");

}
if($id==3)
{
	
	html_entity_decode(include SOURCE_ROOT."views/layered/animatemaster/social_email1.php");

}
if($id==4)
{
	
	html_entity_decode(include SOURCE_ROOT."views/layered/animatemaster/contact_form1.php");

}
if($id==5)
{
	
	html_entity_decode(include SOURCE_ROOT."views/layered/animatemaster/subscribe_form2.php");

}
if($id==6)
{
	
	html_entity_decode(include SOURCE_ROOT."views/layered/animatemaster/subscribe_newsletter1.php");

}
if($id==7)
{
	
	html_entity_decode(include SOURCE_ROOT."views/layered/animatemaster/contact_form2.php");

}
if($id==8)
{
	
	html_entity_decode(include SOURCE_ROOT."views/layered/animatemaster/report1.php");

}
if($id==9)
{
	html_entity_decode(include SOURCE_ROOT."views/layered/animatemaster/social_email2.php");
}
if ($id==10)
{
	html_entity_decode(include SOURCE_ROOT."views/layered/animatemaster/subscribe_newsletter2.php");
}
if ($id==11)
{
	html_entity_decode(include SOURCE_ROOT."views/layered/animatemaster/massive_traffic1.php");
}
if ($id==12)
{
	html_entity_decode(include SOURCE_ROOT."views/layered/animatemaster/massive_traffic2.php");
}
if ($id==13)
{
	html_entity_decode(include SOURCE_ROOT."views/layered/animatemaster/social_email3.php");
}
if ($id==14)
{
	html_entity_decode(include SOURCE_ROOT."views/layered/animatemaster/massive_traffic3.php");
}
if ($id==15)
{
	html_entity_decode(include SOURCE_ROOT."views/layered/animatemaster/subscribe_form3.php");
}
if ($id==16)
{
  html_entity_decode(include SOURCE_ROOT."views/layered/animatemaster/macbook.php");
}
if($id==17)
{
	html_entity_decode(include SOURCE_ROOT."views/layered/animatemaster/enjoyauroaborelias.php");
}
if ($id==18)
{
	html_entity_decode(include SOURCE_ROOT."views/layered/animatemaster/Chat1.php");
}
if($id==19)
{
	html_entity_decode(include SOURCE_ROOT."views/layered/animatemaster/Chat2.php");
}
if($id==20)
{
	html_entity_decode(include SOURCE_ROOT."views/layered/animatemaster/Chat3.php");
}
if($id==21)
{
	html_entity_decode(include SOURCE_ROOT."views/layered/animatemaster/Chat4.php");
}
if($id==22)
{
	html_entity_decode(include SOURCE_ROOT."views/layered/animatemaster/Chat5.php");
}
?>
