<link rel="stylesheet" href="<?php echo SITE_ROOT_URL; ?>views/layered/animatemaster/animate.min.css">
<script type="text/javascript" src="<?php echo SITE_ROOT_URL; ?>colorjs/jscolor.js"></script>

<style>

#ulp-layer-170 {
	background-color: rgba(136, 209, 111, 1);
	box-shadow: 0 4px 20px rgba(32, 32, 32, 1);
	text-align: left;
	z-index: 1000003;
}
#ulp-layer-170, #ulp-layer-170 p, #ulp-layer-170 a, #ulp-layer-170 span, #ulp-layer-170 li, #ulp-layer-170 input, #ulp-layer-170 button, #ulp-layer-170 textarea {
	color: #000000;
	font-family: "arial", arial;
	font-weight: 400;
}
.ulp-layer {
	box-sizing: border-box;
	line-height: 1.475;
	position: absolute;
	text-align: justify;
}
#ulp-layer-171 {
	background-color: rgba(116, 68, 158, 1);
	text-align: left;
	z-index: 1000005;
}
#ulp-layer-171, #ulp-layer-171 p, #ulp-layer-171 a, #ulp-layer-171 span, #ulp-layer-171 li, #ulp-layer-171 input, #ulp-layer-171 button, #ulp-layer-171 textarea {
	color: #000000;
	font-family: "arial", arial;
	font-weight: 400;
}
#ulp-layer-172 {
	letter-spacing: -1px;
	text-align: center;
	z-index: 1000007;
}
#ulp-layer-172, #ulp-layer-172 p, #ulp-layer-172 a, #ulp-layer-172 span, #ulp-layer-172 li, #ulp-layer-172 input, #ulp-layer-172 button, #ulp-layer-172 textarea {
	color: #ffffff;
	font-family: "arial", arial;
	font-weight: 700;
}
#ulp-layer-173 {
	line-height: 1.3;
	text-align: center;
	z-index: 1000007;
}
#ulp-layer-173, #ulp-layer-173 p, #ulp-layer-173 a, #ulp-layer-173 span, #ulp-layer-173 li, #ulp-layer-173 input, #ulp-layer-173 button, #ulp-layer-173 textarea {
	color: #cda8d7;
	font-family: "arial", arial;
	font-weight: 700;
}
#ulp-layer-174 {
	text-align: center;
	z-index: 1000007;
}
#ulp-layer-174, #ulp-layer-174 p, #ulp-layer-174 a, #ulp-layer-174 span, #ulp-layer-174 li, #ulp-layer-174 input, #ulp-layer-174 button, #ulp-layer-174 textarea {
	color: #cda8d7;
	font-family: "arial", arial;
	font-weight: 400;
}
#ulp-layer-175 {
	text-align: left;
	z-index: 1000007;
}
#ulp-layer-175, #ulp-layer-175 p, #ulp-layer-175 a, #ulp-layer-175 span, #ulp-layer-175 li, #ulp-layer-175 input, #ulp-layer-175 button, #ulp-layer-175 textarea {
	color: #ffffff;
	font-family: "arial", arial;
	font-weight: 700;
}
#ulp-layer-176 {
	text-align: left;
	z-index: 1000008;
}
#ulp-layer-176, #ulp-layer-176 p, #ulp-layer-176 a, #ulp-layer-176 span, #ulp-layer-176 li, #ulp-layer-176 input, #ulp-layer-176 button, #ulp-layer-176 textarea {
	color: #000000;
	font-family: "arial", arial;
	font-weight: 400;
}
#ulp-layer-177 {
	text-align: left;
	z-index: 1000007;
}
#ulp-layer-177, #ulp-layer-177 p, #ulp-layer-177 a, #ulp-layer-177 span, #ulp-layer-177 li, #ulp-layer-177 input, #ulp-layer-177 button, #ulp-layer-177 textarea {
	color: #ffffff;
	font-family: "arial", arial;
	font-weight: 700;
}
#ulp-layer-178 {
	text-align: left;
	z-index: 1000008;
}
#ulp-layer-178, #ulp-layer-178 p, #ulp-layer-178 a, #ulp-layer-178 span, #ulp-layer-178 li, #ulp-layer-178 input, #ulp-layer-178 button, #ulp-layer-178 textarea {
	color: #000000;
	font-family: "arial", arial;
	font-weight: 400;
}
#ulp-layer-179 {
	text-align: left;
	z-index: 1000007;
}
#ulp-layer-179, #ulp-layer-179 p, #ulp-layer-179 a, #ulp-layer-179 span, #ulp-layer-179 li, #ulp-layer-179 input, #ulp-layer-179 button, #ulp-layer-179 textarea {
	color: #ffffff;
	font-family: "arial", arial;
	font-weight: 700;
}
#ulp-layer-180 {
	text-align: left;
	z-index: 1000008;
}
#ulp-layer-180, #ulp-layer-180 p, #ulp-layer-180 a, #ulp-layer-180 span, #ulp-layer-180 li, #ulp-layer-180 input, #ulp-layer-180 button, #ulp-layer-180 textarea {
	color: #000000;
	font-family: "arial", arial;
	font-weight: 400;
}
#ulp-layer-181 {
	text-align: center;
	z-index: 1000009;
}
#ulp-layer-181, #ulp-layer-181 p, #ulp-layer-181 a, #ulp-layer-181 span, #ulp-layer-181 li, #ulp-layer-181 input, #ulp-layer-181 button, #ulp-layer-181 textarea {
	color: #ffffff;
	font-family: "arial", arial;
	font-weight: 400;
}
#ulp-layer-182 {
	text-align: center;
	z-index: 1000007;
}
#ulp-layer-182, #ulp-layer-182 p, #ulp-layer-182 a, #ulp-layer-182 span, #ulp-layer-182 li, #ulp-layer-182 input, #ulp-layer-182 button, #ulp-layer-182 textarea {
	color: #ffffff;
	font-family: "arial", arial;
	font-weight: 400;
}
#ulp-layer-183 {
	background-color: rgba(81, 27, 124, 0.9);
	line-height: 36px;
	text-align: center;
	z-index: 1000007;
}
#ulp-layer-183, #ulp-layer-183 p, #ulp-layer-183 a, #ulp-layer-183 span, #ulp-layer-183 li, #ulp-layer-183 input, #ulp-layer-183 button, #ulp-layer-183 textarea {
	color: #cda8d7;
	font-family: "arial", arial;
	font-weight: 400;
}
#ulp-9fLtd5LgfcKQ7Erp .ulp-input, #ulp-9fLtd5LgfcKQ7Erp .ulp-input:hover, #ulp-9fLtd5LgfcKQ7Erp .ulp-input:active, #ulp-9fLtd5LgfcKQ7Erp .ulp-input:focus {
	background-color: rgba(255, 255, 255, 1) !important;
	border-color: #ffffff;
	border-radius: 0 !important;
	border-width: 1px !important;
}
#ulp-layer-176, #ulp-layer-176 p, #ulp-layer-176 a, #ulp-layer-176 span, #ulp-layer-176 li, #ulp-layer-176 input, #ulp-layer-176 button, #ulp-layer-176 textarea {
	color: #000000;
	font-family: "arial", arial;
	font-weight: 400;
}
.ulp-input {
	background: none repeat scroll 0 0 rgba(255, 255, 255, 0.8);
	border-color: #888;
	border-radius: 2px !important;
	border-spacing: 0 !important;
	border-style: solid !important;
	border-width: 1px !important;
	box-shadow: none !important;
	box-sizing: border-box !important;
	clear: both !important;
	font-size: inherit !important;
	height: 100% !important;
	line-height: 1.5 !important;
	margin: 0 !important;
	padding: 0 6px !important;
	vertical-align: middle !important;
	width: 100% !important;
}
#ulp-9fLtd5LgfcKQ7Erp .ulp-submit, #ulp-9fLtd5LgfcKQ7Erp .ulp-submit:visited {
	background: none repeat scroll 0 0 #0e6b2f;
	border: 1px solid #0e6b2f;
	border-radius: 0 !important;
}
#ulp-layer-181, #ulp-layer-181 p, #ulp-layer-181 a, #ulp-layer-181 span, #ulp-layer-181 li, #ulp-layer-181 input, #ulp-layer-181 button, #ulp-layer-181 textarea {
	color: #ffffff;
	font-family: "arial", arial;
	font-weight: 400;
}
.ulp-window a {
	text-decoration: none !important;
}
.ulp-submit, .ulp-submit:visited, .ulp-submit-button, .ulp-submit-button:visited {
	background-color: #019ad2;
	background-image: linear-gradient(#33bcef, #019ad2);
	background-repeat: repeat-x;
	border-radius: 2px;
	box-shadow: none;
	cursor: pointer;
	display: inline-block;
	font-size: inherit !important;
	height: auto;
	line-height: 1.5;
	margin: 0;
	padding: 5px 20px;
	position: relative;
	text-decoration: none !important;
	text-shadow: 0 -1px 1px rgba(0, 0, 0, 0.25);
	transition-duration: 0.3s;
	white-space: nowrap;
	width: auto;
}

table
{
	margin:20px;
	background:#f8f8f8;
	
}
table td
{
	padding:10px;
	border:1px solid #ccc;
}
table td label
{
	font-family:Arial, Helvetica, sans-serif;
	font-size:14px;
	font-weight:normal;
}
table td input[type='text']
{
	border:none;
	padding:10px;
	font-size:12px;
	font-weight:normal;
	border:1px solid #ccc;
	width:300px;
}
table td textarea
{
	width:300px;
	font-size:12px;
}
#updateform
{
	background:#019ad2;
	color:#fff;
	font-size:16px;
	padding:10px;
	border:1px solid #019ad2;
	width:100px;
}
</style>
<?php

$txthtml="<div id='popupform' style='position:relative;'><div class='ulp-content' style='z-index:99999;width: 560px; height: 480px; margin:auto; left:30%; top:15%;'>
							<div id='ulp-layer-170' class='ulp-layer animated bounce' style='width: 560px; height: 480px; font-size: 14px;  top: 0px;'></div>
							<div  id='ulp-layer-171' class='ulp-layer' style='width: 560px; height: 160px; font-size: 14px;  top: 0px;'></div>
							<div  id='ulp-layer-172' class='ulp-layer animated slideInLeft' style='width: 560px; font-size: 24px;  top: 15px;'>ARE YOU READY? GET IT NOW!</div>
							<div  id='ulp-layer-173' class='ulp-layer animated slideInRight' style='width: 560px; font-size: 16px;  top: 60px;'>Increase more than 500% of Email Subscribers!</div>
							<div id='ulp-layer-174' class='ulp-layer animated slideInUp' style='width: 560px; font-size: 13px;  top: 100px;'>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis viverra, urna vitae 
vehicula congue, purus nibh vestibulum lacus, sit amet tristique ante odio.</div>
							<div  id='ulp-layer-175' class='ulp-layer animated slideInLeft' style='width: 520px; font-size: 15px;  top: 180px; margin-left:20px;'>ENTER YOUR NAME</div>
							<div  id='ulp-layer-176' class='ulp-layer  animated slideInRight' style='width: 520px; height: 40px; font-size: 14px;  top: 205px; margin-left:20px;'><input type='text' onfocus='jQuery(this).removeClass('ulp-input-error');' value='' placeholder='Enter your name...' name='ulp-name' class='ulp-input'></div>
							<div id='ulp-layer-177' class='ulp-layer animated slideInLeft' style='width: 520px; font-size: 15px;  top: 250px;  margin-left:20px;'>ENTER YOUR E-MAIL</div>
							<div  id='ulp-layer-178' class='ulp-layer  animated slideInRight' style='width: 520px; height: 40px; font-size: 14px;  top: 275px;  margin-left:20px;'><input type='text' onfocus='jQuery(this).removeClass('ulp-input-error');' value='' placeholder='Enter your e-mail...' name='ulp-email' class='ulp-input'></div>
							<div  id='ulp-layer-181' class='ulp-layer animated slideInLeft' style='width: 520px; height: 40px; font-size: 17px;  top: 365px;'><a data-loading='Loading...' data-label='SUBSCRIBE NOW' data-icon='fa-check' onclick='return ulp_subscribe(this);' class='ulp-submit'><i class='fa fa-check'></i>&nbsp; SUBSCRIBE NOW</a></div>
							<div id='ulp-layer-182' class='ulp-layer  animated slideInRight' style='width: 520px; font-size: 13px;  top: 450px;'><i class='fa fa-lock'></i> Your Information will never be shared with any third party.</div>
							<div id='ulp-layer-183' class='ulp-layer animated slideInUp' style='width: 36px; position:relative; height: 36px; font-size: 32px; left: 524px; top: 0px;'><a onclick='return ulp_self_close();' href='#'><img src='".SITE_ROOT_URL."views/layered/animatemaster/close.gif' style='padding-top:8px;'></a></div></div></div>
						
					
						";
						
											
						echo $txthtml;
						//$ss= htmlentities(mysql_real_escape_string($txthtml));
						//$sql="insert into popup(text_data) values('$ss')";
						//mysql_query($sql);
						
						//$sql="select * from popup";
						//$result=mysql_query($sql);
						//$row=mysql_fetch_row($result);
						//echo html_entity_decode($row[1]);
						
						?>

<div style="margin-top:30px;">

<table width="97%" border="0">
  <tr>
    
    <td><label>Popup Background Color :</label></td>
    <td><input class="color boxcolor" value="66ff00" id="popbgcolor" onchange="popup_bg();"></td>
    <td><label>Header Background Color :</label></td>
    <td><input class="color boxcolor" value="66ff00" id="bkgcolor" onchange="header_bg();"></td>
    <td></td>
    <td></td>
    
  </tr>
  <tr>
    <td><label>Layer one Color :</label></td>
    <td><input class="color boxcolor" value="66ff00" id="layer1_color" onchange="layer1_color();"></td>
    <td><label>Layer One Text :</label></td>
    <td><input type="text" value="" id="layer1_txt" onkeypress="layer1_txt();" maxlength="30" /></td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
   <tr>
    <td><label>Layer Two Color :</label></td>
    <td><input class="color boxcolor" value="66ff00" id="layer2_color" onchange="layer2_color();"></td>
    <td><label>Layer Two Text :</label></td>
    <td><input type="text" value="" id="layer2_txt" onkeypress="layer2_txt();"  /></td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
     <tr>
    <td><label>Layer Three Color :</label></td>
    <td><input class="color boxcolor" value="66ff00" id="layer3_color" onchange="layer3_color();"></td>
    <td><label>Layer Three Text :</label></td>
    <td><textarea id="layer3_txt" onkeypress="layer3_txt();"></textarea></td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
      <tr>
    <td><label>Label One Color :</label></td>
    <td><input class="color boxcolor" value="66ff00" id="label1_color" onchange="label1_color();"></td>
    <td><label>Label One Text :</label></td>
    <td><input type="text" value="" id="label1_txt" onkeypress="label1_txt();"  /></td>
    <td><label>Placeholder one text :</label></td>
    <td><input type="text" value="" id="placeholder1_txt" onkeypress="placeholder1_txt();"  /></td>
  </tr>
  
     <tr>
    <td><label>Label Two Color :</label></td>
    <td><input class="color boxcolor" value="66ff00" id="label2_color" onchange="label2_color();"></td>
    <td><label>Label Two Text :</label></td>
    <td><input type="text" value="" id="label2_txt" onkeypress="label2_txt();"  /></td>
    <td><label>Placeholder Two text :</label></td>
    <td><input type="text" value="" id="placeholder2_txt" onkeypress="placeholder2_txt();"  /></td>
  </tr>
  
  
   
    <tr>
    <td><label>Button Color:</label></td>
    <td><input class="color boxcolor" value="66ff00" id="button1_color" onchange="button1_color();"></td>
    <td><label>Button Background Color :</label></td>
    <td><input class="color boxcolor" value="66ff00" id="button1_bkgcolor" onchange="button1_bkgcolor();"></td>
    <td><label>Button Text :</label></td>
    <td><input type="text" value="" id="button1_txt" onkeypress="button1_txt();"  /></td>
  
  </tr>
  
   <tr>
    <td><label>Layer Four Color :</label></td>
    <td><input class="color boxcolor" value="66ff00" id="layer4_color" onchange="layer4_color();"></td>
    <td><label>Layer Four Text :</label></td>
    <td><input type="text" value="" onkeypress="layer4_txt();" id="layer4_txt" /></td>
    <td>Close Button Background</td>
    <td><input class="color boxcolor" value="66ff00" id="buttonclose_bkgcolor" onchange="buttonclose_bkgcolor();"></td>
  </tr>
  
  
  
  
    <tr>
<td>&nbsp;</td>    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
</table>



  
  
  
  
 
</div>

<script type="text/javascript">
function pop_layer_data()
{
	var layer1_txt=$("#ulp-layer-172").html();
	var layer2_txt=$("#ulp-layer-173").html();
	var layer3_txt=$("#ulp-layer-174").html();
	var label1_txt=$("#ulp-layer-175").html();
	var label2_txt=$("#ulp-layer-177").html();
	var label3_txt=$("#ulp-layer-179").html();
	var layer4_txt=$("#ulp-layer-182").html();
	var placeholder1_txt=$("#ulp-layer-176 .ulp-input").attr('placeholder');
	var placeholder2_txt=$("#ulp-layer-178 .ulp-input").attr('placeholder');
	var placeholder3_txt=$("#ulp-layer-180 .ulp-input").attr('placeholder');
	var button1_txt=$("#ulp-layer-181 .ulp-submit").html();

	$("#layer1_txt").val(layer1_txt);
	$("#layer2_txt").val(layer2_txt);
	$("#layer3_txt").val(layer3_txt);
	$("#label1_txt").val(label1_txt);
	$("#label2_txt").val(label2_txt);
	$("#label3_txt").val(label3_txt);
	$("#layer4_txt").val(layer4_txt);
	$("#placeholder1_txt").val(placeholder1_txt);
	$("#placeholder2_txt").val(placeholder2_txt);
	$("#placeholder3_txt").val(placeholder3_txt);
	$("#button1_txt").val(button1_txt);
}

						function popup_bg()
						{
							
							var popbgcolor="#"+$("#popbgcolor").val();
							//alert(bgcolor);
							$("#ulp-layer-170").css("background-color",popbgcolor);
						}
						function header_bg()
						{
							var bkgcolor="#"+$("#bkgcolor").val();
							//alert(bgcolor);
							$("#ulp-layer-171").css("background-color",bkgcolor);
						}
						
						function layer1_color()
						{
							var fcolor="#"+$("#layer1_color").val();
							//alert(bgcolor);
							$("#ulp-layer-172").css("color",fcolor);
						}
						function layer1_txt()
						{
							var layer1_txt=$("#layer1_txt").val();
							//alert(bgcolor);
							$("#ulp-layer-172").html(layer1_txt);
						}
						function layer2_color()
						{
							var fcolor="#"+$("#layer2_color").val();
							//alert(bgcolor);
							$("#ulp-layer-173").css("color",fcolor);
						}
						function layer2_txt()
						{
							var layer2_txt=$("#layer2_txt").val();
							//alert(bgcolor);
							$("#ulp-layer-173").html(layer2_txt);
						}
						function layer3_color()
						{
							var fcolor="#"+$("#layer3_color").val();
							//alert(bgcolor);
							$("#ulp-layer-174").css("color",fcolor);
						}
						function layer3_txt()
						{
							var layer3_txt=$("#layer3_txt").val();
							//alert(bgcolor);
							$("#ulp-layer-174").html(layer3_txt);
						}
						function label1_color()
						{
							var fcolor="#"+$("#label1_color").val();
							//alert(bgcolor);
							$("#ulp-layer-175").css("color",fcolor);
						}
						function label1_txt()
						{
							var label1_txt=$("#label1_txt").val();
							//alert(bgcolor);
							$("#ulp-layer-175").html(label1_txt);
						}
						function placeholder1_txt()
						{
							var placeholder1_txt=$("#placeholder1_txt").val();
							//alert(bgcolor);
							$("#ulp-layer-176 .ulp-input").attr('placeholder',placeholder1_txt);
						}
						
						function label2_color()
						{
							var fcolor="#"+$("#label2_color").val();
							//alert(bgcolor);
							$("#ulp-layer-177").css("color",fcolor);
						}
						function label2_txt()
						{
							var label2_txt=$("#label2_txt").val();
							//alert(bgcolor);
							$("#ulp-layer-177").html(label2_txt);
						}
						function placeholder2_txt()
						{
							var placeholder2_txt=$("#placeholder2_txt").val();
							//alert(bgcolor);
							$("#ulp-layer-178 .ulp-input").attr('placeholder',placeholder2_txt);
						}
						function label3_color()
						{
							var fcolor="#"+$("#label3_color").val();
							//alert(bgcolor);
							$("#ulp-layer-179").css("color",fcolor);
						}
						function label3_txt()
						{
							var label3_txt=$("#label3_txt").val();
							//alert(bgcolor);
							$("#ulp-layer-179").html(label3_txt);
						}
						function placeholder3_txt()
						{
							var placeholder3_txt=$("#placeholder3_txt").val();
							//alert(bgcolor);
							$("#ulp-layer-180 .ulp-input").attr('placeholder',placeholder3_txt);
						}
						
						function button1_color()
						{
							var fcolor="#"+$("#button1_color").val();
							//alert(bgcolor);
							$("#ulp-layer-181 .ulp-submit").css("color",fcolor);
						}
						function button1_bkgcolor()
						{
							var button1_bkgcolor="#"+$("#button1_bkgcolor").val();
							//alert(button1_bkgcolor);
							$("#ulp-layer-181 .ulp-submit").css('background',button1_bkgcolor);
						}
						function button1_txt()
						{
							var button1_txt=$("#button1_txt").val();
							//alert(bgcolor);
							$("#ulp-layer-181 .ulp-submit").html(button1_txt);
						}
						
						function layer4_color()
						{
							var fcolor="#"+$("#layer4_color").val();
							//alert(bgcolor);
							$("#ulp-layer-182").css("color",fcolor);
						}
						function layer4_txt()
						{
							var layer4_txt=$("#layer4_txt").val();
							//alert(bgcolor);
							$("#ulp-layer-182").html(layer4_txt);
						}
						
						function buttonclose_bkgcolor()
						{
							var bkgcolor="#"+$("#buttonclose_bkgcolor").val();
							//alert(bgcolor);
							$("#ulp-layer-183").css("background-color",bkgcolor);
						}
						
						
						function updateform()
						{
							var popupform= $("#popupform").html();
							
							$.ajax({
							type: "post",
							url: 'animatemaster/updatepop1.php',
							data: {
							popupform: popupform,
							},			
							success: function(response) {
								alert(response);
							},
							error:function 
							(XMLHttpRequest, textStatus, errorThrown) {
							}
							});  
							
						}
						</script>
